//
//  DXPreferencesWindowController.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSInteger DXPreferencesMemorySlotMinimum;
extern NSInteger DXPreferencesMemorySlotMaximum;
extern NSString *DXPreferencesResetSlotsNotificationName;
extern NSString *DXPreferencesShowLogAtStartupKey;
extern NSString *DXPreferencesWarnBeforeClearingLogKey;
extern NSString *DXPreferencesWarnBeforeResettingSlotsKey;


@interface DXPreferencesWindowController : NSWindowController {

}

+ (NSString *)suffixStringForSlotNumbered:(NSInteger)tag;
+ (NSDictionary *)defaultSlotValuesDictionary;

+ (void)initialize;
- (id)init;

- (void)resetAllSlots;
- (void)resetSlotWithTag:(NSInteger)tag;
- (void)resetAllSlotsNotificationReceived:(NSNotification *)notification;


@end
