//
//  DXConflictsWindowController.m
//  Polymatic
//
//  Created by Andrew Merenbach on 8/14/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXConflictsWindowController.h"
#import "DXConflictEntry.h"

NSString *DXNewConflictNotificationName = @"DXNewConflictNotification";

@implementation DXConflictsWindowController

@synthesize conflicts = m_conflictsArray;
@synthesize conflictsArrayController = m_conflictsArrayController;
@synthesize conflictSortDescriptors = m_conflictSortDescriptors;

- (id)init {
	self = [super initWithWindowNibName:@"Conflicts"];
	if (self != nil) {
		NSSortDescriptor *sd = [[[NSSortDescriptor alloc] initWithKey:@"message" ascending:YES] autorelease];

		m_conflictsArray = [[NSArray alloc] init];
		m_conflictSortDescriptors = [[NSArray arrayWithObject:sd] copy];
	}
	return self;
}

- (void)dealloc {
	[m_conflictsArray release];
	m_conflictsArray = nil;

	[m_conflictSortDescriptors release];    
	m_conflictSortDescriptors = nil;
	
	[super dealloc];
}

- (void)assignConflictsWithStrings:(NSArray *)array {
	[self clearConflicts];
	
	for (NSString *conflict in array) {
		[self addConflictWithString:conflict];
	}
}

- (void)showConflictSheetForWindow:(NSWindow *)window {
	[NSApp beginSheet:self.window
	   modalForWindow:window
		modalDelegate:self
	   didEndSelector:@selector(didEndConflictSheet:returnCode:contextInfo:)
		  contextInfo:NULL];

	// the following line does not appear to be necessary as of 2010-04-22:
	//[self.window makeKeyWindow];  // [todo] feels like a kludge...
}

- (void)didEndConflictSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
	[sheet orderOut:self];
}

- (void)endConflictSheet:(id)sender {
	[NSApp endSheet:self.window];
}

- (void)addConflictWithString:(NSString *)string {
	DXConflictEntry *conflict = [DXConflictEntry entryWithMessage:string];
	[self.conflictsArrayController addObject:conflict];
}

- (void)clearConflicts {
	self.conflicts = [NSArray array];
}

- (void)conflictsGenerated:(NSNotification *)notification {
	NSArray *conflicts = [notification object];
	[self assignConflictsWithStrings:conflicts];
	
	NSBeep();
	[self showConflictSheetForWindow:[NSApp mainWindow]];
}


/*- (NSIndexSet *)tableView:(NSTableView *)tableView selectionIndexesForProposedSelection:(NSIndexSet *)proposedSelectionIndexes {

}*/

- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(NSInteger)rowIndex {
	return NO;
}

@end
