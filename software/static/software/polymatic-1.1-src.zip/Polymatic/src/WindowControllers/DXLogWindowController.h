//
//  DXLogWindowController.h
//  Polymatic
//
//  Created by Andrew Merenbach on 22/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *DXLogNodeNotificationName;

@class AMTableView;

@interface DXLogWindowController : NSWindowController {
    NSArray *m_groupNodes;
    NSArrayController *m_groupsArrayController;
    AMTableView *m_groupTableView;
    AMTableView *m_poolTableView;
	AMTableView *m_dieTableView;
	NSSplitView *m_groupSplitView;
	NSSplitView *m_poolSplitView;
}

@property (copy, readwrite) NSArray *groupNodes;
@property (assign) IBOutlet NSArrayController *groupsArrayController;
@property (assign) IBOutlet AMTableView *groupTableView;
@property (assign) IBOutlet AMTableView *poolTableView;
@property (assign) IBOutlet AMTableView *dieTableView;
@property (assign) IBOutlet NSSplitView *groupSplitView;
@property (assign) IBOutlet NSSplitView *poolSplitView;

+ (void)initialize;
- (id)init;
- (void)dealloc;
- (void)windowDidLoad;

- (void)logNode:(NSNotification *)notification;
- (IBAction)clearLog:(id)sender;
- (void)didEndClearLogSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
- (void)finishClearingLog;

//- (IBAction)exportLog:(id)sender;
//- (void)exportLogSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;

@end

@interface DXLogWindowController (TableViewDataSourceMethods)
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView;
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
@end

@interface DXBooleanToStringValueTransformer : NSValueTransformer {}
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;
@end

/*
@implementation DXModifierPresenceValueTransformer
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;
@end
*/

@interface DXLogWindowController (SplitViewDelegateMethods)
//- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset;
//- (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset;
- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset;
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize;
- (void)windowDidResize:(NSNotification *)notification;
@end