//
//  DXLogWindowController.m
//  Polymatic
//
//  Created by Andrew Merenbach on 22/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import "DXLogWindowController.h"
#import "DXPreferencesWindowController.h"
#import "AMTableView.h"

#import "DXRoll.h"
#import "DXGroup.h"
#import "DXPool.h"
#import "DXDie.h"

#define DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS 120
#define DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW 200

NSString *DXLogNodeNotificationName = @"DX_LOG_NODE_NOTIFICATION";

@implementation DXLogWindowController

@synthesize groupNodes = m_groupNodes;
@synthesize groupsArrayController = m_groupsArrayController;
@synthesize groupTableView = m_groupTableView;
@synthesize poolTableView = m_poolTableView;
@synthesize dieTableView = m_dieTableView;
@synthesize groupSplitView = m_groupSplitView;
@synthesize poolSplitView = m_poolSplitView;

+ (void)initialize {
	NSValueTransformer *vt;
	
	vt = [[DXBooleanToStringValueTransformer alloc] init];
	[NSValueTransformer setValueTransformer:vt forName:@"DXBooleanToString"];
	
	//vt = [[DXModifierPresenceValueTransformer alloc] init];
	//[NSValueTransformer setValueTransformer:vt forName:@"DXModifierPresence"];
}

- (id)init {
	self = [super initWithWindowNibName:@"Log"];
	if (self != nil) {
		m_groupNodes = [[NSArray alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_groupNodes release];
	m_groupNodes = nil;
	
	[super dealloc];
}

/*- (void)windowDidLoad {
	[self.window setExcludedFromWindowsMenu:YES];   // we have a static entry in the Windows menu
}*/

- (void)windowDidLoad {
	self.groupTableView.spaceKeyAdds = NO;
	self.groupTableView.enterKeyAdds = NO;
	self.groupTableView.deleteKeyRemoves = NO;
	self.groupTableView.spaceKeySendsDoubleAction = NO;
	self.groupTableView.enterKeySendsDoubleAction = NO;
	
	self.poolTableView.spaceKeyAdds = NO;
	self.poolTableView.enterKeyAdds = NO;
	self.poolTableView.deleteKeyRemoves = NO;
	self.poolTableView.spaceKeySendsDoubleAction = NO;
	self.poolTableView.enterKeySendsDoubleAction = NO;
	
	self.dieTableView.spaceKeyAdds = NO;
	self.dieTableView.enterKeyAdds = NO;
	self.dieTableView.deleteKeyRemoves = NO;
	self.dieTableView.spaceKeySendsDoubleAction = NO;
	self.dieTableView.enterKeySendsDoubleAction = NO;
}

- (void)logNode:(NSNotification *)notification {
	NSTreeNode *node = [notification object];
	
	//DXRoll *repObj = [node representedObject];
	//repObj.order = [self.groupNodes count] + 1;
	[self.groupsArrayController addObject:node];
	
	// scroll most recent row to visible
	NSInteger rowCount = [self.groupTableView numberOfRows];
	if (rowCount > 0) {
		[self.groupTableView scrollRowToVisible:(rowCount - 1)];
		//[self.groupTableView scrollToEndOfDocument:nil];
	}
	//[self.groupsArrayController performSelectorOnMainThread:@selector(addObject:) withObject:node waitUntilDone:YES];
	//[[self mutableArrayValueForKey:@"groupNodes"] addObject:node];
	//[self.groupsArrayController setSelectedObjects:[NSArray arrayWithObject:node]];
}

- (IBAction)clearLog:(id)sender {	
	if ([[NSUserDefaults standardUserDefaults] boolForKey:DXPreferencesWarnBeforeClearingLogKey]) {
		// sanity-check
		if (![self.window isVisible]) {
			[self showWindow:sender];
		}
		
		NSBeep();

		// show confirmation...
		
		NSAlert *alert = [[[NSAlert alloc] init] autorelease];
		[alert addButtonWithTitle:NSLocalizedString(@"OK", @"OK")];
		[alert addButtonWithTitle:NSLocalizedString(@"Cancel", @"Cancel")];
		[alert setMessageText:NSLocalizedString(@"DXClearLogAreYouSureMessageText", @"DXClearLogAreYouSureMessageText")];
		[alert setInformativeText:NSLocalizedString(@"DXClearLogAreYouSureInformativeText", @"DXClearLogAreYouSureInformativeText")];
		[alert setAlertStyle:NSInformationalAlertStyle];
		
		[alert beginSheetModalForWindow:self.window
						  modalDelegate:self
						 didEndSelector:@selector(didEndClearLogSheet:returnCode:contextInfo:)
							contextInfo:(void *)sender];
	} else {
		// ...or not
		[self finishClearingLog];
	}
}

- (void)didEndClearLogSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
	if (returnCode == NSAlertFirstButtonReturn) {
		[self finishClearingLog];
	}
}

- (void)finishClearingLog {
	self.groupNodes = [NSArray array];
}

/*- (IBAction)exportLog:(id)sender {
 NSSavePanel *sp;
 
 sp = [NSSavePanel savePanel];
 
 [sp setCanSelectHiddenExtension:YES];
 [sp setRequiredFileType:@"html"];
 
 [sp
 beginSheetForDirectory:nil
 file:NSLocalizedString(@"Polymatic Log", @"Polymatic Log")
 modalForWindow:self.window
 modalDelegate:self
 didEndSelector:@selector(exportLogSavePanelDidEnd:returnCode:contextInfo:)
 contextInfo:NULL];
 }
 
 - (void)exportLogSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
 if (returnCode == NSOKButton) {
 NSString *templateFilename = @"log-export-template";
 NSBundle *bundle = [NSBundle mainBundle];
 NSString *path = [bundle pathForResource:templateFilename ofType:@"xhtml"];
 
 NSMutableString *outString = [NSMutableString string];
 [outString appendString:@"<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"];
 
 for (NSTreeNode *groupNode in self.groupNodes) {
 DXGroup *group = [groupNode representedObject];
 [outString appendFormat:@"<ta", ];
 
 for (NSTreeNode *poolNode in groupNode.childNodes) {
 DXPool *pool = [poolNode representedObject];
 
 for (NSTreeNode *dieNode in poolNode.childNodes) {
 DXDie *die = [dieNode representedObject];
 
 }
 }
 }
 
 [outString appendString:@"</table>\n"];
 
 [outString writeToFile:[sheet filename] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
 }
 }*/

@end

@implementation DXLogWindowController (TableViewDataSourceMethods)

#define DL_LINE_NUMBER_KEY @"lineNumber"

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
	return 0;	
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	id retVal = nil;
	if ([[aTableColumn identifier] isEqualToString:DL_LINE_NUMBER_KEY]) {
		NSNumber *number = [NSNumber numberWithInteger:rowIndex + 1];
		retVal = number;
	}
	return retVal;
}

@end

@implementation DXBooleanToStringValueTransformer
+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	id retVal = nil;
	if (value != nil) {
		BOOL b = [value boolValue];
		if (b) {
			retVal = NSLocalizedString(@"BooleanYES", @"BooleanYES");
		}
		else {
			retVal = NSLocalizedString(@"BooleanNO", @"BooleanNO");
		}
	}
	return retVal;
}
@end

/*
@implementation DXModifierPresenceValueTransformer
+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	id retVal = nil;
	if (value) {
		id repObj = []
		BOOL b = [value boolValue];
		if (b) {
			retVal = NSLocalizedString(@"BooleanYES", @"BooleanYES");
		}
		else {
			retVal = NSLocalizedString(@"BooleanNO", @"BooleanNO");
		}
	}
	return retVal;
}
@end
*/

@implementation DXLogWindowController (SplitViewDelegateMethods)

- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
	CGFloat newPosition = proposedPosition;
	
	if (sender == self.groupSplitView) {
		if (proposedPosition < DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW) {
			newPosition = DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW;
		} else if (proposedPosition > NSWidth([sender frame]) - DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW) {
			newPosition = NSWidth([sender frame]) - DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW;
		}
	} else if (sender == self.poolSplitView) {
		if (proposedPosition < DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS) {
			newPosition = DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS;
		} else if (proposedPosition > NSHeight([sender frame]) - DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS) {
			newPosition = NSHeight([sender frame]) - DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS;
		}
	}
	return newPosition;
}

/*  During live resize of the window, lock the left side, the collection
 side, and resize the tableside
 The frames have to be set to add up to the total size minus the divider
 thickness */
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize {
	//detect if it's a window resize
	if (sender == self.groupSplitView) {
		if ([sender inLiveResize]) {
			CGFloat dt = [sender dividerThickness];
			
			//info needed
			NSRect tmpRect = [sender bounds];
			NSArray *subviews =  [sender subviews];
			NSView *collectionsSide = [subviews objectAtIndex:0];
			NSView *tableSide = [subviews objectAtIndex:1];
			CGFloat collectionWidth = [collectionsSide bounds].size.width;
			
			//tableside frame: full size minus collection width and divider
			// My divider thickness is hard coded here as 1
			tmpRect.size.width = tmpRect.size.width - collectionWidth - dt;
			tmpRect.origin.x = tmpRect.origin.x + collectionWidth + dt;
			[tableSide setFrame:tmpRect];
			
			//collection frame stays the same
			tmpRect.size.width = collectionWidth;
			tmpRect.origin.x = 0;
			[collectionsSide setFrame:tmpRect];
		}
		/*else
			[sender adjustSubviews];*/
	}
	else if (sender == self.poolSplitView) {
		if ([sender inLiveResize]) {
			CGFloat dt = [sender dividerThickness];
			
			//info needed
			NSRect tmpRect = [sender bounds];
			NSArray *subviews =  [sender subviews];
			NSView *collectionsSide = [subviews objectAtIndex:0];
			NSView *tableSide = [subviews objectAtIndex:1];
			CGFloat collectionHeight = [collectionsSide bounds].size.height;
			
			//tableside frame: full size minus collection width and divider
			// My divider thickness is hard coded here as 1
			tmpRect.size.height = tmpRect.size.height - collectionHeight - dt;
			tmpRect.origin.y = tmpRect.origin.y + collectionHeight + dt;
			[tableSide setFrame:tmpRect];
			
			//collection frame stays the same
			tmpRect.size.height = collectionHeight;
			tmpRect.origin.y = 0;
			[collectionsSide setFrame:tmpRect];
		}
		/*else
		 [sender adjustSubviews];*/
	}
}

- (void)windowDidResize:(NSNotification *)notification {
	NSWindow *window = [notification object];
	if (window == self.window) {
		NSSplitView *sv = self.poolSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat h = NSHeight(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (h < (DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS - dt)) {
			h = DX_MINIMUM_HEIGHT_FOR_POOL_AND_DIE_VIEWS - dt;
			
			// get the differential between the height we want and the height of the bottom rectangle
			CGFloat diff = h - NSHeight(rect);
			
			// resize the top view to the new height and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.height -= diff;
			topRect.origin.y += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}		
	}
	
	if (window == self.window) {
		NSSplitView *sv = self.groupSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat w = NSWidth(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (w < (DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW - dt)) {
			w = DX_MINIMUM_WIDTH_FOR_GROUP_OR_OTHER_VIEW - dt;
			
			// get the differential between the width we want and the width of the bottom rectangle
			CGFloat diff = w - NSWidth(rect);
			
			// resize the top view to the new width and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.width -= diff;
			topRect.origin.x += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}
	}
}

/*- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize
 {
 NSRect newFrame = [sender frame];
 CGFloat dt = [sender dividerThickness];
 
 //NSView *leftView = self.splitViewBottomView;
 //NSView *rightView = self.splitViewTopView;
 NSView *leftView = self.splitViewTopView;
 NSView *rightView = self.splitViewBottomView;
 
 // this is the fixed view (right)
 // on top on being fixed it is also collapsible
 NSRect rightFrame = [self.splitViewBottomView frame];
 // this is the flexible view (left)
 NSRect leftFrame = [self.splitViewTopView frame];
 
 rightFrame.size.height = newFrame.size.height;
 leftFrame.size.height = newFrame.size.height;
 
 if (![self.recordsSplitView isSubviewCollapsed:rightView]) {
 NSLog(@"not collapsed");
 rightFrame.origin.x = newFrame.size.width - rightFrame.size.width;
 rightFrame.origin.y = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - rightFrame.size.width - dt;
 } else {
 NSLog(@"collapsed");
 rightFrame.origin.x = newFrame.size.width;
 rightFrame.origin.y = 0;
 rightFrame.size.width = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - dt;
 }
 [leftView setFrame: leftFrame];
 [rightView setFrame:rightFrame];
 }*/

@end
