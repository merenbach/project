//
//  DXConflictsWindowController.h
//  Polymatic
//
//  Created by Andrew Merenbach on 8/14/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *DXNewConflictNotificationName;

@interface DXConflictsWindowController : NSWindowController {
    NSArray *m_conflictsArray;
    NSArrayController *m_conflictsArrayController;
    
    NSArray *m_conflictSortDescriptors;
}

@property (copy, readwrite) NSArray *conflicts;
@property (assign) IBOutlet NSArrayController *conflictsArrayController;
@property (readonly) NSArray *conflictSortDescriptors;

- (id)init;

- (void)assignConflictsWithStrings:(NSArray *)array;
- (void)showConflictSheetForWindow:(NSWindow *)window;
- (void)didEndConflictSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
- (void)endConflictSheet:(id)sender;


- (void)addConflictWithString:(NSString *)string;
- (void)clearConflicts;
- (void)conflictsGenerated:(NSNotification *)notification;

//- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(NSInteger)rowIndex;

@end
