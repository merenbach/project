//
//  DXPreferencesWindowController.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

/* A note on the mechanics and logistics of the memory slots (2010-04-18):
 *	The memory slot system works by appending the word "Slot" plus a number,
 *	from 0 to 4, to the preference in question.  This is not applied to all
 *	preferences, but rather only to those involved in die-rolling.  A base
 *	of is in use, despite only four *visible* slots being available in the
 *	GUI, for the purposes of having an "invisible" slot that the can save
 *	settings across program launches.  This seemed the easiest method, and
 *	appears to work quite well--and, frankly, seems to be the right way to
 *	do things.
 */

#import "DXPreferencesWindowController.h"
#import "DXLogWindowController.h"


#define DXSlotPrefix @"Slot"	/* for settings memory */

NSInteger DXPreferencesMemorySlotMinimum = 0;	// slot 0 is for latest settings
NSInteger DXPreferencesMemorySlotMaximum = 4;
NSString *DXPreferencesResetSlotsNotificationName = @"DX_RESET_SLOTS";
NSString *DXPreferencesShowLogAtStartupKey = @"showLogWindowAtStartup";
NSString *DXPreferencesWarnBeforeClearingLogKey = @"warnBeforeClearingLog";
NSString *DXPreferencesWarnBeforeResettingSlotsKey = @"warnBeforeResettingSlots";


@implementation DXPreferencesWindowController

+ (NSString *)suffixStringForSlotNumbered:(NSInteger)tag {
	return [NSString stringWithFormat:@"%@%i", DXSlotPrefix, tag];
}

//@synthesize standardDefaultsTemplate = m_standardDefaultsTemplate;

+ (NSDictionary *)defaultSlotValuesDictionary {
	static NSDictionary *dict = nil;
	if (!dict) {
		NSString *path = [[NSBundle mainBundle] pathForResource:@"InitialStandardDefaultsForSlots" ofType:@"plist"];
		dict = [[NSDictionary alloc] initWithContentsOfFile:path];
	}
	return dict;	
}

+ (void)initialize {	
	// for preferences
	NSString *sharedPath = [[NSBundle mainBundle] pathForResource:@"InitialSharedDefaults" ofType:@"plist"];
	NSDictionary *sharedValues = [NSDictionary dictionaryWithContentsOfFile:sharedPath];
	[[NSUserDefaultsController sharedUserDefaultsController] setInitialValues:sharedValues];

	// for slots
	//NSString *standardPath = [[NSBundle mainBundle] pathForResource:@"InitialStandardDefaultsForSlots" ofType:@"plist"];
	//NSDictionary *standardValues = [NSDictionary dictionaryWithContentsOfFile:standardPath];
	NSDictionary *standardValues = [[self class] defaultSlotValuesDictionary];
	
	// configure default slots
	/* first, make a copy of values; the reasoning here is a little convoluted:
	 * we want a slot-based dictionary, configured below, with individual settings for each slot;
	 * but, at the same time, the reset-all-settings mumbo-jumbo requires a universal slot, so we
	 * need the base values, too.
	 */
	NSMutableDictionary *newValues = [NSMutableDictionary dictionaryWithDictionary:standardValues];
	for (NSInteger counter = DXPreferencesMemorySlotMinimum; counter <= DXPreferencesMemorySlotMaximum; counter++) {
		for (id key in standardValues) {
			id value = [standardValues objectForKey:key];
			NSString *newKey = [key stringByAppendingFormat:@"%@%i", DXSlotPrefix, counter];
			[newValues setObject:value forKey:newKey];
		}
	}
	[newValues addEntriesFromDictionary:sharedValues];	// we want to register these, too
	
	[[NSUserDefaults standardUserDefaults] registerDefaults:newValues];
}

- (id)init {
	self = [super initWithWindowNibName:@"Preferences"];
	return self;
}

- (void)resetAllSlots {
	for (NSInteger tag = DXPreferencesMemorySlotMinimum; tag <= DXPreferencesMemorySlotMaximum; tag++) {
		[self resetSlotWithTag:tag];
	}	
}

- (void)resetSlotWithTag:(NSInteger)tag {
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSDictionary *dictRep = [[self class] defaultSlotValuesDictionary];
	
    NSString *string = [DXPreferencesWindowController suffixStringForSlotNumbered:tag];
	
	for (id key in dictRep) {
		[defaults removeObjectForKey:[key stringByAppendingString:string]];
	}
}

- (void)resetAllSlotsNotificationReceived:(NSNotification *)notification {
	[self resetAllSlots];
}

@end
