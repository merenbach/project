//
//  DXMainWindowController_Conflicts.m
//  Polymatic
//
//  Created by Andrew Merenbach on 8/19/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXMainWindowController_Conflicts.h"
#import "DXAspectController.h" /* kludge? for precedence */


@implementation DXMainWindowController (DXBasicSettingsChecks)

- (BOOL)testForPoolsUnderflow {
    BOOL success = YES;
    
    if (self.numberOfPoolsToRoll <= 0) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForPoolsOverflow {
    BOOL success = YES;
    
    if (self.numberOfPoolsToRoll > DXStandardMax) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForSidesUnderflow {
    BOOL success = YES;
    
    if (self.numberOfSidesPerDie <= 0) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForCountUnderflow {
    BOOL success = YES;
    
    if (self.numberOfDicePerPool <= 0) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForCountOverflow {
    BOOL success = YES;
    
    if (self.numberOfDicePerPool > DXStandardMax) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForSidesOverflow {
    BOOL success = YES;
    
    if (self.numberOfSidesPerDie > DXStandardMax) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForResultOverflow {
    BOOL success = YES;
    
    NSInteger maxVal;
    
    //if (!self.cachedWillRollAsPercentile) {
        maxVal = [self possibleMaximumResultForIndividualPool];
    //}
    /*else {
        maxVal = [self possibleMaximumResultForPercentile];
    }*/
    
    if (maxVal > DXMaximumResult /*|| maxVal < DXMinimumResult*/) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForResultUnderflow {
    BOOL success = YES;
    
    NSInteger minVal;
    
    //if (!self.cachedWillRollAsPercentile) {
        minVal = [self possibleMaximumResultForIndividualPool];
    //}
    /*else {
        minVal = [self possibleMinimumResultForPercentile];
    }*/
    
    if (minVal < DXMinimumResult /*|| minVal > DXMaximumResult*/) {
        success = NO;
    }
    
    return success;
}


// does the number of dice to drop exceed the number of dice being rolled?
- (BOOL)testForMoreDropsThanDice {
    BOOL success = YES;

    NSInteger conditionalLowDrops = (self.cachedWillDropLowestRolls ? self.cachedNumberOfLowDrops : 0);
    NSInteger conditionalHighDrops = (self.cachedWillDropHighestRolls ? self.cachedNumberOfHighDrops : 0);
    
    if (conditionalLowDrops + conditionalHighDrops > self.numberOfDicePerPool) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertCannotDropAllDice) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

// we don't allow multiple rerolling categories to be set simultaneously
- (BOOL)testForRerollingCategoryCount {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    NSInteger valueForwillRerollIndividualDice = (willRerollIndividualDice ? 1 : 0);
    //NSInteger valueForWillRerollPercentile = (willRerollPercentile ? 1 : 0);
    NSInteger valueForwillRerollIndividualPools = (willRerollIndividualPools ? 1 : 0);

    if (valueForwillRerollIndividualDice + valueForwillRerollIndividualPools > 1) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertCannotRerollMultiCategory) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

#pragma mark -

- (BOOL)testForModifiersUnderflow {
    return ([self testForModifiersUnderflowPerDie] && [self testForModifiersUnderflowPerPool]);
}

- (BOOL)testForModifiersOverflow {
    return ([self testForModifiersOverflowPerDie] && [self testForModifiersOverflowPerPool]);
}

- (BOOL)testForModifiersOverflowPerDie {
    BOOL success = YES;
    
    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    if (conditionalPerDieBonusValue > DXStandardMax || conditionalPerDiePenaltyValue > DXStandardMax || conditionalPerDieMultiplierValue > DXStandardMax) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForModifiersOverflowPerPool {
    BOOL success = YES;
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);
    
    if (conditionalPerPoolBonusValue > DXStandardMax || conditionalPerPoolPenaltyValue > DXStandardMax || conditionalPerPoolMultiplierValue > DXStandardMax) {
        success = NO;
    }
    
    return success;
}


- (BOOL)testForModifiersUnderflowPerDie {
    BOOL success = YES;
    
    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    if (conditionalPerDieBonusValue < DXStandardZero || conditionalPerDiePenaltyValue < DXStandardZero || conditionalPerDieMultiplierValue < DXStandardZero) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForModifiersUnderflowPerPool {
    BOOL success = YES;
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);
    
    if (conditionalPerPoolBonusValue < DXStandardZero || conditionalPerPoolPenaltyValue < DXStandardZero || conditionalPerPoolMultiplierValue < DXStandardZero) {
        success = NO;
    }
    
    return success;
}

#pragma mark -

- (BOOL)testForDropsOverflow {
    BOOL success = YES;
    
    NSInteger lowDrops = self.cachedNumberOfLowDrops;
    NSInteger highDrops = self.cachedNumberOfHighDrops;
        
    BOOL willDropLo = self.cachedWillDropLowestRolls;
    BOOL willDropHi = self.cachedWillDropHighestRolls;

    if ((willDropLo && lowDrops > DXStandardMax) || (willDropHi && highDrops > DXStandardMax)) {
        success = NO;
    }
    
    return success;
}

- (BOOL)testForDropsUnderflow {
    BOOL success = YES;
    
    NSInteger lowDrops = self.cachedNumberOfLowDrops;
    NSInteger highDrops = self.cachedNumberOfHighDrops;
    
    BOOL willDropLo = self.cachedWillDropLowestRolls;
    BOOL willDropHi = self.cachedWillDropHighestRolls;
    
    if ((willDropLo && lowDrops < 0) || (willDropHi && highDrops < 0)) {
        success = NO;
    }
    
    return success;
}

@end

@implementation DXMainWindowController (DXModifierChecks)

- (BOOL)willApplyModifiersPerDie {
    BOOL b = (self.cachedWillApplyPerDieBonusValue || self.cachedWillApplyPerDiePenaltyValue || self.cachedWillApplyPerDieMultiplierValue);
    return b;
}

- (BOOL)willApplyModifiersPerPool {
    BOOL b = (self.cachedWillApplyPerPoolBonusValue || self.cachedWillApplyPerPoolPenaltyValue || self.cachedWillApplyPerPoolMultiplierValue);
    return b;
}

- (BOOL)willApplyModifiersAfterIndividual {
    BOOL b = (self.cachedRerollPrecedenceForDice == DXRerollAfterModifiers);
    return b;
}

/*- (BOOL)willApplyModifiersAfterPercentile {
    BOOL b = (self.cachedWillRollAsPercentile && self.cachedRerollPercentileDicePrecedence == DXRerollAfterModifiers);
    return b;
}*/

- (BOOL)determineWillApplyModifiersAfterPool {
    BOOL b = (self.cachedRerollPrecedenceForPools == DXRerollAfterModifiers);
    return b;
}

@end

@implementation DXMainWindowController (DXPossibleMinimumResults)



- (NSInteger)possibleMinimumResultForIndividualDie {
    //BOOL afterMods = (self.cachedWillApplyPerDieBonusValue || self.cachedWillApplyPerDiePenaltyValue || self.cachedWillApplyPerDieMultiplierValue);
    BOOL afterMods = [self willApplyModifiersAfterIndividual];

    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);

    //NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    //NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    //NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

    // calculate!
    NSInteger value = 1;
    
    if (afterMods) {
        value *= conditionalPerDieMultiplierValue;
        value += conditionalPerDieBonusValue;
        value -= conditionalPerDiePenaltyValue;

        //value *= conditionalPerPoolMultiplierValue;
        //value += conditionalPerPoolBonusValue;
        //value -= conditionalPerPoolPenaltyValue;
    }
    return value;
}

/*- (NSInteger)possibleMinimumResultForPercentile {
    BOOL afterMods = [self determineWillApplyModifiersAfterPool];

    //NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    //NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    //NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);
    
    NSInteger minPerDie = DXPercentileSideValueMin + 1;
    NSInteger value = minPerDie;
    
    if (afterMods) {
        value *= conditionalPerPoolMultiplierValue; // should be zero...
        value += conditionalPerPoolBonusValue;
        value -= conditionalPerPoolPenaltyValue;
    }
    
    //NSInteger value = (conditionalPerDieMultiplierValue * (DXPercentileDieSideCount / * min sides per die * / + conditionalPerDieBonusValue - conditionalPerDiePenaltyValue));

    return value;
}*/

- (NSInteger)possibleMinimumResultForIndividualPool {
    //BOOL afterMods = (self.cachedWillApplyPerDieBonusValue || self.cachedWillApplyPerDiePenaltyValue || self.cachedWillApplyPerDieMultiplierValue);
    BOOL afterMods = [self determineWillApplyModifiersAfterPool];


    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

        NSInteger value = 1;
    
//if (afterMods) {
        value *= conditionalPerDieMultiplierValue;
        value += conditionalPerDieBonusValue;
        value -= conditionalPerDiePenaltyValue;

        //value *= conditionalPerPoolMultiplierValue;
        //value += conditionalPerPoolBonusValue;
        //value -= conditionalPerPoolPenaltyValue;
//}


    value *= self.numberOfDicePerPool;
    
    if (afterMods) {
        value *= conditionalPerPoolMultiplierValue;
        value += conditionalPerPoolBonusValue;
        value -= conditionalPerPoolPenaltyValue;
    }
    
    //++value;
    
    return value;
    

    /*NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);

    //NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    //NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    //NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

    NSInteger value = (conditionalPerDieMultiplierValue * (1 / * min sides per die * / + conditionalPerDieBonusValue - conditionalPerDiePenaltyValue));

    return value;*/
}

@end


@implementation DXMainWindowController (DXPossibleMaximumResults)

- (NSInteger)possibleMaximumResultForIndividualDie {
    //BOOL afterMods = (self.cachedWillApplyPerDieBonusValue || self.cachedWillApplyPerDiePenaltyValue || self.cachedWillApplyPerDieMultiplierValue);
    BOOL afterMods = [self willApplyModifiersAfterIndividual];


    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);

    //NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    //NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    //NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

    // calculate!
    NSInteger value = self.numberOfSidesPerDie;
    
    if (afterMods) {
        value *= conditionalPerDieMultiplierValue;
        value += conditionalPerDieBonusValue;
        value -= conditionalPerDiePenaltyValue;
    }
    
    /*if (afterMods) {
        NSInteger value3 = value2 * conditionalPerPoolMultiplierValue;
        NSInteger value4 = value3 + conditionalPerPoolBonusValue - conditionalPerPoolPenaltyValue;
        value = value4;
    }
    else {
        value = value2;
    }*/

    return value;
}

/*- (NSInteger)possibleMaximumResultForPercentile {
    BOOL afterMods = [self determineWillApplyModifiersAfterPool];

    //NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    //NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    //NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);
    
    //NSInteger maxPerDie = DXPercentileSideValueMax;
    NSInteger count = self.numberOfDicePerPool;
    NSInteger sides = self.numberOfSidesPerDie;   // equals ten
    NSInteger value = (NSInteger)floor(pow((double)sides, (double)count));
    
    if (afterMods) {
        value *= conditionalPerPoolMultiplierValue; // should be zero...
        value += conditionalPerPoolBonusValue;
        value -= conditionalPerPoolPenaltyValue;
    }
    //NSInteger value = (conditionalPerDieMultiplierValue * (DXPercentileDieSideCount / * min sides per die * / + conditionalPerDieBonusValue - conditionalPerDiePenaltyValue));

    return value;
}*/

- (NSInteger)possibleMaximumResultForIndividualPool {
    //BOOL afterMods = (self.cachedWillApplyPerDieBonusValue || self.cachedWillApplyPerDiePenaltyValue || self.cachedWillApplyPerDieMultiplierValue);
    BOOL afterMods = [self determineWillApplyModifiersAfterPool];

    NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

    // calculate!
    NSInteger value = self.numberOfSidesPerDie;
    
//if (afterMods) {
        value *= conditionalPerDieMultiplierValue;
        value += conditionalPerDieBonusValue;
        value -= conditionalPerDiePenaltyValue;
//}


NSUInteger dropTotal = 0;

if (self.cachedWillDropLowestRolls) dropTotal += self.cachedNumberOfLowDrops;
if (self.cachedWillDropHighestRolls) dropTotal += self.cachedNumberOfHighDrops;

NSInteger diceAfterDrops = self.numberOfDicePerPool - dropTotal;

    value *= diceAfterDrops;
    
    if (afterMods) {
        value *= conditionalPerPoolMultiplierValue;
        value += conditionalPerPoolBonusValue;
        value -= conditionalPerPoolPenaltyValue;
    }
    

    //--value;
    
    return value;
    
    /*NSInteger conditionalPerDieBonusValue = (self.cachedWillApplyPerDieBonusValue ? self.cachedPerDieBonusValue : 0);
    NSInteger conditionalPerDiePenaltyValue = (self.cachedWillApplyPerDiePenaltyValue ? self.cachedPerDiePenaltyValue : 0);
    NSInteger conditionalPerDieMultiplierValue = (self.cachedWillApplyPerDieMultiplierValue ? self.cachedPerDieMultiplierValue : 1);
    
    //NSInteger conditionalPerPoolBonusValue = (self.cachedWillApplyPerPoolBonusValue ? self.cachedPerPoolBonusValue : 0);
    //NSInteger conditionalPerPoolPenaltyValue = (self.cachedWillApplyPerPoolPenaltyValue ? self.cachedPerPoolPenaltyValue : 0);
    //NSInteger conditionalPerPoolMultiplierValue = (self.cachedWillApplyPerPoolMultiplierValue ? self.cachedPerPoolMultiplierValue : 1);

    NSInteger value = (conditionalPerDieMultiplierValue * (self.numberOfSidesPerDie + conditionalPerDieBonusValue - conditionalPerDiePenaltyValue));
    
    return value;*/
}

@end

//@implementation DXMainWindowController (DXPercentileSettingsCompatibility)

// are we rolling as percentile, but with an unsupported number of dice?
/*- (BOOL)testForPercentileDieCountOverrun {
    BOOL success = YES;

    if (self.cachedWillRollAsPercentile && self.numberOfDicePerPool > DXMaxPercentileDieCount) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertTooManyPercentileDice) withObject:nil waitUntilDone:NO];
        success = NO;
    }
    
    return success;
}

// are we rolling as percentile, but with any per-die modifiers? this could lead to an overrun, as each percentile die has only ten sides
- (BOOL)testForPercentileDieModifierOverrun {
    BOOL success = YES;

    BOOL applyMods = [self willApplyModifiersPerDie];

    if (self.cachedWillRollAsPercentile && applyMods) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertPercentileDiceModifierOverrun) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

// are we dropping dice in percentile mode?
- (BOOL)testForDropsWithPercentile {
    BOOL success = YES;

    if (self.cachedWillRollAsPercentile) {
        if (self.cachedWillDropLowestRolls || self.cachedWillDropHighestRolls) {
//            [[NSApp delegate] performSelectorOnMainThread:@selector(alertCannotDropWithPercentile) withObject:nil waitUntilDone:NO];
            success = NO;
        }
    }
    
    return success;
}

// if we're rolling as percentile, then... are any incompatible rerolling options set?
- (BOOL)testForPercentileRollWithNonPercentileReroll {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    if (self.cachedWillRollAsPercentile && (willRerollIndividualDice || willRerollTotal)) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertCannotMixPercentilRerollSettings) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}*/

// test for rolling as non-percentile, but with incompatible rerolling options
/*- (BOOL)testForNonPercentileRollWithPercentileReroll {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    if (!self.cachedWillRollAsPercentile && willRerollPercentile) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertCannotMixPercentilRerollSettings) withObject:nil waitUntilDone:NO];
        success = NO;            
    }
    
    return success;
}*/

//@end

@implementation DXMainWindowController (DXRerollRangeOverlaps)

// check for individual rerolling range overlap
- (BOOL)testForRerollRangeOverlapIndividual {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);
    BOOL shouldRerollBothBelowAndAbove = self.cachedWillRerollBelowValueForDice && self.cachedWillRerollAboveValueForDice;

    //NSInteger conditionalValueBelowWhichToRerollIndividualDice = (self.cachedWillRerollBelowValueForDice ? self.cachedValueBelowWhichToRerollDice : 0);
    //NSInteger conditionalValueAboveWhichToRerollIndividualDice = (self.cachedWillRerollAboveValueForDice ? self.cachedValueAboveWhichToRerollDice : 0);

    if (willRerollIndividualDice && shouldRerollBothBelowAndAbove && self.cachedValueBelowWhichToRerollDice > self.cachedValueAboveWhichToRerollDice) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertImproperRerollingValues) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

// check for percentile rerolling range overlap
/*- (BOOL)testForRerollRangeOverlapPercentile {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);
    BOOL shouldRerollBothBelowAndAbove = self.cachedWillRerollPercentileDiceBelowGivenValue && self.cachedWillRerollPercentileDiceAboveGivenValue;

    //NSInteger conditionalValueBelowWhichToRerollPercentileDice = (self.cachedWillRerollPercentileDiceBelowGivenValue ? self.cachedValueBelowWhichToRerollPercentileDice : 0);
    //NSInteger conditionalValueAboveWhichToRerollPercentileDice = (self.cachedWillRerollPercentileDiceAboveGivenValue ? self.cachedValueAboveWhichToRerollPercentileDice : 0);

    if (willRerollPercentile && shouldRerollBothBelowAndAbove && self.cachedValueBelowWhichToRerollPercentileDice > self.cachedValueAboveWhichToRerollPercentileDice) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertImproperRerollingValues) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}*/

// check for total rerolling range overlap
- (BOOL)testForRerollRangeOverlapTotal {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);
    BOOL shouldRerollBothBelowAndAbove = self.cachedWillRerollBelowValueForPools && self.cachedWillRerollAboveValueForPools;

    //NSInteger conditionalValueBelowWhichToRerollIndividualPools = (self.cachedWillRerollBelowValueForPools ? self.cachedValueBelowWhichToRerollPools : 0);
    //NSInteger conditionalValueAboveWhichToRerollIndividualPools = (self.cachedWillRerollAboveValueForPools ? self.cachedValueAboveWhichToRerollPools : 0);

    if (willRerollIndividualPools && shouldRerollBothBelowAndAbove && self.cachedValueBelowWhichToRerollPools > self.cachedValueAboveWhichToRerollPools) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertImproperRerollingValues) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

@end

@implementation DXMainWindowController (DXRerollValueChecksForIndividual)

// is the "above" value below the minimum posible per-die result?
- (BOOL)testForRerollAboveValueBelowMinimumInIndividual {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    if (willRerollIndividualDice && self.cachedWillRerollAboveValueForDice && self.cachedValueAboveWhichToRerollDice < minimumResultForIndividualDie) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

// is the "below" value above the maximum posible per-die result?
- (BOOL)testForRerollBelowValueAboveMaximumInIndividual {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];    

    if (willRerollIndividualDice && self.cachedWillRerollBelowValueForDice && self.cachedValueBelowWhichToRerollDice > maximumResultForIndividualDie) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollBelowValueBelowMinimumInIndividual {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    // is the "above" value above the maximum possible per-die result?
    if (willRerollIndividualDice && self.cachedWillRerollBelowValueForDice && self.cachedValueBelowWhichToRerollDice < minimumResultForIndividualDie) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollAboveValueAboveMaximumInIndividual {
    BOOL success = YES;

    BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    // is the "below" value below the minimum possible per-die result?
    if (willRerollIndividualDice && self.cachedWillRerollAboveValueForDice && self.cachedValueAboveWhichToRerollDice > maximumResultForIndividualDie) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

@end

/*@implementation DXMainWindowController (DXRerollValueChecksForPercentile)

- (BOOL)testForRerollAboveValueBelowMinimumInPercentile {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];
    
    if (willRerollPercentile && self.cachedWillRerollPercentileDiceAboveGivenValue && self.cachedValueAboveWhichToRerollPercentileDice < minimumResultForPercentile) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollBelowValueAboveMaximumInPercentile {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];
    
    if (willRerollPercentile && self.cachedWillRerollPercentileDiceBelowGivenValue && self.cachedValueBelowWhichToRerollPercentileDice > maximumResultForPercentile) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollBelowValueBelowMinimumInPercentile {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];
    
    if (willRerollPercentile && self.cachedWillRerollPercentileDiceBelowGivenValue && self.cachedValueBelowWhichToRerollPercentileDice < minimumResultForPercentile) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollAboveValueAboveMaximumInPercentile {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    //BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    if (willRerollPercentile && self.cachedWillRerollPercentileDiceAboveGivenValue && self.cachedValueAboveWhichToRerollPercentileDice > maximumResultForPercentile) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}


@end*/

@implementation DXMainWindowController (DXRerollValueChecksForIndividualPool)

- (BOOL)testForRerollAboveValueBelowMinimumInTotal {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    if (willRerollIndividualPools && self.cachedWillRerollAboveValueForPools && self.cachedValueAboveWhichToRerollPools < minimumResultForIndividualPool) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollBelowValueAboveMaximumInTotal {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];
    
    if (willRerollIndividualPools && self.cachedWillRerollBelowValueForPools && self.cachedValueBelowWhichToRerollPools > maximumResultForIndividualPool) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorOverlapMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollBelowValueBelowMinimumInTotal {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    //NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    if (willRerollIndividualPools && self.cachedWillRerollBelowValueForPools && self.cachedValueBelowWhichToRerollPools < minimumResultForIndividualPool) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMinimum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

- (BOOL)testForRerollAboveValueAboveMaximumInTotal {
    BOOL success = YES;

    //BOOL willRerollIndividualDice = (self.cachedRerollPrecedenceForDice != DXRerollingNone);
    //BOOL willRerollPercentile = (self.cachedRerollPercentileDicePrecedence != DXRerollingNone);
    BOOL willRerollIndividualPools = (self.cachedRerollPrecedenceForPools != DXRerollingNone);

    //NSInteger minimumResultForIndividualDie = [self possibleMinimumResultForIndividualDie];
    //NSInteger minimumResultForPercentile = [self possibleMinimumResultForPercentile];
    //NSInteger minimumResultForIndividualPool = [self possibleMinimumResultForIndividualPool];
    
    //NSInteger maximumResultForIndividualDie = [self possibleMaximumResultForIndividualDie];
    //NSInteger maximumResultForPercentile = [self possibleMaximumResultForPercentile];
    NSInteger maximumResultForIndividualPool = [self possibleMaximumResultForIndividualPool];

    if (willRerollIndividualPools && self.cachedWillRerollAboveValueForPools && self.cachedValueAboveWhichToRerollPools > maximumResultForIndividualPool) {
//        [[NSApp delegate] performSelectorOnMainThread:@selector(alertRerollingRangeErrorBoundsMaximum) withObject:nil waitUntilDone:NO];
        success = NO;
    }

    return success;
}

@end
