//
//  DXMainWindowController.m
//  Polymatic
//
//  Created by Andrew Merenbach on 27/12/06.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import "DXMainWindowController.h"
#import "DXMainWindowController_Conflicts.h"

#import "DXPreferencesWindowController.h"
#import "DXAspectController.h"
#import "AMTableView.h"

// window controllers
#import "DXLogWindowController.h"
#import "DXConflictsWindowController.h"
#import "DXPreferencesWindowController.h"

// operations
#import "DXRollOperation.h"

// potential kludges for Collection View Item represented objects
#import "DXModifierSettingsRepresentation.h"
#import "DXRerollSettingsRepresentation.h"
#import "DXDropSettingsRepresentation.h"


NSString *DXWillLogRollsKey = @"willLogRolls";
NSString *DXNumberOfSidesPerDieKey = @"numberOfSidesPerDie";
NSString *DXNumberOfDicePerPoolKey = @"numberOfDicePerPool";
NSString *DXNumberOfPoolsToRollKey = @"numberOfPoolsToRoll";


@implementation DXMainWindowController

@synthesize rollsTableView = m_rollsTableView;
@synthesize memorySlotSaveSegmentedControl = m_memorySlotSaveSegmentedControl;
@synthesize memorySlotLoadSegmentedControl = m_memorySlotLoadSegmentedControl;

@synthesize defaultSidesPerDie = m_defaultSidesPerDie;  // default combo box values for sides per die
@synthesize defaultDicePerPool = m_defaultDicePerPool;  // default combo box values for dice per group

@synthesize rollsArray = m_rollsArray;   // roll results to display in main window's table
@synthesize isRunningRoll = m_isRunningRoll;  // are we rolling?
@synthesize willLogRolls = m_willLogRolls;   // should we log?
@synthesize rollOperationQueue = m_rollOperationQueue;

@synthesize numberOfSidesPerDie = m_numberOfSidesPerDie;
@synthesize numberOfDicePerPool = m_numberOfDicePerPool;
@synthesize numberOfPoolsToRoll = m_numberOfPoolsToRoll;

@synthesize aspectTabView = m_aspectTabView;            // the tab view for roll settings
@synthesize aspectControllers = m_aspectControllers;    // the controllers for aspect data
//@synthesize aspectTabViewFadeContainer = m_aspectTabViewFadeContainer;

/* modifiers */
@synthesize cachedWillApplyPerDieMultiplierValue = m_cachedWillApplyPerDieMultiplierValue;   // should we apply a per-die multiplier?
@synthesize cachedWillApplyPerDieBonusValue = m_cachedWillApplyPerDieBonusValue;        // should we apply a per-die bonus?
@synthesize cachedWillApplyPerDiePenaltyValue = m_cachedWillApplyPerDiePenaltyValue;      // should we apply a per-die penalty?
@synthesize cachedPerDieMultiplierValue = m_cachedPerDieMultiplierValue;            // value for per-die multiplier
@synthesize cachedPerDieBonusValue = m_cachedPerDieBonusValue;                 // value for per-die bonus
@synthesize cachedPerDiePenaltyValue = m_cachedPerDiePenaltyValue;               // value for per-die penalty
@synthesize cachedWillApplyPerPoolMultiplierValue = m_cachedWillApplyPerPoolMultiplierValue;  // should we apply a per-pool multiplier?
@synthesize cachedWillApplyPerPoolBonusValue = m_cachedWillApplyPerPoolBonusValue;       // should we apply a per-pool bonus?
@synthesize cachedWillApplyPerPoolPenaltyValue = m_cachedWillApplyPerPoolPenaltyValue;     // should we apply a per-pool penalty?
@synthesize cachedPerPoolMultiplierValue = m_cachedPerPoolMultiplierValue;           // value for per-pool multiplier
@synthesize cachedPerPoolBonusValue = m_cachedPerPoolBonusValue;                // value for per-pool bonus
@synthesize cachedPerPoolPenaltyValue = m_cachedPerPoolPenaltyValue;              // value for per-pool penalty

/* rerolling */
@synthesize cachedWillRerollBelowValueForDice = m_cachedWillRerollBelowValueForDice;  // should we reroll dice below a given value?
@synthesize cachedWillRerollAboveValueForDice = m_cachedWillRerollAboveValueForDice;  // should we reroll dice above a given value?
@synthesize cachedValueBelowWhichToRerollDice = m_cachedValueBelowWhichToRerollDice;  // value below which to reroll dice
@synthesize cachedValueAboveWhichToRerollDice = m_cachedValueAboveWhichToRerollDice;  // value above which to reroll dice
@synthesize cachedRerollPrecedenceForDice = m_cachedRerollPrecedenceForDice;      // rerolling precedence for dice (i.e., before/after modifiers)
@synthesize cachedWillRerollBelowValueForPools = m_cachedWillRerollBelowValueForPools; // should we reroll pools below a given value?
@synthesize cachedWillRerollAboveValueForPools = m_cachedWillRerollAboveValueForPools; // should we reroll pools above a given value?
@synthesize cachedValueBelowWhichToRerollPools = m_cachedValueBelowWhichToRerollPools; // value below which to reroll pools
@synthesize cachedValueAboveWhichToRerollPools = m_cachedValueAboveWhichToRerollPools; // value above which to reroll pools
@synthesize cachedRerollPrecedenceForPools = m_cachedRerollPrecedenceForPools;     // rerolling precedence for pools (i.e., before/after modifiers)

/* drops */
@synthesize cachedWillDropLowestRolls = m_cachedWillDropLowestRolls;
@synthesize cachedWillDropHighestRolls = m_cachedWillDropHighestRolls;
@synthesize cachedNumberOfLowDrops = m_cachedNumberOfLowDrops;
@synthesize cachedNumberOfHighDrops = m_cachedNumberOfHighDrops;

+ (void)initialize {
	srandom(time(NULL));

	NSValueTransformer *vt;
	
	// used in enabling of rerolling precedence
	vt = [[DXIsNotZeroValueTransformer alloc] init];
	[NSValueTransformer setValueTransformer:vt forName:@"DXIsNotZero"];
	
	//vt = [[DXRollButtonTitleConverterVT alloc] init];
	//[NSValueTransformer setValueTransformer:vt forName:@"DXRollButtonTitleConverter"];
}

- (id)init {
	self = [super initWithWindowNibName:@"MainWindow"];
	if (self != nil) {
		// prepare list values
		NSString *path = [[NSBundle mainBundle] pathForResource:@"DefaultListValues" ofType:@"plist"];
		NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
		m_defaultSidesPerDie = [dict objectForKey:@"dieSidesComboBox"];
		m_defaultDicePerPool = [dict objectForKey:@"dieCountComboBox"];
		// end preparation of list values
		
		m_rollOperationQueue = [NSOperationQueue new];
		
		m_isRunningRoll = NO;
		m_willLogRolls = YES;
		m_rollsArray = [[NSArray alloc] init];
	
		// general paremeters
		m_numberOfSidesPerDie = 1;
		m_numberOfDicePerPool = 1;
		m_numberOfPoolsToRoll = 1;
	
		// settings aspects
		m_aspectControllers = nil;
		//m_aspectTabViewFadeContainer = nil;

		// modifiers
		m_cachedWillApplyPerDieMultiplierValue = NO;
		m_cachedWillApplyPerDieBonusValue = NO;
		m_cachedWillApplyPerDiePenaltyValue = NO;
		m_cachedPerDieMultiplierValue = 0;
		m_cachedPerDieBonusValue = 0;
		m_cachedPerDiePenaltyValue = 0;

		m_cachedWillApplyPerPoolMultiplierValue = NO;
		m_cachedWillApplyPerPoolBonusValue = NO;
		m_cachedWillApplyPerPoolPenaltyValue = NO;
		m_cachedPerPoolMultiplierValue = 0;
		m_cachedPerPoolBonusValue = 0;
		m_cachedPerPoolPenaltyValue = 0;

		// rerolling
		m_cachedWillRerollBelowValueForDice = NO;
		m_cachedWillRerollAboveValueForDice = NO;
		m_cachedValueBelowWhichToRerollDice = 0;
		m_cachedValueAboveWhichToRerollDice = 0;
		m_cachedRerollPrecedenceForDice = 0;
		
		m_cachedWillRerollBelowValueForPools = NO;
		m_cachedWillRerollAboveValueForPools = NO;
		m_cachedValueBelowWhichToRerollPools = 0;
		m_cachedValueAboveWhichToRerollPools = 0;
		m_cachedRerollPrecedenceForPools = 0;

		// drops
		m_cachedWillDropLowestRolls = NO;
		m_cachedWillDropHighestRolls = NO;
		m_cachedNumberOfLowDrops = 0;
		m_cachedNumberOfHighDrops = 0;
	}
	return self;
}

- (void)dealloc {    
	[m_rollOperationQueue release];
	m_rollOperationQueue = nil;
	
	[m_rollsArray release];
	m_rollsArray = nil;
	
	[super dealloc];
}

- (void)windowDidLoad {
	self.rollsTableView.spaceKeyAdds = NO;
	self.rollsTableView.enterKeyAdds = NO;
	self.rollsTableView.deleteKeyRemoves = NO;
	self.rollsTableView.spaceKeySendsDoubleAction = NO;
	self.rollsTableView.enterKeySendsDoubleAction = NO;
	
	[self prepareTabViewItems];
}

- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)anItem {
	BOOL isValid = YES;
	SEL action = [anItem action];
	
	if (action == @selector(startRunningRoll:)) {
		isValid = !self.isRunningRoll;
	}
	else if (action == @selector(stopRunningRoll:)) {
		isValid = self.isRunningRoll;
	}
	
	return isValid;
}

/*- (void)resetSettings {
	// general paremeters
	self.numberOfSidesPerDie = 6;
	self.numberOfDicePerPool = 1;
	self.numberOfPoolsToRoll = 1;
	
	// modifiers
	self.cachedWillApplyPerDieMultiplierValue = NO;
	self.cachedWillApplyPerDieBonusValue = NO;
	self.cachedWillApplyPerDiePenaltyValue = NO;
	self.cachedPerDieMultiplierValue = 0;
	self.cachedPerDieBonusValue = 0;
	self.cachedPerDiePenaltyValue = 0;
	
	self.cachedWillApplyPerPoolMultiplierValue = NO;
	self.cachedWillApplyPerPoolBonusValue = NO;
	self.cachedWillApplyPerPoolPenaltyValue = NO;
	self.cachedPerPoolMultiplierValue = 0;
	self.cachedPerPoolBonusValue = 0;
	self.cachedPerPoolPenaltyValue = 0;
	
	// rerolling
	self.cachedWillRerollBelowValueForDice = NO;
	self.cachedWillRerollAboveValueForDice = NO;
	self.cachedValueBelowWhichToRerollDice = 0;
	self.cachedValueAboveWhichToRerollDice = 0;
	self.cachedRerollPrecedenceForDice = 0;
	
	self.cachedWillRerollBelowValueForPools = NO;
	self.cachedWillRerollAboveValueForPools = NO;
	self.cachedValueBelowWhichToRerollPools = 0;
	self.cachedValueAboveWhichToRerollPools = 0;
	self.cachedRerollPrecedenceForPools = 0;
	
	// drops
	self.cachedWillDropLowestRolls = NO;
	self.cachedWillDropHighestRolls = NO;
	self.cachedNumberOfLowDrops = 0;
	self.cachedNumberOfHighDrops = 0;	
}*/

- (IBAction)startRunningRoll:(id)sender {
	if (!self.isRunningRoll) {
		[self toggleRunningRoll:sender];
	}
}

- (IBAction)stopRunningRoll:(id)sender {
	// might in the future interrupt logging; currently interrupts only rolling
	if (self.isRunningRoll) {
		[self toggleRunningRoll:sender];
	}
}

- (void)toggleRunningRoll:(id)sender {
	if (self.isRunningRoll) {
		// stop running roll
		
		NSArray *rollOps = [self.rollOperationQueue operations];
		for (NSOperation *op in rollOps) {
			[op removeObserver:self forKeyPath:@"isFinished"];        
		}
		
		[self.rollOperationQueue cancelAllOperations];

		self.isRunningRoll = NO;
		
	}
	else {
		// configure roll
		[self updateCachedRollSettings];
		
		NSArray *conflicts = [self determinedConflicts];
		if ([conflicts count] > 0) {
			[self displayConflictSheetWithConflicts:conflicts];
			return;
		}
		
		self.isRunningRoll = YES;
		
		// this will create an operation to generate our node structure
		DXRollOperation *rollOp = [DXRollOperation new];    // create a roll operation
		
		[rollOp addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
		
		rollOp.cachedNumberOfPoolsToRoll = self.numberOfPoolsToRoll;
		rollOp.cachedNumberOfSidesPerDie = self.numberOfSidesPerDie;
		rollOp.cachedNumberOfDicePerPool = self.numberOfDicePerPool;
		
		rollOp.cachedWillApplyPerDieMultiplierValue = self.cachedWillApplyPerDieMultiplierValue;
		rollOp.cachedWillApplyPerDieBonusValue = self.cachedWillApplyPerDieBonusValue;
		rollOp.cachedWillApplyPerDiePenaltyValue = self.cachedWillApplyPerDiePenaltyValue;
		rollOp.cachedPerDieMultiplierValue = self.cachedPerDieMultiplierValue;
		rollOp.cachedPerDieBonusValue = self.cachedPerDieBonusValue;
		rollOp.cachedPerDiePenaltyValue = self.cachedPerDiePenaltyValue;
		
		rollOp.cachedWillRerollBelowValueForDice = self.cachedWillRerollBelowValueForDice;
		rollOp.cachedWillRerollAboveValueForDice = self.cachedWillRerollAboveValueForDice;
		rollOp.cachedValueBelowWhichToRerollDice = self.cachedValueBelowWhichToRerollDice;
		rollOp.cachedValueAboveWhichToRerollDice = self.cachedValueAboveWhichToRerollDice;
		rollOp.cachedRerollPrecedenceForDice = self.cachedRerollPrecedenceForDice;
		
		
		rollOp.cachedWillRerollBelowValueForPools = self.cachedWillRerollBelowValueForPools;
		rollOp.cachedWillRerollAboveValueForPools = self.cachedWillRerollAboveValueForPools;
		rollOp.cachedValueBelowWhichToRerollPools = self.cachedValueBelowWhichToRerollPools;
		rollOp.cachedValueAboveWhichToRerollPools = self.cachedValueAboveWhichToRerollPools;
		
		rollOp.cachedWillApplyPerPoolMultiplierValue = self.cachedWillApplyPerPoolMultiplierValue;
		rollOp.cachedWillApplyPerPoolBonusValue = self.cachedWillApplyPerPoolBonusValue;
		rollOp.cachedWillApplyPerPoolPenaltyValue = self.cachedWillApplyPerPoolPenaltyValue;
		
		rollOp.cachedPerPoolMultiplierValue = self.cachedPerPoolMultiplierValue;
		rollOp.cachedPerPoolBonusValue = self.cachedPerPoolBonusValue;
		rollOp.cachedPerPoolPenaltyValue = self.cachedPerPoolPenaltyValue;
		
		rollOp.cachedWillDropLowestRolls = self.cachedWillDropLowestRolls;
		rollOp.cachedWillDropHighestRolls = self.cachedWillDropHighestRolls;
		rollOp.cachedNumberOfLowDrops = self.cachedNumberOfLowDrops;
		rollOp.cachedNumberOfHighDrops = self.cachedNumberOfHighDrops;
		rollOp.cachedRerollPrecedenceForPools = self.cachedRerollPrecedenceForPools;
				
		[self.rollOperationQueue addOperation:rollOp];   // add to queue (although it won't be processed until nodeOp completes)
	}
}

- (void)updateCachedRollSettings {
	DXAspectController *modifiersAspectController = [self.aspectControllers objectForKey:@"modifiers"];
	DXAspectController *rerollingAspectController = [self.aspectControllers objectForKey:@"rerolling"];
	DXAspectController *dropsAspectController = [self.aspectControllers objectForKey:@"drops"];


	/* modifiers */
	//NSDictionary *perDieModifiers = [modifiersAspectController dictionaryForModifiersUsingIdentifier:@"per-die"];
	DXModifierSettingsRepresentation *repObjForModifiers;
	
	repObjForModifiers = [modifiersAspectController itemRepresentedObjectForIdentifier:@"per-die"];
	self.cachedWillApplyPerDieBonusValue = repObjForModifiers.willApplyBonus;
	self.cachedWillApplyPerDiePenaltyValue = repObjForModifiers.willApplyPenalty;
	self.cachedWillApplyPerDieMultiplierValue = repObjForModifiers.willApplyMultiplier;
	
	self.cachedPerDieBonusValue = repObjForModifiers.valueForBonus;
	self.cachedPerDiePenaltyValue = repObjForModifiers.valueForPenalty;
	self.cachedPerDieMultiplierValue = repObjForModifiers.valueForMultiplier;

	//NSDictionary *perPoolModifiers = [modifiersAspectController dictionaryForModifiersUsingIdentifier:@"per-pool"];
	repObjForModifiers = [modifiersAspectController itemRepresentedObjectForIdentifier:@"per-pool"];
	self.cachedWillApplyPerPoolBonusValue = repObjForModifiers.willApplyBonus;
	self.cachedWillApplyPerPoolPenaltyValue = repObjForModifiers.willApplyPenalty;
	self.cachedWillApplyPerPoolMultiplierValue = repObjForModifiers.willApplyMultiplier;
	
	self.cachedPerPoolBonusValue = repObjForModifiers.valueForBonus;
	self.cachedPerPoolPenaltyValue = repObjForModifiers.valueForPenalty;
	self.cachedPerPoolMultiplierValue = repObjForModifiers.valueForMultiplier;
	
	/* rerolling */
	DXRerollSettingsRepresentation *repObjForRerolling;
	
	repObjForRerolling = [rerollingAspectController itemRepresentedObjectForIdentifier:@"dice"];
	
	self.cachedWillRerollBelowValueForDice = repObjForRerolling.willRerollBelowGivenValue;
	self.cachedWillRerollAboveValueForDice = repObjForRerolling.willRerollAboveGivenValue;
	self.cachedValueBelowWhichToRerollDice = repObjForRerolling.valueBelowWhichToReroll;
	self.cachedValueAboveWhichToRerollDice = repObjForRerolling.valueAboveWhichToReroll;
	self.cachedRerollPrecedenceForDice = repObjForRerolling.rerollingPrecedence;

	repObjForRerolling = [rerollingAspectController itemRepresentedObjectForIdentifier:@"pools"];
	
	self.cachedWillRerollBelowValueForPools = repObjForRerolling.willRerollBelowGivenValue;
	self.cachedWillRerollAboveValueForPools = repObjForRerolling.willRerollAboveGivenValue;
	self.cachedValueBelowWhichToRerollPools = repObjForRerolling.valueBelowWhichToReroll;
	self.cachedValueAboveWhichToRerollPools = repObjForRerolling.valueAboveWhichToReroll;
	self.cachedRerollPrecedenceForPools = repObjForRerolling.rerollingPrecedence;
	
	/* drops */
	DXDropSettingsRepresentation *repObjForDrops;
	
	repObjForDrops = [dropsAspectController itemRepresentedObjectForIdentifier:@"low-drops"];
	self.cachedWillDropLowestRolls = repObjForDrops.willDrop;
	self.cachedNumberOfLowDrops = repObjForDrops.dropQuantity;
	
	repObjForDrops = [dropsAspectController itemRepresentedObjectForIdentifier:@"high-drops"];
	self.cachedWillDropHighestRolls = repObjForDrops.willDrop;
	self.cachedNumberOfHighDrops = repObjForDrops.dropQuantity;
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([keyPath isEqualToString:@"isFinished"]/* && [[self.rollOperationQueue operations] containsObject:object]*/) {
		[object removeObserver:self forKeyPath:@"isFinished"];
		
		DXRollOperation *op = object;
		
		[self performSelectorOnMainThread:@selector(finishRoll:) withObject:op.cachedNode waitUntilDone:YES];
		self.isRunningRoll = NO;
	}
	else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)finishRoll:(NSTreeNode *)node {
	self.rollsArray = [node childNodes];
	if (self.willLogRolls) {
		[[NSNotificationCenter defaultCenter] postNotificationName:DXLogNodeNotificationName object:node];
	}
}

- (IBAction)configureForPercentileRoll:(id)sender {
	self.numberOfSidesPerDie = 100;
	self.numberOfDicePerPool = 1;
	self.numberOfPoolsToRoll = 1;
}

/*- (BOOL)validateSidesPerDie:(id *)ioValue error:(NSError **)outError {
	BOOL validated = YES;
	
	if (*ioValue != nil) {
		NSInteger value = [*ioValue integerValue];
		if (value <= 0 || value > 32767) {
			*outError = [self scalarValidationError];
			validated = NO;
		}
		else {
			*ioValue = [NSNumber numberWithInteger:value];
		}
	}
	else {
		*outError = [self scalarValidationError];
		validated = NO;
	}
	
	return validated;
}

- (BOOL)validateCountOfDice:(id *)ioValue error:(NSError **)outError {
	BOOL validated = YES;

	if (*ioValue != nil) {
		NSInteger value = [*ioValue integerValue];
		if (value <= 0 || value > 32767) {
			*outError = [self scalarValidationError];
			validated = NO;
		}
		else {
			*ioValue = [NSNumber numberWithInteger:value];
		}
	}
	else {
		*outError = [self scalarValidationError];
		validated = NO;
	}
	
	return validated;
}

- (BOOL)validateRollRepetitions:(id *)ioValue error:(NSError **)outError {
	BOOL validated = YES;

	if (*ioValue != nil) {
		NSInteger value = [*ioValue integerValue];
		if (value <= 0 || value > 32767) {
			*outError = [self scalarValidationError];
			validated = NO;
		}
		else {
			*ioValue = [NSNumber numberWithInteger:value];
		}
	}
	else {
		*outError = [self scalarValidationError];
		validated = NO;
	}
	
	return validated;
}

- (NSError *)scalarValidationError {
	NSString *errorString = NSLocalizedString(
		@"General parameters must be between 1 and 32767",
		@"validation: invalid general parameter error");
	NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
	NSError *error = [NSError errorWithDomain:NSCocoaErrorDomain
		code:NSFormattingError
		userInfo:userInfoDict];
		
	return error;
}*/

- (void)setNilValueForKey:(NSString *)key {
	if ([key isEqualToString:@"numberOfPoolsToRoll"]) {
		[super setValue:[NSNumber numberWithInteger:1] forKey:key];
	}
	else if ([key isEqualToString:@"numberOfDicePerPool"]) {
		[super setValue:[NSNumber numberWithInteger:1] forKey:key];
	}
	else if ([key isEqualToString:@"numberOfSidesPerDie"]) {
		[super setValue:[NSNumber numberWithInteger:1] forKey:key];
	}
	else {
		[super setNilValueForKey:key];
	}
}

- (IBAction)displaySettingsHelp:(id)sender {
	NSString *locBookName = [[NSBundle mainBundle] objectForInfoDictionaryKey: @"CFBundleHelpBookName"];
	[[NSHelpManager sharedHelpManager] openHelpAnchor:@"settings" inBook:locBookName];
}

- (void)prepareTabViewItems {
	// first, clear the tab view
	NSArray *tabViewItems = [self.aspectTabView tabViewItems];
	for (NSTabViewItem *tabViewItem in tabViewItems) {
		[self.aspectTabView removeTabViewItem:tabViewItem];
	}
	
	// read data from plists
	NSString *pathForSetupArray = [[NSBundle mainBundle] pathForResource:@"AspectSetup" ofType:@"plist"];
	NSArray *aspectArray = [NSArray arrayWithContentsOfFile:pathForSetupArray];
	
	// create blank temp dict
	NSMutableDictionary *aspectControllersTemp = [NSMutableDictionary dictionary];
	
	for (NSDictionary *dict in aspectArray) {
		NSString *nibName = [dict objectForKey:@"viewNibName"];
		NSString *identifier = [dict objectForKey:@"identifier"];
		NSString *label = [dict objectForKey:@"label"];
		NSString *className = [dict objectForKey:@"settingsRepresentationClass"];
		NSDictionary *settingsDict = [dict objectForKey:@"settingsDict"];
		NSArray *settingsArray = [dict objectForKey:@"settingsRepresentations"];
		
		//NSDictionary *settingsDict = [aspectDict objectForKey:identifier];
		
		DXAspectController *aspectController = [[DXAspectController alloc] initWithNibName:nibName];
		aspectController.identifier = identifier;
		aspectController.label = label;
		aspectController.settingsArray = settingsArray;
		aspectController.settingsRepresentationClassName = className;
		
		aspectController.settingsKeys = settingsDict;
		//[aspectController prepareSettings];
		[aspectControllersTemp setObject:aspectController forKey:identifier];
		
		// construct and insert the tab view item
		NSTabViewItem *tabViewItem = [[NSTabViewItem alloc] initWithIdentifier:identifier];
		[tabViewItem setView:aspectController.view];
		[tabViewItem setLabel:aspectController.localizedLabel];
		
		// add the tab view item to the existing tab view hierarchy
		[self.aspectTabView addTabViewItem:tabViewItem];
	}
	
	// move temp dict into property
	self.aspectControllers = aspectControllersTemp;
}

// implementing the following delegate method makes sense on the one hand, but isn't very user-friendly or user-expected
/*- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(NSInteger)rowIndex {
	return NO;
}*/

@end

@implementation DXMainWindowController (TableViewDataSourceMethods)

#define DL_LINE_NUMBER_KEY @"lineNumber"

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
	return 0;	
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	id retVal = nil;
	if ([[aTableColumn identifier] isEqualToString:DL_LINE_NUMBER_KEY]) {
		NSNumber *number = [NSNumber numberWithInteger:rowIndex + 1];
		retVal = number;
	}
	return retVal;
}

@end

@implementation DXMainWindowController (RollingAlerts)

/*- (void)displayAlertWithMessageText:(NSString *)messageText andInformativeText:(NSString *)informativeText {
	[self interruptActivity:self];

	NSAlert *alert = [NSAlert alertWithMessageText:NSLocalizedString(messageText, @"Alert")
			defaultButton:nil   // will make a localized "OK"...
			alternateButton:nil
			otherButton:nil
			informativeTextWithFormat:NSLocalizedString(informativeText, @"Information")];
	[alert setAlertStyle:NSInformationalAlertStyle];
	[alert beginSheetModalForWindow:window modalDelegate:nil didEndSelector:NULL contextInfo:nil];
}*/

- (void)displayConflictSheetWithConflicts:(NSArray *)conflicts {
	[self stopRunningRoll:nil];
	[[NSNotificationCenter defaultCenter] postNotificationName:DXNewConflictNotificationName object:conflicts];
}

- (NSArray *)determinedConflicts {
	NSMutableSet *strings = [NSMutableSet set];

	//BOOL success = YES;
	
	//[self runTestTest];
		
	
	

	if (![self testForPoolsOverflow]) {
		[strings addObject:@"DXPoolsOverflow"];
	}

	if (![self testForPoolsUnderflow]) {
		[strings addObject:@"DXPoolsUnderflow"];
	}
	
	if (![self testForDropsUnderflow]) {
		[strings addObject:@"DXDropsUnderflow"];
	}
	
	if (![self testForDropsOverflow]) {
		[strings addObject:@"DXDropsOverflow"];
	}

	if (![self testForModifiersUnderflow]) {
		[strings addObject:@"DXModifiersUnderflow"];
	}
	
	if (![self testForModifiersOverflow]) {
		[strings addObject:@"DXModifiersOverflow"];
	}


	if (![self testForSidesUnderflow]) {
		[strings addObject:@"DXSidesUnderflow"];
	}
	
	if (![self testForCountUnderflow]) {
		[strings addObject:@"DXCountUnderflow"];
	}
	
	if (![self testForCountOverflow]) {
		[strings addObject:@"DXCountOverflow"];
	}

	if (![self testForSidesOverflow]) {
		[strings addObject:@"DXSidesOverflow"];
	}

	if (![self testForResultOverflow]) {
		[strings addObject:@"DXResultOverflow"];
	}
	
	if (![self testForResultUnderflow]) {
		[strings addObject:@"DXResultUnderflow"];
	}

	if (![self testForMoreDropsThanDice]) {    // are we dropping too many?
		[strings addObject:@"DXConflictTooManyDrops"];
	}

//    if (![self testForDropsWithPercentile]) {                      // are we dropping dice during a percentile roll?
//        [strings addObject:@"DXConflictNoPercentileDrops"];
//    }
	
	if (![self testForRerollingCategoryCount]) {                   // is more than one rerolling category enabled?
		[strings addObject:@"DXConflictNoMoreThanOneRerollCategory"];
	}
	
//    if (![self testForPercentileDieCountOverrun]) {               // are we rolling too many dice in percentile mode?
//        [strings addObject:@"DXConflictPercentileDieLimit"];
//    }

//    if (![self testForPercentileDieModifierOverrun]) {             // are we rolling with per-die modifiers in percentile mode?
//        [strings addObject:@"DXConflictPercentileNoPerDieModifiers"];
//    }

	/*if (![self testForPercentileRollWithNonPercentileReroll]) {    // are we rolling as percentile but with normal rerolling options set?
		[strings addObject:@"DXConflictNoPercentileRollWithStandardSettings"];
	}

	if (![self testForNonPercentileRollWithPercentileReroll]) {    // are we rolling as normal but with percentile rerolling options set?
		[strings addObject:@"DXConflictNoStandardRollWithPercentileSettings"];
	}*/

	if (![self testForRerollRangeOverlapIndividual]) {
		[strings addObject:@"DXConflictNoOverlapInRerollThresholds"];
	}

	/*if (![self testForRerollRangeOverlapPercentile]) {
		[strings addObject:@"DXConflictNoOverlapInRerollThresholds"];
	}*/

	if (![self testForRerollRangeOverlapTotal]) {
		[strings addObject:@"DXConflictNoOverlapInRerollThresholds"];
	}

	
	if (![self testForRerollAboveValueBelowMinimumInIndividual]) {
		[strings addObject:@"DXConflictHiThreshBelowMin"];
	}

	if (![self testForRerollBelowValueAboveMaximumInIndividual]) {
		[strings addObject:@"DXConflictLoThreshAboveMax"];
	}

	if (![self testForRerollBelowValueBelowMinimumInIndividual]) {
		[strings addObject:@"DXConflictLoThreshBelowMin"];
	}

	if (![self testForRerollAboveValueAboveMaximumInIndividual]) {
		[strings addObject:@"DXConflictHiThreshAboveMax"];
	}
	
	// even more experimental....
	if (![self testForRerollAboveValueBelowMinimumInTotal]) {
		[strings addObject:@"DXConflictHiThreshBelowMin"];
	}

	if (![self testForRerollBelowValueAboveMaximumInTotal]) {
		[strings addObject:@"DXConflictLoThreshAboveMax"];
	}

	if (![self testForRerollBelowValueBelowMinimumInTotal]) {
		[strings addObject:@"DXConflictLoThreshBelowMin"];
	}

	if (![self testForRerollAboveValueAboveMaximumInTotal]) {
		[strings addObject:@"DXConflictHiThreshAboveMax"];
	}
	
	/*if ([strings count] > 0) {
		success = NO;
	}*/

	return [strings allObjects];
}

@end

//CGFloat h = 0;

//- (IBAction)showSettingsWindow:(id)sender {
//return;
	//[self.aspectTabView setHidden:!([self.aspectTabView isHidden])];
	
/*
NSRect newFrame = [self.window frame];

	NSRect startFrame;
	NSRect endFrame;
	
	NSString *effect;
	if ([self.aspectTabView isHidden]) {
		startFrame = [self.aspectTabView frame];
		endFrame = NSMakeRect(NSMinX(startFrame), NSMinY([self.aspectTabViewFadeContainer frame]), NSWidth(startFrame), NSHeight([self.aspectTabViewFadeContainer frame]) - 11);
		effect = NSViewAnimationFadeInEffect;
		newFrame.size.height += h;
		newFrame.origin.y -= h;
		h = 0;
	}
	else {
		startFrame = [self.aspectTabView frame];
		endFrame = NSMakeRect(NSMinX(startFrame), NSMaxY(startFrame), NSWidth(startFrame), 0);
		effect = NSViewAnimationFadeOutEffect;
		h = NSHeight([self.aspectTabViewFadeContainer frame]) - 11;
		newFrame.size.height -= h;
		newFrame.origin.y += h;
	}
	
	
	NSValue *startFrameValue = [NSValue valueWithRect:startFrame];    
	NSValue *endFrameValue = [NSValue valueWithRect:endFrame];
	
	NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
		self.aspectTabView, NSViewAnimationTargetKey,
		startFrameValue, NSViewAnimationStartFrameKey,
		endFrameValue, NSViewAnimationEndFrameKey,
		effect, NSViewAnimationEffectKey,
		nil];
	
	NSArray *array = [NSArray arrayWithObject:dict];

	NSViewAnimation *anim = [[NSViewAnimation alloc] initWithViewAnimations:array];

if ([self.aspectTabView isHidden]) {
	[anim startAnimation];
	//[self.aspectTabView setHidden:NO];
}
else {
	[anim startAnimation];
}
[self.window setFrame:newFrame display:YES animate:YES];
	
	//[self.settingsWindowController showWindow:sender];
	*/
//}


@implementation DXMainWindowController (MemorySlots)

- (void)loadFirstSlotFromDefaults {
	[self loadValuesFromDefaultsWithTag:DXPreferencesMemorySlotMinimum];
	NSDictionary *aspectControllers = self.aspectControllers;
	for (id key in aspectControllers) {
		DXAspectController *aspectController = [aspectControllers objectForKey:key];
		[aspectController loadValuesFromDefaultsWithTag:DXPreferencesMemorySlotMinimum];
	}
}

- (void)saveFirstSlotToDefaults {
	[self saveValuesToDefaultsWithTag:DXPreferencesMemorySlotMinimum];
	NSDictionary *aspectControllers = self.aspectControllers;
	for (id key in aspectControllers) {
		DXAspectController *aspectController = [aspectControllers objectForKey:key];
		[aspectController saveValuesToDefaultsWithTag:DXPreferencesMemorySlotMinimum];
	}
}

/*- (void)loadAllValuesFromDefaults {
 [self loadValuesFromDefaults];
 NSArray *controllers = [self.aspectControllers allValues];
 [controllers makeObjectsPerformSelector:@selector(loadValuesFromDefaults) withObject:nil];
 }
 
 - (void)saveAllValuesToDefaults {
 [self saveValuesToDefaults];
 NSArray *controllers = [self.aspectControllers allValues];
 [controllers makeObjectsPerformSelector:@selector(saveValuesToDefaults) withObject:nil];
 }*/

/**
 Returns the support folder for the application, used to store the memory slot
 store file.  This code uses a folder named "Polymatic" for
 the content, either in the NSApplicationSupportDirectory location or (if the
 former cannot be found), the system's temporary directory.
 */

/*- (NSString *)applicationSupportFolder {
 NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
 NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : NSTemporaryDirectory();
 return [basePath stringByAppendingPathComponent:@"Polymatic"];
 }*/



/*- (IBAction)resetSettings:(id)sender {
 NSAlert *alert = [NSAlert alertWithMessageText:NSLocalizedString(@"DXResetSettingsAreYouSureMessageText", @"DXResetSettingsAreYouSureMessageText")
 defaultButton:@"OK"
 alternateButton:@"Cancel"
 otherButton:nil
 informativeTextWithFormat:NSLocalizedString(@"DXResetSettingsAreYouSureInformativeText", @"DXResetSettingsAreYouSureInformativeText")];
 [alert setAlertStyle:NSWarningAlertStyle];  // NSCriticalAlertStyle
 [alert beginSheetModalForWindow:self.window modalDelegate:self
 didEndSelector:@selector(didEndResetSettingsSheet:returnCode:contextInfo:) contextInfo:NULL];  // contextInfo:
 }
 
 - (void)didEndResetSettingsSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
 if (returnCode == NSOKButton) {
 
 // reset results and log
 //self.rolls = [NSArray array];
 //[self.logWindowController clearNodes];
 
 
 // remove all defaults that are relevant
 
 //[NSUserDefaults resetStandardUserDefaults];   // [todo] can I make use of this? [am]
 
 [self.preferencesWindowController resetDefaults];
 
 [self loadAllValuesFromDefaults];
 }
 }*/

- (IBAction)saveIntoMemorySlots:(id)sender {
	if (sender == self.memorySlotSaveSegmentedControl) {
		NSDictionary *aspectControllers = self.aspectControllers;
		for (id key in aspectControllers) {
			DXAspectController *aspectController = [aspectControllers objectForKey:key];
			// the tag matches the slot number; 1 for segment 0 (labeled 1), 2 for segment 1 (labeled 2), etc.
			NSInteger tag = [[sender cell] tagForSegment:[sender selectedSegment]];
				
			if (tag >= DXPreferencesMemorySlotMinimum && tag <= DXPreferencesMemorySlotMaximum) {
				[self saveValuesToDefaultsWithTag:tag];
				[aspectController saveValuesToDefaultsWithTag:tag];		
			}
		}
	}
}

- (IBAction)loadFromMemorySlots:(id)sender {
	if (sender == self.memorySlotLoadSegmentedControl) {
		NSDictionary *aspectControllers = self.aspectControllers;
		for (id key in aspectControllers) {
			DXAspectController *aspectController = [aspectControllers objectForKey:key];
			// the tag matches the slot number; 1 for segment 0 (labeled 1), 2 for segment 1 (labeled 2), etc.
			NSInteger tag = [[sender cell] tagForSegment:[sender selectedSegment]];
			
			if (tag >= DXPreferencesMemorySlotMinimum && tag <= DXPreferencesMemorySlotMaximum) {
				[self loadValuesFromDefaultsWithTag:tag];
				[aspectController loadValuesFromDefaultsWithTag:tag];
			}
		}
	}
}

- (IBAction)resetSlots:(id)sender {
	if ([[NSUserDefaults standardUserDefaults] boolForKey:DXPreferencesWarnBeforeResettingSlotsKey]) {
		// sanity-check
		if (![self.window isVisible]) {
			[self showWindow:sender];
		}
		
		NSBeep();
		
		NSAlert *alert = [[[NSAlert alloc] init] autorelease];
		[alert addButtonWithTitle:NSLocalizedString(@"OK", @"OK")];
		[alert addButtonWithTitle:NSLocalizedString(@"Cancel", @"Cancel")];
		[alert setMessageText:NSLocalizedString(@"DXResetSlotsAreYouSureMessageText", @"DXResetSlotsAreYouSureMessageText")];
		[alert setInformativeText:NSLocalizedString(@"DXResetSlotsAreYouSureInformativeText", @"DXResetSlotsAreYouSureInformativeText")];
		[alert setAlertStyle:NSInformationalAlertStyle];
		
		[alert beginSheetModalForWindow:self.window
						  modalDelegate:self
						 didEndSelector:@selector(didEndResetSlotsSheet:returnCode:contextInfo:)
							contextInfo:(void *)sender];
	} else {
		[self finishResettingSlots];
	}
}

- (void)didEndResetSlotsSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
	if (returnCode == NSAlertFirstButtonReturn) {
		[self finishResettingSlots];
	}
}

- (void)finishResettingSlots {
	// reset the slots
	[[NSNotificationCenter defaultCenter] postNotificationName:DXPreferencesResetSlotsNotificationName object:nil];
	
	//[self resetSettings];
	// now we'll load values from defaults
	[self loadFirstSlotFromDefaults];	
}

/*- (void)loadValuesFromDefaults {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	
	self.numberOfSidesPerDie = [userDefaults integerForKey:DXNumberOfSidesPerDieKey];
	self.numberOfDicePerPool = [userDefaults integerForKey:DXNumberOfDicePerPoolKey];
	self.numberOfPoolsToRoll = [userDefaults integerForKey:DXNumberOfPoolsToRollKey];
	
	self.willLogRolls = [userDefaults boolForKey:DXWillLogRollsKey];
}

- (void)saveValuesToDefaults {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

	[userDefaults setInteger:self.numberOfSidesPerDie forKey:DXNumberOfSidesPerDieKey];
	[userDefaults setInteger:self.numberOfDicePerPool forKey:DXNumberOfDicePerPoolKey]; 
	[userDefaults setInteger:self.numberOfPoolsToRoll forKey:DXNumberOfPoolsToRollKey];
	
	[userDefaults setBool:self.willLogRolls forKey:DXWillLogRollsKey];
}*/

- (void)loadValuesFromDefaultsWithTag:(NSInteger)tag {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSString *string = [DXPreferencesWindowController suffixStringForSlotNumbered:tag];
	
	self.numberOfSidesPerDie = [userDefaults integerForKey:[DXNumberOfSidesPerDieKey stringByAppendingString:string]];
	self.numberOfDicePerPool = [userDefaults integerForKey:[DXNumberOfDicePerPoolKey stringByAppendingString:string]];
	self.numberOfPoolsToRoll = [userDefaults integerForKey:[DXNumberOfPoolsToRollKey stringByAppendingString:string]];
	
	self.willLogRolls = [userDefaults boolForKey:[DXWillLogRollsKey stringByAppendingString:string]];
}

- (void)saveValuesToDefaultsWithTag:(NSInteger)tag {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSString *string = [DXPreferencesWindowController suffixStringForSlotNumbered:tag];
	
	[userDefaults setInteger:self.numberOfSidesPerDie forKey:[DXNumberOfSidesPerDieKey stringByAppendingString:string]];
	[userDefaults setInteger:self.numberOfDicePerPool forKey:[DXNumberOfDicePerPoolKey stringByAppendingString:string]]; 
	[userDefaults setInteger:self.numberOfPoolsToRoll forKey:[DXNumberOfPoolsToRollKey stringByAppendingString:string]];
	
	[userDefaults setBool:self.willLogRolls forKey:[DXWillLogRollsKey stringByAppendingString:string]];
}

@end


/*@interface DXtitleForRollButtonTransformer: NSValueTransformer {}
@end
@implementation DXtitleForRollButtonTransformer
+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	return (value == nil) ? nil : NSStringFromClass([value class]);
}
@end*/

// this value transformer is used to determine whether the tag of the
//  selected partition scheme, in advanced mode, is equal to zero -- "subset"
@implementation DXIsNotZeroValueTransformer

+ (Class)transformedValueClass { return [NSNumber class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	id retVal = nil;
	if (value) {
		BOOL b = ([value integerValue] != 0) ? YES : NO;
		retVal = [NSNumber numberWithBool:b];
	}
	return retVal;
}

@end

/*@implementation DXRollButtonTitleConverterVT

+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	id retVal = nil;
	if (value) {
		BOOL b = [value boolValue];
		if (!b) {
			retVal = NSLocalizedString(@"Roll", @"Roll");
		}
		else {
			retVal = NSLocalizedString(@"Stop", @"Stop");
		}
	}
	return retVal;
}

@end
*/