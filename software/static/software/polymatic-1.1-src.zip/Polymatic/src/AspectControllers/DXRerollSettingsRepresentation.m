//
//  DXRerollSettingsRepresentation.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXRerollSettingsRepresentation.h"


@implementation DXRerollSettingsRepresentation

@synthesize rerollingPrecedence = m_rerollingPrecedence;
@synthesize willRerollBelowGivenValue = m_willRerollBelowGivenValue;
@synthesize willRerollAboveGivenValue = m_willRerollAboveGivenValue;
@synthesize valueBelowWhichToReroll = m_valueBelowWhichToReroll;
@synthesize valueAboveWhichToReroll = m_valueAboveWhichToReroll;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_rerollingPrecedence = 0;
        m_willRerollBelowGivenValue = NO;
        m_willRerollAboveGivenValue = NO;
        m_valueBelowWhichToReroll = 0;
        m_valueAboveWhichToReroll = 0;
    }
    return self;
}

- (void)setNilValueForKey:(NSString *)key {
    if ([key isEqualToString:@"valueBelowWhichToReroll"]) {
        [super setValue:[NSNumber numberWithInteger:0] forKey:key];
    }
    else if ([key isEqualToString:@"valueAboveWhichToReroll"]) {
        [super setValue:[NSNumber numberWithInteger:0] forKey:key];
    }
    else {
        [super setNilValueForKey:key];
    }
}

/*- (BOOL)validateValueBelowWhichToReroll:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;
    
    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value < (-32767) || value > 32767) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (BOOL)validateValueAboveWhichToReroll:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;

    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value < (-32767) || value > 32767) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (NSError *)scalarValidationError {
    NSString *errorString = NSLocalizedString(
        @"Reroll target numbers must be between -32767 and +32767",
        @"validation: invalid target number error");
    NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
    NSError *error = [NSError errorWithDomain:NSCocoaErrorDomain
        code:NSFormattingError
        userInfo:userInfoDict];
        
    return error;
}*/

@end
