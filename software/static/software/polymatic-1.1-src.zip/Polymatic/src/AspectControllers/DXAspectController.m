//
//  DXAspectController.m
//  Polymatic
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright Andrew Merenbach 2002-2008 2007 Andrew Merenbach. All rights reserved.
//

#import "DXAspectController.h"
#import "DXSettingsRepresentation.h"
#import "DXPreferencesWindowController.h"

//NSString *DXDoubleSpace = @"  ";


@implementation DXAspectController

@synthesize aspectCollectionView = m_aspectCollectionView;
@synthesize settingsArray = m_settingsArray;
@synthesize label = m_label;
@synthesize identifier = m_identifier;
@synthesize settingsRepresentationClassName = m_settingsRepresentationClassName;
@synthesize settingsKeys = m_settingsKeys;
@synthesize aspectArray = m_aspectArray;
@dynamic localizedLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nil];
    if (self != nil) {
        m_settingsArray = nil;
        m_identifier = nil;
        m_label = nil;
		m_aspectArray = [[NSArray alloc] init];
    }
    return self;
}

- (void)dealloc {
	[m_aspectArray release];
	m_aspectArray = nil;
	
	[super dealloc];
}

- (void)awakeFromNib {
    [self prepareSettings];
}

- (void)prepareSettings {
    NSString *className = self.settingsRepresentationClassName;
    Class class = NSClassFromString(className);
    
	NSMutableArray *aspectArrayTemp = [NSMutableArray array];
	
    for (NSDictionary *dict in self.settingsArray) {
        DXSettingsRepresentation *rep = [[[class alloc] init] autorelease];
        rep.identifier = [dict objectForKey:@"identifier"];
        rep.boxTitle = [dict objectForKey:@"label"];
        
        (void)[self.aspectCollectionView newItemForRepresentedObject:rep];
        
        [aspectArrayTemp addObject:rep];
    }
	
	self.aspectArray = aspectArrayTemp;
}

- (NSString *)localizedLabel {
    return NSLocalizedString(self.label, self.label);
}

/*- (void)loadValuesFromDefaults {
    NSDictionary *theDict = self.settingsKeys;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSArray *arrObj = self.aspectArray;
    for (DXSettingsRepresentation *repObjItem in arrObj) {
        NSString *identifier = repObjItem.identifier;
        NSDictionary *keysDict = [theDict objectForKey:identifier];
            
        for (id theKey in keysDict) {
            id dictKeyValue = [keysDict objectForKey:theKey];
            id theValue = [userDefaults objectForKey:dictKeyValue];
            [repObjItem setValue:theValue forKey:theKey];
        }
    }
}

- (void)saveValuesToDefaults {
    NSDictionary *theDict = self.settingsKeys;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSArray *arrObj = self.aspectArray;
    for (DXSettingsRepresentation *repObjItem in arrObj) {
        NSString *identifier = repObjItem.identifier;
        NSDictionary *keysDict = [theDict objectForKey:identifier];
            
        for (id theKey in keysDict) {
            id theValue = [repObjItem valueForKey:theKey];
            id dictKeyValue = [keysDict objectForKey:theKey];
            [userDefaults setObject:theValue forKey:dictKeyValue];
        }
    }
}*/

- (void)loadValuesFromDefaultsWithTag:(NSInteger)tag {
    NSDictionary *theDict = self.settingsKeys;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSString *string = [DXPreferencesWindowController suffixStringForSlotNumbered:tag];

    NSArray *arrObj = self.aspectArray;
    for (DXSettingsRepresentation *repObjItem in arrObj) {
        NSString *identifier = repObjItem.identifier;
        NSDictionary *keysDict = [theDict objectForKey:identifier];
            
        for (id theKey in keysDict) {
            id dictKeyValue = [keysDict objectForKey:theKey];
			NSString *prefKey = [dictKeyValue stringByAppendingString:string];
            id theValue = [userDefaults objectForKey:prefKey];
			[repObjItem setValue:theValue forKey:theKey];
        }
    }
}

- (void)saveValuesToDefaultsWithTag:(NSInteger)tag {
    NSDictionary *theDict = self.settingsKeys;
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

    NSString *string = [DXPreferencesWindowController suffixStringForSlotNumbered:tag];
	
    NSArray *arrObj = self.aspectArray;
    for (DXSettingsRepresentation *repObjItem in arrObj) {
        NSString *identifier = repObjItem.identifier;
        NSDictionary *keysDict = [theDict objectForKey:identifier];
		
        for (id theKey in keysDict) {
            id theValue = [repObjItem valueForKey:theKey];
            id dictKeyValue = [keysDict objectForKey:theKey];
			NSString *newKey = [dictKeyValue stringByAppendingString:string];
            [userDefaults setObject:theValue forKey:newKey];
        }
    }
}

- (id)itemRepresentedObjectForIdentifier:(NSString *)identifier {
    id theObj = nil;
    
    NSArray *reps = self.aspectArray;
    for (DXSettingsRepresentation *rep in reps) {
        if ([rep.identifier isEqualToString:identifier]) {
            theObj = rep;
            break;
        }
    }
    
    return theObj;
}

@end

