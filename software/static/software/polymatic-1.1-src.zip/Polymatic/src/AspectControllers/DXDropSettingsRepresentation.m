//
//  DXDropSettingsRepresentation.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/27/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXDropSettingsRepresentation.h"


@implementation DXDropSettingsRepresentation

@synthesize willDrop = m_willDrop;
@synthesize dropQuantity = m_dropQuantity;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_willDrop = NO;
        m_dropQuantity = 0;
    }
    return self;
}

- (void)setNilValueForKey:(NSString *)key {
    if ([key isEqualToString:@"dropQuantity"]) {
        [super setValue:[NSNumber numberWithInteger:0] forKey:key];
    }
    else {
        [super setNilValueForKey:key];
    }
}


/*- (BOOL)validateDropQuantity:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;

    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value <= 0) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (NSError *)scalarValidationError {
    NSString *errorString = NSLocalizedString(
        @"Drop counts must be greater than or equal to zero",
        @"validation: invalid drops error");
    NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
    NSError *error = [NSError errorWithDomain:NSCocoaErrorDomain
        code:NSFormattingError
        userInfo:userInfoDict];
        
    return error;
}*/

@end
