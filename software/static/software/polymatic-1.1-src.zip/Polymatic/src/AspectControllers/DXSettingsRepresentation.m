//
//  DXSettingsRepresentation.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXSettingsRepresentation.h"


@implementation DXSettingsRepresentation

@synthesize identifier = m_identifierString;
@synthesize boxTitle = m_boxTitleString;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_identifierString = [[NSString alloc] initWithString:@""];
        m_boxTitleString = [[NSString alloc] initWithString:@""];
    }
    return self;
}

- (void)dealloc {
    [m_identifierString release];
    m_identifierString = nil;
    
    [m_boxTitleString release];
    m_boxTitleString = nil;
    
    [super dealloc];
}

- (void)setNilValueForKey:(NSString *)key {
    [self setValue:[NSNumber numberWithInteger:0] forKey:key];
}

@end
