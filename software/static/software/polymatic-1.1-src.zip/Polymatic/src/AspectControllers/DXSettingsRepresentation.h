//
//  DXSettingsRepresentation.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface DXSettingsRepresentation : NSObject {
    NSString *m_identifierString;
    NSString *m_boxTitleString;
}

@property (copy, readwrite) NSString *identifier;
@property (copy, readwrite) NSString *boxTitle;

- (id)init;
- (void)dealloc;
- (void)setNilValueForKey:(NSString *)key;

@end
