//
//  DXDropSettingsRepresentation.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/27/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXSettingsRepresentation.h"


@interface DXDropSettingsRepresentation : DXSettingsRepresentation {
    BOOL m_willDrop;
    NSInteger m_dropQuantity;
}

@property (assign, readwrite) BOOL willDrop;
@property (assign, readwrite) NSInteger dropQuantity;

- (id)init;

@end
