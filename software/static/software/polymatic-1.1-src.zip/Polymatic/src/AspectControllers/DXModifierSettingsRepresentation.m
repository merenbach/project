//
//  DXModifierSettingsRepresentation.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXModifierSettingsRepresentation.h"


@implementation DXModifierSettingsRepresentation

@synthesize willApplyMultiplier = m_willApplyMultiplier;
@synthesize willApplyBonus = m_willApplyBonus;
@synthesize willApplyPenalty = m_willApplyPenalty;
@synthesize valueForMultiplier = m_valueForMultiplier;
@synthesize valueForBonus = m_valueForBonus;
@synthesize valueForPenalty = m_valueForPenalty;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_willApplyBonus = NO;
        m_willApplyPenalty = NO;
        m_willApplyMultiplier = NO;
        
        m_valueForBonus = 0;
        m_valueForPenalty = 0;
        m_valueForMultiplier = 0;
    }
    return self;
}

- (void)setNilValueForKey:(NSString *)key {
    if ([key isEqualToString:@"valueForMultiplier"]) {
        [super setValue:[NSNumber numberWithInteger:1] forKey:key];
    }
    else if ([key isEqualToString:@"valueForPenalty"]) {
        [super setValue:[NSNumber numberWithInteger:0] forKey:key];
    }
    else if ([key isEqualToString:@"valueForBonus"]) {
        [super setValue:[NSNumber numberWithInteger:0] forKey:key];
    }
    else {
        [super setNilValueForKey:key];
    }
}

/*- (BOOL)validateValueForBonus:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;

    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value <= 0 || value > 32767) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (BOOL)validateValueForPenalty:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;

    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value <= 0 || value > 32767) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (BOOL)validateValueForMultiplier:(id *)ioValue error:(NSError **)outError {
    BOOL validated = YES;

    if (*ioValue != nil) {
        NSInteger value = [*ioValue integerValue];
        if (value <= 0 || value > 32767) {
            *outError = [self scalarValidationError];
            validated = NO;
        }
        else {
            *ioValue = [NSNumber numberWithInteger:value];
        }
    }
    else {
        *outError = [self scalarValidationError];
        validated = NO;
    }
    
    return validated;
}

- (NSError *)scalarValidationError {
    NSString *errorString = NSLocalizedString(
        @"Modifiers must be between 1 and 32767",
        @"validation: invalid modifier error");
    NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
    NSError *error = [NSError errorWithDomain:NSCocoaErrorDomain
        code:NSFormattingError
        userInfo:userInfoDict];
        
    return error;
}

- (NSError *)scalarValidationOverflowError {
    NSString *errorString = NSLocalizedString(
        @"Modifiers must be less than +32767",
        @"validation: invalid modifier error");
    NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
    NSError *error = [NSError errorWithDomain:NSCocoaErrorDomain
        code:NSFormattingError
        userInfo:userInfoDict];
        
    return error;
}*/

@end
