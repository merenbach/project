//
//  DXRerollSettingsRepresentation.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXSettingsRepresentation.h"


@interface DXRerollSettingsRepresentation : DXSettingsRepresentation {
    NSInteger m_rerollingPrecedence;
    BOOL m_willRerollBelowGivenValue;
    BOOL m_willRerollAboveGivenValue;
    NSInteger m_valueBelowWhichToReroll;
    NSInteger m_valueAboveWhichToReroll;
}

@property (assign, readwrite) NSInteger rerollingPrecedence;
@property (assign, readwrite) BOOL willRerollBelowGivenValue;
@property (assign, readwrite) BOOL willRerollAboveGivenValue;
@property (assign, readwrite) NSInteger valueBelowWhichToReroll;
@property (assign, readwrite) NSInteger valueAboveWhichToReroll;

- (id)init;

@end
