//
//  DXAspectController.h
//  Polymatic
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright Andrew Merenbach 2002-2008 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//extern NSString *DXDoubleSpace;


@interface DXAspectController : NSViewController {
    NSCollectionView *m_aspectCollectionView;
    
    NSArray *m_settingsArray;
    
    NSString *m_label;
    NSString *m_identifier;
    NSString *m_settingsRepresentationClassName;
    
    NSDictionary *m_settingsKeys;

	NSArray *m_aspectArray;
}

@property (assign) IBOutlet NSCollectionView *aspectCollectionView;
@property (copy, readwrite) NSArray *settingsArray;
@property (copy, readwrite) NSString *label;
@property (copy, readwrite) NSString *identifier;
@property (copy, readwrite) NSString *settingsRepresentationClassName;
@property (copy, readwrite) NSDictionary *settingsKeys;
@property (copy, readwrite) NSArray *aspectArray;
@property (readonly) NSString *localizedLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil;

- (void)prepareSettings;

/*- (void)loadValuesFromDefaults;
- (void)saveValuesToDefaults;*/

- (void)loadValuesFromDefaultsWithTag:(NSInteger)tag;	// is this a kludge?
- (void)saveValuesToDefaultsWithTag:(NSInteger)tag;		// is this a kludge?

//- (void)setNilValueForKey:(NSString *)key;
- (id)itemRepresentedObjectForIdentifier:(NSString *)identifier;

@end
