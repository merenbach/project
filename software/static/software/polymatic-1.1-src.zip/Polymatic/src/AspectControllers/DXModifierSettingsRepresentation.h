//
//  DXModifierSettingsRepresentation.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/24/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXSettingsRepresentation.h"


@interface DXModifierSettingsRepresentation : DXSettingsRepresentation {
    BOOL m_willApplyMultiplier;
    BOOL m_willApplyBonus;
    BOOL m_willApplyPenalty;
    
    NSInteger m_valueForMultiplier;
    NSInteger m_valueForBonus;
    NSInteger m_valueForPenalty;
}

@property (assign, readwrite) BOOL willApplyMultiplier;
@property (assign, readwrite) BOOL willApplyBonus;
@property (assign, readwrite) BOOL willApplyPenalty;
@property (assign, readwrite) NSInteger valueForMultiplier;
@property (assign, readwrite) NSInteger valueForBonus;
@property (assign, readwrite) NSInteger valueForPenalty;

- (id)init;

@end
