//
//  DXRollOperation.m
//  Polymatic
//
//  Created by Andrew Merenbach on 3/25/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXRollOperation.h"

#import "DXRoll.h"
#import "DXGroup.h"
#import "DXPool.h"
#import "DXDie.h"


@implementation DXRollOperation

@synthesize cachedNode = m_cachedNode;
@synthesize cachedNumberOfPoolsToRoll = m_cachedNumberOfPoolsToRoll;

@synthesize cachedNumberOfSidesPerDie = m_cachedNumberOfSidesPerDie;
@synthesize cachedNumberOfDicePerPool = m_cachedNumberOfDicePerPool;

@synthesize cachedWillApplyPerDieMultiplierValue = m_cachedWillApplyPerDieMultiplierValue;
@synthesize cachedWillApplyPerDieBonusValue = m_cachedWillApplyPerDieBonusValue;
@synthesize cachedWillApplyPerDiePenaltyValue = m_cachedWillApplyPerDiePenaltyValue;
@synthesize cachedPerDieMultiplierValue = m_cachedPerDieMultiplierValue;
@synthesize cachedPerDieBonusValue = m_cachedPerDieBonusValue;
@synthesize cachedPerDiePenaltyValue = m_cachedPerDiePenaltyValue;

@synthesize cachedWillRerollBelowValueForDice = m_cachedWillRerollBelowValueForDice;
@synthesize cachedWillRerollAboveValueForDice = m_cachedWillRerollAboveValueForDice;
@synthesize cachedValueBelowWhichToRerollDice = m_cachedValueBelowWhichToRerollDice;
@synthesize cachedValueAboveWhichToRerollDice = m_cachedValueAboveWhichToRerollDice;
@synthesize cachedRerollPrecedenceForDice = m_cachedRerollPrecedenceForDice;

@synthesize cachedWillRerollBelowValueForPools = m_cachedWillRerollBelowValueForPools;
@synthesize cachedWillRerollAboveValueForPools = m_cachedWillRerollAboveValueForPools;
@synthesize cachedValueBelowWhichToRerollPools = m_cachedValueBelowWhichToRerollPools;
@synthesize cachedValueAboveWhichToRerollPools = m_cachedValueAboveWhichToRerollPools;

@synthesize cachedWillApplyPerPoolMultiplierValue = m_cachedWillApplyPerPoolMultiplierValue;
@synthesize cachedWillApplyPerPoolBonusValue = m_cachedWillApplyPerPoolBonusValue;
@synthesize cachedWillApplyPerPoolPenaltyValue = m_cachedWillApplyPerPoolPenaltyValue;

@synthesize cachedPerPoolMultiplierValue = m_cachedPerPoolMultiplierValue;
@synthesize cachedPerPoolBonusValue = m_cachedPerPoolBonusValue;
@synthesize cachedPerPoolPenaltyValue = m_cachedPerPoolPenaltyValue;

@synthesize cachedWillDropLowestRolls = m_cachedWillDropLowestRolls;
@synthesize cachedWillDropHighestRolls = m_cachedWillDropHighestRolls;
@synthesize cachedNumberOfLowDrops = m_cachedNumberOfLowDrops;
@synthesize cachedNumberOfHighDrops = m_cachedNumberOfHighDrops;
@synthesize cachedRerollPrecedenceForPools = m_cachedRerollPrecedenceForPools;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_cachedNode = nil;        
        m_cachedNumberOfPoolsToRoll = 0;
    }
    return self;
}

- (void)main {
    // generate group
    DXGroup *group = [DXGroup group];
    group.numberOfPoolsToRoll = self.cachedNumberOfPoolsToRoll;
    [group updatePoolsWithHandler:self];
    [group rollWithHandler:self];

    // generate nodes from group
    //[self performSelectorOnMainThread:@selector(recalculateMasterOrderHints) withObject:nil waitUntilDone:YES];
    //NSUInteger masterOrderHint = 0;
    //NSUInteger masterOrderValue = 0;
    
    NSMutableArray *newNodes = [NSMutableArray array];
    NSMutableArray *newPoolNodes = [NSMutableArray array];
    
    for (DXPool *pool in group.pools) {
        if (self.isCancelled) break;
        
        NSTreeNode *poolNode = [NSTreeNode treeNodeWithRepresentedObject:pool];
        
        for (DXDie *die in pool.dice) {
            if (self.isCancelled) break;
            NSTreeNode *dieNode = [NSTreeNode treeNodeWithRepresentedObject:die];
            [newPoolNodes addObject:dieNode];
        }
        
        if (self.isCancelled) break;
        [[poolNode mutableChildNodes] addObjectsFromArray:newPoolNodes];

        if (self.isCancelled) break;
        [newNodes addObject:poolNode];
        [newPoolNodes removeAllObjects];
    }
    
    if (self.isCancelled) return;
    NSTreeNode *newGroupNode = [NSTreeNode treeNodeWithRepresentedObject:group];
    [[newGroupNode mutableChildNodes] addObjectsFromArray:newNodes];
    
    if (self.isCancelled) return;
    self.cachedNode = newGroupNode;
}

@end
