//
//  DXConflictEntry.h
//  Polymatic
//
//  Created by Andrew Merenbach on 8/14/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface DXConflictEntry : NSObject {
    NSString *m_message;
}

@property (readonly) NSString *message;
@property (readonly) NSString *localizedMessage;

- (id)initWithString:(NSString *)aString;
+ (id)entryWithMessage:(NSString *)aString;
- (void)dealloc;

@end
