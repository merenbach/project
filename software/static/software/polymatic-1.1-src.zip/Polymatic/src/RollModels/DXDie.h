//
//  DXDie.h
//  Polymatic
//
//  Created by Andrew Merenbach on 25/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXRoll.h"


@class DXPool;

@interface DXDie : DXRoll {   //<NSCoding>
    BOOL m_isDropped;

    NSInteger m_sides;

    BOOL m_willRerollBelow;
    BOOL m_willRerollAbove;
    NSInteger m_valueForRerollBelow;
    NSInteger m_valueForRerollAbove;
    DXRerollPrecedence m_valueForRerollPrecedence;

    BOOL m_willApplyModifierForMultiplier;
    BOOL m_willApplyModifierForBonus;
    BOOL m_willApplyModifierForPenalty;

    NSInteger m_valueForModifierForBonus;
    NSInteger m_valueForModifierForPenalty;
    NSInteger m_valueForModifierForMultiplier;
    
    NSInteger m_totalBeforeModifiers;
    NSInteger m_totalAfterModifiers;
}

@property (assign, readwrite) NSInteger sides;
@property (assign, readwrite) BOOL isDropped;
@property (assign, readwrite) BOOL willRerollBelow;
@property (assign, readwrite) BOOL willRerollAbove;
@property (assign, readwrite) NSInteger valueForRerollBelow;
@property (assign, readwrite) NSInteger valueForRerollAbove;
@property (assign, readwrite) DXRerollPrecedence valueForRerollPrecedence;
@property (assign, readwrite) BOOL willApplyModifierForMultiplier;
@property (assign, readwrite) BOOL willApplyModifierForBonus;
@property (assign, readwrite) BOOL willApplyModifierForPenalty;
@property (assign, readwrite) NSInteger valueForModifierForMultiplier;
@property (assign, readwrite) NSInteger valueForModifierForBonus;
@property (assign, readwrite) NSInteger valueForModifierForPenalty;
@property (assign, readwrite) NSInteger totalBeforeModifiers;
@property (assign, readwrite) NSInteger totalAfterModifiers;

- (id)init;
+ (id)die;

- (void)rollWithHandler:(NSOperation *)handler;
- (void)updateTotalsFromBase:(NSInteger)value;

@end
