//
//  DXDie.m
//  Polymatic
//
//  Created by Andrew Merenbach on 25/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import "DXDie.h"


@implementation DXDie

@synthesize sides = m_sides;
@synthesize isDropped = m_isDropped;

@synthesize willRerollBelow = m_willRerollBelow;
@synthesize willRerollAbove = m_willRerollAbove;
@synthesize valueForRerollBelow = m_valueForRerollBelow;
@synthesize valueForRerollAbove = m_valueForRerollAbove;
@synthesize valueForRerollPrecedence = m_valueForRerollPrecedence;

@synthesize willApplyModifierForMultiplier = m_willApplyModifierForMultiplier;
@synthesize willApplyModifierForBonus = m_willApplyModifierForBonus;
@synthesize willApplyModifierForPenalty = m_willApplyModifierForPenalty;

@synthesize valueForModifierForMultiplier = m_valueForModifierForMultiplier;
@synthesize valueForModifierForBonus = m_valueForModifierForBonus;
@synthesize valueForModifierForPenalty = m_valueForModifierForPenalty;

@synthesize totalBeforeModifiers = m_totalBeforeModifiers;
@synthesize totalAfterModifiers = m_totalAfterModifiers;

- (id)init {
    self = [super init];
    if (self != nil) {
        m_sides = 0;
    
        m_isDropped = NO;
    
        m_willRerollBelow = NO;
        m_willRerollAbove = NO;
        m_valueForRerollBelow = 0;
        m_valueForRerollAbove = 0;
        m_valueForRerollPrecedence = DXRerollingNone;
        
        m_willApplyModifierForMultiplier = NO;
        m_willApplyModifierForBonus = NO;
        m_willApplyModifierForPenalty = NO;
        
        m_valueForModifierForMultiplier = 1;
        m_valueForModifierForBonus = 0;
        m_valueForModifierForPenalty = 0;
            
        m_totalBeforeModifiers = 0;
        m_totalAfterModifiers = 0;
    }
    return self;
}

+ (id)die {
    return [[[[self class] alloc] init] autorelease];
}

- (void)rollWithHandler:(NSOperation *)handler {
    [super rollWithHandler:handler];

    self.isDropped = NO;    // reset die

    DXRerollPrecedence rerollPrecedence = self.valueForRerollPrecedence;
    
    BOOL belowFlag = self.willRerollBelow;
    BOOL aboveFlag = self.willRerollAbove;

    NSInteger belowValue = self.valueForRerollBelow;
    NSInteger aboveValue = self.valueForRerollAbove;

    BOOL success = NO;


    while (!success && !handler.isCancelled) {
        success = YES;
        NSInteger value = random()%self.sides + 1;
        [self updateTotalsFromBase:value];
        
        if (rerollPrecedence != DXRerollingNone) {
            switch(rerollPrecedence) {
                case DXRerollBeforeModifiers:
                    value = self.totalBeforeModifiers;
                    break;
                    
                case DXRerollAfterModifiers:
                    value = self.totalAfterModifiers;
                    break;
                    
                default:
                    break;
            }
        
            BOOL belowFailure = (belowFlag && value < belowValue);
            BOOL aboveFailure = (aboveFlag && value > aboveValue);
            
            if (belowFailure || aboveFailure) {
                success = NO;
            }
        }
    }
}

- (void)updateTotalsFromBase:(NSInteger)value {
    self.totalBeforeModifiers = value;

    if (self.willApplyModifierForMultiplier) {
        value *= self.valueForModifierForMultiplier;
    }
    
    if (self.willApplyModifierForBonus) {
        value += self.valueForModifierForBonus;
    }
        
    if (self.willApplyModifierForPenalty) {
        value -= self.valueForModifierForPenalty;
    }
        
    self.totalAfterModifiers = value;
}

- (id)conditionalMultiplierModifier {
    id val = nil;
    
    if (!self.willApplyModifierForMultiplier) {
        val = @"-";
    }
    else {
        val = [NSNumber numberWithInteger:self.valueForModifierForMultiplier];
    }
    
    return val;
}

- (id)conditionalBonusModifier {
    id val = nil;
    
    if (!self.willApplyModifierForBonus) {
        val = @"-";
    }
    else {
        val = [NSNumber numberWithInteger:self.valueForModifierForBonus];
    }
    
    return val;
}

- (id)conditionalPenaltyModifier {
    id val = nil;
    
    if (!self.willApplyModifierForPenalty) {
        val = @"-";
    }
    else {
        val = [NSNumber numberWithInteger:self.valueForModifierForPenalty];
    }
    
    return val;
}

@end
