//
//  DXGroup.h
//  Polymatic
//
//  Created by Andrew Merenbach on 8/19/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXRoll.h"


@interface DXGroup : DXRoll {
    NSArray *m_poolsArray;
//    NSInteger m_total;
    NSString *m_rollString;
    NSInteger m_numberOfPoolsToRoll;
}

@property (copy, readwrite) NSArray *pools;
//@property (assign, readwrite) NSInteger total;
@property (copy, readwrite) NSString *roll;
@property (assign, readwrite) NSInteger numberOfPoolsToRoll;

- (id)init;
+ (id)group;
- (void)rollWithHandler:(NSOperation *)handler;
- (void)updatePoolsWithHandler:(NSOperation *)handler;

@end
