//
//  DXPool.m
//  Polymatic
//
//  Created by Andrew Merenbach on 25/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import "DXPool.h"

#import "DXDie.h"

@implementation DXPool

@synthesize dice = m_diceArray;

@synthesize countOfDice = m_countOfDice;
@synthesize sidesPerDie = m_sidesPerDie;
//@synthesize isPercentileRoll;

@synthesize willRerollBelow = m_willRerollBelow;
@synthesize willRerollAbove = m_willRerollAbove;
@synthesize valueForRerollBelow = m_valueForRerollBelow;
@synthesize valueForRerollAbove = m_valueForRerollAbove;
@synthesize valueForRerollPrecedence = m_valueForRerollPrecedence;

@synthesize willDropLoRolls = m_willDropLoRolls;
@synthesize willDropHiRolls = m_willDropHiRolls;
@synthesize numberOfLoDrops = m_numberOfLoDrops;
@synthesize numberOfHiDrops = m_numberOfHiDrops;

@synthesize willApplyModifierForMultiplier = m_willApplyModifierForMultiplier;
@synthesize willApplyModifierForBonus = m_willApplyModifierForBonus;
@synthesize willApplyModifierForPenalty = m_willApplyModifierForPenalty;

@synthesize valueForModifierForMultiplier = m_valueForModifierForMultiplier;
@synthesize valueForModifierForBonus = m_valueForModifierForBonus;
@synthesize valueForModifierForPenalty = m_valueForModifierForPenalty;

@synthesize totalBeforeModifiers = m_totalBeforeModifiers;
@synthesize totalAfterModifiers = m_totalAfterModifiers;

@synthesize poolSortDescriptors = m_poolSortDescriptors;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_totalBeforeModifiers = 0;
		m_totalAfterModifiers = 0;
		
		m_countOfDice = 0;
		m_sidesPerDie = 0;
		
		m_willRerollBelow = NO;
		m_willRerollAbove = NO;
		m_valueForRerollBelow = 0;
		m_valueForRerollAbove = 0;
		m_valueForRerollPrecedence = DXRerollingNone;
			
		m_willDropLoRolls = NO;
		m_willDropHiRolls = NO;
		m_numberOfLoDrops = 0;
		m_numberOfHiDrops = 0;
			
		m_willApplyModifierForMultiplier = NO;
		m_willApplyModifierForBonus = NO;
		m_willApplyModifierForPenalty = NO;
		
		m_valueForModifierForMultiplier = 1;
		m_valueForModifierForBonus = 0;
		m_valueForModifierForPenalty = 0;
			
		m_diceArray = [[NSArray alloc] init];
		
		NSSortDescriptor *sd = [[NSSortDescriptor alloc] initWithKey:@"totalBeforeModifiers" ascending:YES];  // [todo][major] total*After*Modifiers?
		m_poolSortDescriptors = [[NSArray arrayWithObject:sd] copy];
		[sd release];
	}
	return self;
}

- (void)dealloc {
	[m_diceArray release];
	m_diceArray = nil;
	
	[m_poolSortDescriptors release];
	m_poolSortDescriptors = nil;
	
	[super dealloc];
}

+ (id)pool {
	return [[[[self class] alloc] init] autorelease];
}

#pragma mark -


+ (NSArray *)blankDiceWithCount:(NSUInteger)count withHandler:(NSOperation *)handler {
	NSMutableArray *array = [NSMutableArray arrayWithCapacity:count];
	
	for (NSUInteger n = 0; n < count; ++n) {
		if (handler.isCancelled) break;
		DXDie *die = [DXDie die];
		[array addObject:die];
	}
	
	return [array copy];
}

// kludge...
+ (NSArray *)blankDiceCopiedFromDice:(NSArray *)dice withHandler:(NSOperation *)handler {
	NSMutableArray *array = [NSMutableArray array];
	for (DXDie *die in dice) {
		if (handler.isCancelled) break;
		
		DXDie *dieCopy = [DXDie die];
		
		//dieCopy.order = die.order;
		
		dieCopy.sides = die.sides;
		
		// configure die-level modifiers
		dieCopy.willApplyModifierForMultiplier = die.willApplyModifierForMultiplier;
		dieCopy.willApplyModifierForBonus = die.willApplyModifierForBonus;
		dieCopy.willApplyModifierForPenalty = die.willApplyModifierForPenalty;
		dieCopy.valueForModifierForMultiplier = die.valueForModifierForMultiplier;
		dieCopy.valueForModifierForBonus = die.valueForModifierForBonus;
		dieCopy.valueForModifierForPenalty = die.valueForModifierForPenalty;
		
		// copy die-level rerolling
		dieCopy.willRerollBelow = die.willRerollBelow;
		dieCopy.willRerollAbove = die.willRerollAbove;
		dieCopy.valueForRerollBelow = die.valueForRerollBelow;
		dieCopy.valueForRerollAbove = die.valueForRerollAbove;
		dieCopy.valueForRerollPrecedence = die.valueForRerollPrecedence;
		
		// add to array of copies
		[array addObject:dieCopy];
	}
	
	return [array copy];
}

#pragma mark -

- (BOOL)testForRerollAfterModifiers:(BOOL)flag {
	BOOL reroll = NO;

	NSInteger total = (flag ? self.totalBeforeModifiers : self.totalAfterModifiers);
	
	BOOL needToRerollBelow = (self.willRerollBelow && total < self.valueForRerollBelow);
	BOOL needToRerollAbove = (self.willRerollAbove && total > self.valueForRerollAbove);
	
	if (needToRerollBelow || needToRerollAbove) {
		reroll = YES;
	}
	
	return reroll;
}

- (void)rollWithHandler:(NSOperation *)handler {
	[super rollWithHandler:handler];
	
	DXRerollPrecedence rerollPrecedence = self.valueForRerollPrecedence;
	
	BOOL belowFlag = self.willRerollBelow;
	BOOL aboveFlag = self.willRerollAbove;

	NSInteger belowValue = self.valueForRerollBelow;
	NSInteger aboveValue = self.valueForRerollAbove;

	BOOL success = NO;

	while (!success && !handler.isCancelled) {
		success = YES;

		for (DXDie *die in self.dice) {
			if (handler.isCancelled) break;
			[die rollWithHandler:handler];
		}
		//[self.dice makeObjectsPerformSelector:@selector(rollWithHandler:) withObject:handler];
		[self updateDrops];
		
		// sum the dice (not including drops)
		NSInteger value = 0;
		for (DXDie *die in self.dice) {
			if (handler.isCancelled) break;
			if (!die.isDropped) value += die.totalAfterModifiers;
		}
		
		[self updateTotalsFromBase:value];
// [TODO] keypath: @sum
		
		if (rerollPrecedence != DXRerollingNone) {
			switch(rerollPrecedence) {
				case DXRerollBeforeModifiers:
					value = self.totalBeforeModifiers;
					break;
					
				case DXRerollAfterModifiers:
					value = self.totalAfterModifiers;
					break;
					
				default:
					break;
			}
			
			BOOL belowFailure = (belowFlag && value < belowValue);
			BOOL aboveFailure = (aboveFlag && value > aboveValue);
			
			if (belowFailure || aboveFailure) {
				success = NO;
			}
		}
	}
}

- (void)updateDrops {
	BOOL dropLo = self.willDropLoRolls;
	BOOL dropHi = self.willDropHiRolls;
	
	if (dropLo || dropHi) {
		NSNumber *yesValue = [NSNumber numberWithBool:YES];
	
		NSArray *sortedDiceArray = [self.dice sortedArrayUsingDescriptors:self.poolSortDescriptors];
		NSUInteger countOfDice = [sortedDiceArray count];
		
		if (countOfDice > 0) {
			if (dropLo) {
				NSInteger rollDrops = self.numberOfLoDrops;
				if (rollDrops > 0) { // [dice count] is a sanity-check
					NSArray *rollsSubarray = [sortedDiceArray subarrayWithRange:NSMakeRange(0, rollDrops)];
					[rollsSubarray setValue:yesValue forKeyPath:@"isDropped"]; // drop all dice in the subarray
				}
			}
			
			if (dropHi) {
				NSInteger rollDrops = self.numberOfHiDrops;
				if (rollDrops > 0) { // [dice count] is a sanity-check
					NSArray *rollsSubarray = [sortedDiceArray subarrayWithRange:NSMakeRange(countOfDice - rollDrops, rollDrops)];
					[rollsSubarray setValue:yesValue forKeyPath:@"isDropped"]; // drop all dice in the subarray
				}
			}
		}
	}
}

- (void)updateTotalsFromBase:(NSInteger)value {
	self.totalBeforeModifiers = value;

	if (self.willApplyModifierForMultiplier) {
		value *= self.valueForModifierForMultiplier;
	}
	
	if (self.willApplyModifierForBonus) {
		value += self.valueForModifierForBonus;
	}
		
	if (self.willApplyModifierForPenalty) {
		value -= self.valueForModifierForPenalty;
	}
	
	self.totalAfterModifiers = value;
}

- (id)conditionalMultiplierModifier {
	id val = nil;
	
	if (!self.willApplyModifierForMultiplier) {
		val = @"-";
	}
	else {
		val = [NSNumber numberWithInteger:self.valueForModifierForMultiplier];
	}
	
	return val;
}

- (id)conditionalBonusModifier {
	id val = nil;
	
	if (!self.willApplyModifierForBonus) {
		val = @"-";
	}
	else {
		val = [NSNumber numberWithInteger:self.valueForModifierForBonus];
	}
	
	return val;
}

- (id)conditionalPenaltyModifier {
	id val = nil;
	
	if (!self.willApplyModifierForPenalty) {
		val = @"-";
	}
	else {
		val = [NSNumber numberWithInteger:self.valueForModifierForPenalty];
	}
	
	return val;
}

- (id)conditionalNumberOfDrops {
	id val = nil;
	
	BOOL willDropLo = self.willDropLoRolls;
	BOOL willDropHi = self.willDropHiRolls;
	
	BOOL valueForLo = self.numberOfLoDrops;
	BOOL valueForHi = self.numberOfHiDrops;
	
	NSInteger condLo = (willDropLo ? valueForLo : 0);
	NSInteger condHi = (willDropHi ? valueForHi : 0);
	
	NSInteger sum = condLo + condHi;
	
	
	if (sum == 0) {
		val = @"-";
	}
	else {
		val = [NSNumber numberWithInteger:sum];
	}
	
	return val;
}

@end
