//
//  DXRoll.h
//  Polymatic
//
//  Created by Andrew Merenbach on 8/22/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXMainWindowController.h"    /* for DXRerollPrecedence, used by subclasses */


@interface DXRoll : NSObject {
	//NSUInteger m_order;
}

//@property (assign, readwrite) NSUInteger order;

- (void)rollWithHandler:(NSOperation *)handler;

@end
