//
//  DXPool.h
//  Polymatic
//
//  Created by Andrew Merenbach on 25/11/2004.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXRoll.h"


@interface DXPool : DXRoll {
    /* properties */
    NSArray *m_diceArray;
    NSArray *m_poolSortDescriptors;
    
    NSInteger m_countOfDice;
    NSInteger m_sidesPerDie;

    BOOL m_willRerollBelow;
    BOOL m_willRerollAbove;
    NSInteger m_valueForRerollBelow;
    NSInteger m_valueForRerollAbove;
    DXRerollPrecedence m_valueForRerollPrecedence;
    
    BOOL m_willDropLoRolls;
    BOOL m_willDropHiRolls;
    NSInteger m_numberOfLoDrops;
    NSInteger m_numberOfHiDrops;
    
    BOOL m_willApplyModifierForMultiplier;
    BOOL m_willApplyModifierForBonus;
    BOOL m_willApplyModifierForPenalty;
    NSInteger m_valueForModifierForMultiplier;
    NSInteger m_valueForModifierForBonus;
    NSInteger m_valueForModifierForPenalty;
    
    NSInteger m_totalBeforeModifiers;
    NSInteger m_totalAfterModifiers;
}

@property (copy, readwrite) NSArray *dice;
@property (readonly) NSArray *poolSortDescriptors;

@property (assign, readwrite) NSInteger countOfDice;
@property (assign, readwrite) NSInteger sidesPerDie;

@property (assign, readwrite) BOOL willRerollBelow;
@property (assign, readwrite) BOOL willRerollAbove;
@property (assign, readwrite) NSInteger valueForRerollBelow;
@property (assign, readwrite) NSInteger valueForRerollAbove;
@property (assign, readwrite) DXRerollPrecedence valueForRerollPrecedence;

@property (assign, readwrite) BOOL willDropLoRolls;
@property (assign, readwrite) BOOL willDropHiRolls;
@property (assign, readwrite) NSInteger numberOfLoDrops;
@property (assign, readwrite) NSInteger numberOfHiDrops;

@property (assign, readwrite) BOOL willApplyModifierForMultiplier;
@property (assign, readwrite) BOOL willApplyModifierForBonus;
@property (assign, readwrite) BOOL willApplyModifierForPenalty;
@property (assign, readwrite) NSInteger valueForModifierForMultiplier;
@property (assign, readwrite) NSInteger valueForModifierForBonus;
@property (assign, readwrite) NSInteger valueForModifierForPenalty;
@property (assign, readwrite) NSInteger totalBeforeModifiers;
@property (assign, readwrite) NSInteger totalAfterModifiers;

- (id)init;
+ (id)pool;

+ (NSArray *)blankDiceWithCount:(NSUInteger)count withHandler:(NSOperation *)handler;
+ (NSArray *)blankDiceCopiedFromDice:(NSArray *)dice withHandler:(NSOperation *)handler;

- (BOOL)testForRerollAfterModifiers:(BOOL)flag;

- (void)rollWithHandler:(NSOperation *)handler;

- (void)updateDrops;
- (void)updateTotalsFromBase:(NSInteger)value;

@end
