//
//  DXGroup.m
//  Polymatic
//
//  Created by Andrew Merenbach on 8/19/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXGroup.h"
#import "DXPool.h"
#import "DXDie.h"
#import "DXRollOperation.h"
#import "DXMainWindowController.h"


@implementation DXGroup

@synthesize pools = m_poolsArray;
//@synthesize total = m_total;
@synthesize roll = m_rollString;
@synthesize numberOfPoolsToRoll = m_numberOfPoolsToRoll;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_poolsArray = [[NSArray alloc] init];

//        self.total = 0;
		m_rollString = [@"" copy];
		
		
		m_numberOfPoolsToRoll = 0;
	}
	return self;
}

+ (id)group {
	return [[[[self class] alloc] init] autorelease];
}

- (void)dealloc {
	[m_poolsArray release];
	m_poolsArray = nil;

	[m_rollString release];
	m_rollString = nil;
	
	[super dealloc];
}

- (void)rollWithHandler:(NSOperation *)handler {
	[super rollWithHandler:handler];
	
	for (DXPool *pool in self.pools) {
		if (handler.isCancelled) break;
		[pool rollWithHandler:handler];
	}
	
//    if (handler.isCancelled) return;
//    self.total = [[self.pools valueForKeyPath:@"@sum.totalAfterModifiers"] integerValue];
}

- (void)updatePoolsWithHandler:(DXRollOperation *)handler {
	NSMutableArray *pools = [NSMutableArray arrayWithCapacity:self.numberOfPoolsToRoll];

	self.roll = [NSString stringWithFormat:@"%id%i", handler.cachedNumberOfDicePerPool, handler.cachedNumberOfSidesPerDie];
	
	// prepare a generic die pool
	NSArray *blankDice = [DXPool blankDiceWithCount:handler.cachedNumberOfDicePerPool withHandler:handler];
	
	//NSUInteger dieOrder = 1;
	
	for (DXDie *die in blankDice) {
		if (handler.isCancelled) break;
		
		//die.order = dieOrder;
		
		die.sides = handler.cachedNumberOfSidesPerDie;

		die.willApplyModifierForMultiplier = handler.cachedWillApplyPerDieMultiplierValue;
		die.willApplyModifierForBonus = handler.cachedWillApplyPerDieBonusValue;
		die.willApplyModifierForPenalty = handler.cachedWillApplyPerDiePenaltyValue;

		die.valueForModifierForMultiplier = handler.cachedPerDieMultiplierValue;
		die.valueForModifierForBonus = handler.cachedPerDieBonusValue;
		die.valueForModifierForPenalty = handler.cachedPerDiePenaltyValue;

		// configure per-die rerolling
		die.willRerollBelow = handler.cachedWillRerollBelowValueForDice;
		die.willRerollAbove = handler.cachedWillRerollAboveValueForDice;
		die.valueForRerollBelow = handler.cachedValueBelowWhichToRerollDice;
		die.valueForRerollAbove = handler.cachedValueAboveWhichToRerollDice;
		die.valueForRerollPrecedence = handler.cachedRerollPrecedenceForDice;
		
		//dieOrder++;
	}

	//NSUInteger poolOrder = 1; 

	for (NSInteger i = 0; i < self.numberOfPoolsToRoll; ++i) {
		if (handler.isCancelled) break;
		
		/* and now, for the rolling logic */
		DXPool *pool = [DXPool pool];
		
		//pool.order = poolOrder;
		
		pool.countOfDice = handler.cachedNumberOfDicePerPool;
		pool.sidesPerDie = handler.cachedNumberOfSidesPerDie;
		
		pool.dice = [DXPool blankDiceCopiedFromDice:blankDice withHandler:handler];    // kludge
		
		// configure pool rerolling
		pool.willRerollBelow = handler.cachedWillRerollBelowValueForPools;
		pool.willRerollAbove = handler.cachedWillRerollAboveValueForPools;
		pool.valueForRerollBelow = handler.cachedValueBelowWhichToRerollPools;
		pool.valueForRerollAbove = handler.cachedValueAboveWhichToRerollPools;
		
		pool.willApplyModifierForMultiplier = handler.cachedWillApplyPerPoolMultiplierValue;
		pool.willApplyModifierForBonus = handler.cachedWillApplyPerPoolBonusValue;
		pool.willApplyModifierForPenalty = handler.cachedWillApplyPerPoolPenaltyValue;
		
		pool.valueForModifierForMultiplier = handler.cachedPerPoolMultiplierValue;
		pool.valueForModifierForBonus = handler.cachedPerPoolBonusValue;
		pool.valueForModifierForPenalty = handler.cachedPerPoolPenaltyValue;
		
		// configure drop behavior
		pool.willDropLoRolls = handler.cachedWillDropLowestRolls;
		pool.willDropHiRolls = handler.cachedWillDropHighestRolls;
		pool.numberOfLoDrops = handler.cachedNumberOfLowDrops;
		pool.numberOfHiDrops = handler.cachedNumberOfHighDrops;
		pool.valueForRerollPrecedence = handler.cachedRerollPrecedenceForPools;
		
		[pools addObject:pool];
		//poolOrder++;
	}
	
	if (handler.isCancelled) return;
	self.pools = pools;
}

@end
