//
//  DXRoll.m
//  Polymatic
//
//  Created by Andrew Merenbach on 8/22/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXRoll.h"


@implementation DXRoll

//@synthesize order = m_order;

- (id)init {
    self = [super init];
    /*if (self != nil) {
        m_order = 0;
    }*/
    return self;
}

- (void)rollWithHandler:(NSOperation *)handler {
    // do nothing
}

@end
