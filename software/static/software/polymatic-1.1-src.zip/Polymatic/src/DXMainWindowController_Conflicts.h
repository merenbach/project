//
//  DXMainWindowController_Conflicts.h
//  Polymatic
//
//  Created by Andrew Merenbach on 8/19/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DXMainWindowController.h"


@interface DXMainWindowController (DXBasicSettingsChecks)

- (BOOL)testForPoolsUnderflow;
- (BOOL)testForPoolsOverflow;

- (BOOL)testForSidesUnderflow;
- (BOOL)testForCountOverflow;

- (BOOL)testForCountUnderflow;

- (BOOL)testForSidesOverflow;
- (BOOL)testForResultOverflow;
- (BOOL)testForResultUnderflow;
- (BOOL)testForMoreDropsThanDice;
- (BOOL)testForRerollingCategoryCount;

- (BOOL)testForDropsOverflow;
- (BOOL)testForDropsUnderflow;

- (BOOL)testForModifiersUnderflow;
- (BOOL)testForModifiersOverflow;
- (BOOL)testForModifiersOverflowPerDie;
- (BOOL)testForModifiersOverflowPerPool;
- (BOOL)testForModifiersUnderflowPerDie;
- (BOOL)testForModifiersUnderflowPerPool;

@end


@interface DXMainWindowController (DXModifierChecks)
- (BOOL)willApplyModifiersPerDie;
- (BOOL)willApplyModifiersPerPool;
@end

@interface DXMainWindowController (DXPossibleMinimumResults)
- (NSInteger)possibleMinimumResultForIndividualDie;
//- (NSInteger)possibleMinimumResultForPercentile;
- (NSInteger)possibleMinimumResultForIndividualPool;
@end

@interface DXMainWindowController (DXPossibleMaximumResults)
- (NSInteger)possibleMaximumResultForIndividualDie;
//- (NSInteger)possibleMaximumResultForPercentile;
- (NSInteger)possibleMaximumResultForIndividualPool;
@end

/*@interface DXMainWindowController (DXPercentileSettingsCompatibility)
- (BOOL)testForPercentileDieCountOverrun;
- (BOOL)testForPercentileDieModifierOverrun;
- (BOOL)testForDropsWithPercentile;
//- (BOOL)testForPercentileRollWithNonPercentileReroll;
//- (BOOL)testForNonPercentileRollWithPercentileReroll;
@end*/

@interface DXMainWindowController (DXRerollRangeOverlaps)
- (BOOL)testForRerollRangeOverlapIndividual;
//- (BOOL)testForRerollRangeOverlapPercentile;
- (BOOL)testForRerollRangeOverlapTotal;
@end

@interface DXMainWindowController (DXRerollValueChecksForIndividual)
- (BOOL)testForRerollAboveValueBelowMinimumInIndividual;
- (BOOL)testForRerollBelowValueAboveMaximumInIndividual;
- (BOOL)testForRerollBelowValueBelowMinimumInIndividual;
- (BOOL)testForRerollAboveValueAboveMaximumInIndividual;
@end

/*@interface DXMainWindowController (DXRerollValueChecksForPercentile)
- (BOOL)testForRerollAboveValueBelowMinimumInPercentile;
- (BOOL)testForRerollBelowValueAboveMaximumInPercentile;
- (BOOL)testForRerollBelowValueBelowMinimumInPercentile;
- (BOOL)testForRerollAboveValueAboveMaximumInPercentile;
@end*/

@interface DXMainWindowController (DXRerollValueChecksForTotal)
- (BOOL)testForRerollAboveValueBelowMinimumInTotal;
- (BOOL)testForRerollBelowValueAboveMaximumInTotal;
- (BOOL)testForRerollBelowValueBelowMinimumInTotal;
- (BOOL)testForRerollAboveValueAboveMaximumInTotal;
@end
