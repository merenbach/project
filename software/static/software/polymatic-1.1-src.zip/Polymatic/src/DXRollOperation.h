//
//  DXRollOperation.h
//  Polymatic
//
//  Created by Andrew Merenbach on 3/25/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface DXRollOperation : NSOperation {
    NSTreeNode *m_cachedNode;    
    NSInteger m_cachedNumberOfPoolsToRoll;
	
	NSInteger m_cachedNumberOfSidesPerDie;
	NSInteger m_cachedNumberOfDicePerPool;
	
	BOOL m_cachedWillApplyPerDieMultiplierValue;
	BOOL m_cachedWillApplyPerDieBonusValue;
	BOOL m_cachedWillApplyPerDiePenaltyValue;
	NSInteger m_cachedPerDieMultiplierValue;
	NSInteger m_cachedPerDieBonusValue;
	NSInteger m_cachedPerDiePenaltyValue;
	
	BOOL m_cachedWillRerollBelowValueForDice;
	BOOL m_cachedWillRerollAboveValueForDice;
	NSInteger m_cachedValueBelowWhichToRerollDice;
	NSInteger m_cachedValueAboveWhichToRerollDice;
	NSInteger m_cachedRerollPrecedenceForDice;
	
	BOOL m_cachedWillRerollBelowValueForPools;
	BOOL m_cachedWillRerollAboveValueForPools;
	NSInteger m_cachedValueBelowWhichToRerollPools;
	NSInteger m_cachedValueAboveWhichToRerollPools;
	
	BOOL m_cachedWillApplyPerPoolMultiplierValue;
	BOOL m_cachedWillApplyPerPoolBonusValue;
	BOOL m_cachedWillApplyPerPoolPenaltyValue;
	
	NSInteger m_cachedPerPoolMultiplierValue;
	NSInteger m_cachedPerPoolBonusValue;
	NSInteger m_cachedPerPoolPenaltyValue;
	
	BOOL m_cachedWillDropLowestRolls;
	BOOL m_cachedWillDropHighestRolls;
	NSInteger m_cachedNumberOfLowDrops;
	NSInteger m_cachedNumberOfHighDrops;
	NSInteger m_cachedRerollPrecedenceForPools;
}

@property (assign, readwrite) NSTreeNode *cachedNode;
@property (assign, readwrite) NSInteger cachedNumberOfPoolsToRoll;

@property (assign, readwrite) NSInteger cachedNumberOfSidesPerDie;
@property (assign, readwrite) NSInteger cachedNumberOfDicePerPool;

@property (assign, readwrite) BOOL cachedWillApplyPerDieMultiplierValue;
@property (assign, readwrite) BOOL cachedWillApplyPerDieBonusValue;
@property (assign, readwrite) BOOL cachedWillApplyPerDiePenaltyValue;
@property (assign, readwrite) NSInteger cachedPerDieMultiplierValue;
@property (assign, readwrite) NSInteger cachedPerDieBonusValue;
@property (assign, readwrite) NSInteger cachedPerDiePenaltyValue;

@property (assign, readwrite) BOOL cachedWillRerollBelowValueForDice;
@property (assign, readwrite) BOOL cachedWillRerollAboveValueForDice;
@property (assign, readwrite) NSInteger cachedValueBelowWhichToRerollDice;
@property (assign, readwrite) NSInteger cachedValueAboveWhichToRerollDice;
@property (assign, readwrite) NSInteger cachedRerollPrecedenceForDice;

@property (assign, readwrite) BOOL cachedWillRerollBelowValueForPools;
@property (assign, readwrite) BOOL cachedWillRerollAboveValueForPools;
@property (assign, readwrite) NSInteger cachedValueBelowWhichToRerollPools;
@property (assign, readwrite) NSInteger cachedValueAboveWhichToRerollPools;

@property (assign, readwrite) BOOL cachedWillApplyPerPoolMultiplierValue;
@property (assign, readwrite) BOOL cachedWillApplyPerPoolBonusValue;
@property (assign, readwrite) BOOL cachedWillApplyPerPoolPenaltyValue;

@property (assign, readwrite) NSInteger cachedPerPoolMultiplierValue;
@property (assign, readwrite) NSInteger cachedPerPoolBonusValue;
@property (assign, readwrite) NSInteger cachedPerPoolPenaltyValue;

@property (assign, readwrite) BOOL cachedWillDropLowestRolls;
@property (assign, readwrite) BOOL cachedWillDropHighestRolls;
@property (assign, readwrite) NSInteger cachedNumberOfLowDrops;
@property (assign, readwrite) NSInteger cachedNumberOfHighDrops;
@property (assign, readwrite) NSInteger cachedRerollPrecedenceForPools;

- (id)init;
- (void)main;	

@end
