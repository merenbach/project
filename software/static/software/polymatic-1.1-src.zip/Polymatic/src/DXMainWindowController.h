//
//  DXMainWindowController.h
//  Polymatic
//
//  Created by Andrew Merenbach on 27/12/06.
//  Copyright Andrew Merenbach 2002-2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *DXWillLogRollsKey;
extern NSString *DXNumberOfSidesPerDieKey;
extern NSString *DXNumberOfDicePerPoolKey;
extern NSString *DXNumberOfPoolsToRollKey;

typedef enum _DXRerollPrecedence {
	DXRerollingNone         = 0,
	DXRerollBeforeModifiers = 1,
	DXRerollAfterModifiers  = 2,
} DXRerollPrecedence;


enum {
	//DXMaxPercentileDieCount = 8,    // eight is the max precision for which we're aiming in percentile rolling
	//DXPercentileDieSideCount = 10,  // this is a constant, of course
	
	DXMaximumResult = (2 << 26),
	DXMinimumResult = -(2 << 26),
	
	
	//DXPercentileSideValueMin = 0,
	//DXPercentileSideValueMax = 9,
	DXStandardMin = (-65535),
	DXStandardZero = 0,
	DXStandardMax = 65535,
};

@class AMTableView;


@interface DXMainWindowController : NSWindowController 
{
	AMTableView *m_rollsTableView;
	NSSegmentedControl *m_memorySlotSaveSegmentedControl;
	NSSegmentedControl *m_memorySlotLoadSegmentedControl;
	
	// default list values for combo boxes
	NSArray *m_defaultSidesPerDie;  // default sides per die
	NSArray *m_defaultDicePerPool;  // default dice per pool

	// results
	NSArray *m_rollsArray;  // result nodes
	BOOL m_isRunningRoll;   // are we rolling?
	BOOL m_willLogRolls;    // should we log?
	
	// operation queues
	NSOperationQueue *m_rollOperationQueue;
	
	// basic parameters
	NSInteger m_numberOfPoolsToRoll;        
	NSInteger m_numberOfDicePerPool;
	NSInteger m_numberOfSidesPerDie;
	
	// aspects for settings
	NSTabView *m_aspectTabView;
	NSDictionary *m_aspectControllers;
	//NSBox *m_aspectTabViewFadeContainer;

	// modifiers
	BOOL m_cachedWillApplyPerDieBonusValue;
	BOOL m_cachedWillApplyPerDiePenaltyValue;
	BOOL m_cachedWillApplyPerDieMultiplierValue;
	NSInteger m_cachedPerDieBonusValue;
	NSInteger m_cachedPerDiePenaltyValue;
	NSInteger m_cachedPerDieMultiplierValue;
	BOOL m_cachedWillApplyPerPoolBonusValue;
	BOOL m_cachedWillApplyPerPoolPenaltyValue;
	BOOL m_cachedWillApplyPerPoolMultiplierValue;
	NSInteger m_cachedPerPoolBonusValue;
	NSInteger m_cachedPerPoolPenaltyValue;
	NSInteger m_cachedPerPoolMultiplierValue;
	
	// rerolling
	BOOL m_cachedWillRerollBelowValueForDice;
	BOOL m_cachedWillRerollAboveValueForDice;
	NSInteger m_cachedValueBelowWhichToRerollDice;
	NSInteger m_cachedValueAboveWhichToRerollDice;
	NSInteger m_cachedRerollPrecedenceForDice;
	BOOL m_cachedWillRerollBelowValueForPools;
	BOOL m_cachedWillRerollAboveValueForPools;
	NSInteger m_cachedValueBelowWhichToRerollPools;
	NSInteger m_cachedValueAboveWhichToRerollPools;
	NSInteger m_cachedRerollPrecedenceForPools;
	
	// drops
	BOOL m_cachedWillDropLowestRolls;
	BOOL m_cachedWillDropHighestRolls;
	NSInteger m_cachedNumberOfLowDrops;
	NSInteger m_cachedNumberOfHighDrops;
}

@property (assign) IBOutlet AMTableView *rollsTableView;
@property (assign) IBOutlet NSSegmentedControl *memorySlotSaveSegmentedControl;
@property (assign) IBOutlet NSSegmentedControl *memorySlotLoadSegmentedControl;

@property (readonly) NSArray *defaultSidesPerDie;    // default combo box values for sides per die
@property (readonly) NSArray *defaultDicePerPool;    // default combo box values for dice per pool

// general parameters
@property (assign, readwrite) NSInteger numberOfSidesPerDie;    // number of sides per die
@property (assign, readwrite) NSInteger numberOfDicePerPool;    // number of dice per pool
@property (assign, readwrite) NSInteger numberOfPoolsToRoll;    // number of pools to roll

@property (copy, readwrite) NSArray *rollsArray;         // keeps track of results
@property (assign, readwrite) BOOL isRunningRoll;   // keeps track of whether a roll is running
@property (assign, readwrite) BOOL willLogRolls;    // keeps track of whether to log rolls
@property (retain, readwrite) NSOperationQueue *rollOperationQueue;

@property (assign) IBOutlet NSTabView *aspectTabView;
@property (copy, readwrite) NSDictionary *aspectControllers;    // [am][2009-02-26] changed from assign to copy

// modifiers
@property (assign, readwrite) BOOL cachedWillApplyPerDieBonusValue;
@property (assign, readwrite) BOOL cachedWillApplyPerDiePenaltyValue;
@property (assign, readwrite) BOOL cachedWillApplyPerDieMultiplierValue;
@property (assign, readwrite) NSInteger cachedPerDieBonusValue;
@property (assign, readwrite) NSInteger cachedPerDiePenaltyValue;
@property (assign, readwrite) NSInteger cachedPerDieMultiplierValue;
@property (assign, readwrite) BOOL cachedWillApplyPerPoolBonusValue;
@property (assign, readwrite) BOOL cachedWillApplyPerPoolPenaltyValue;
@property (assign, readwrite) BOOL cachedWillApplyPerPoolMultiplierValue;
@property (assign, readwrite) NSInteger cachedPerPoolBonusValue;
@property (assign, readwrite) NSInteger cachedPerPoolPenaltyValue;
@property (assign, readwrite) NSInteger cachedPerPoolMultiplierValue;

// rerolling
@property (assign, readwrite) BOOL cachedWillRerollBelowValueForDice;
@property (assign, readwrite) BOOL cachedWillRerollAboveValueForDice;
@property (assign, readwrite) NSInteger cachedValueBelowWhichToRerollDice;
@property (assign, readwrite) NSInteger cachedValueAboveWhichToRerollDice;
@property (assign, readwrite) NSInteger cachedRerollPrecedenceForDice;
@property (assign, readwrite) BOOL cachedWillRerollBelowValueForPools;
@property (assign, readwrite) BOOL cachedWillRerollAboveValueForPools;
@property (assign, readwrite) NSInteger cachedValueBelowWhichToRerollPools;
@property (assign, readwrite) NSInteger cachedValueAboveWhichToRerollPools;
@property (assign, readwrite) NSInteger cachedRerollPrecedenceForPools;

// drops
@property (assign, readwrite) BOOL cachedWillDropLowestRolls;
@property (assign, readwrite) BOOL cachedWillDropHighestRolls;
@property (assign, readwrite) NSInteger cachedNumberOfLowDrops;
@property (assign, readwrite) NSInteger cachedNumberOfHighDrops;

- (id)init;
//- (void)resetSettings;
- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)anItem;
- (IBAction)startRunningRoll:(id)sender;
- (IBAction)stopRunningRoll:(id)sender;

- (IBAction)configureForPercentileRoll:(id)sender;

- (void)toggleRunningRoll:(id)sender;
- (void)updateCachedRollSettings;
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
- (void)finishRoll:(NSTreeNode *)node;


//- (IBAction)resetSettings:(id)sender;
//- (void)didEndResetSettingsSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;

//- (IBAction)clearLog:(id)sender;
//- (void)didEndClearLogSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;

- (IBAction)displaySettingsHelp:(id)sender;

- (void)prepareTabViewItems;

@end

@interface DXMainWindowController (MemorySlots)
- (void)loadFirstSlotFromDefaults;
- (void)saveFirstSlotToDefaults;
- (IBAction)saveIntoMemorySlots:(id)sender;
- (IBAction)loadFromMemorySlots:(id)sender;
- (IBAction)resetSlots:(id)sender;
- (void)didEndResetSlotsSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
- (void)finishResettingSlots;
//- (void)loadValuesFromDefaults;
//- (void)saveValuesToDefaults;
- (void)loadValuesFromDefaultsWithTag:(NSInteger)tag;
- (void)saveValuesToDefaultsWithTag:(NSInteger)tag;
@end

@interface DXMainWindowController (TableViewDataSourceMethods)
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView;
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
@end

@interface DXMainWindowController (RollingAlerts)
- (void)displayConflictSheetWithConflicts:(NSArray *)conflicts;
- (NSArray *)determinedConflicts;
@end

@interface DXIsNotZeroValueTransformer : NSValueTransformer {}
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;
@end

/*@interface DXRollButtonTitleConverterVT : NSValueTransformer {}
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;
@end
*/
