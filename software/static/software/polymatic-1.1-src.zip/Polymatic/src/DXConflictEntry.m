//
//  DXConflictEntry.m
//  Polymatic
//
//  Created by Andrew Merenbach on 8/14/08.
//  Copyright 2002-2008 Andrew Merenbach. All rights reserved.
//

#import "DXConflictEntry.h"


@implementation DXConflictEntry

@synthesize message = m_message;
@dynamic localizedMessage;

- (id)initWithString:(NSString *)aString {
    self = [super init];
    if (self != nil) {
        m_message = [aString copy];
    }
    return self;
}

+ (id)entryWithMessage:(NSString *)aString {
    return [[[[self class] alloc] initWithString:aString] autorelease];
}

- (void)dealloc {
    [m_message release];
    m_message = nil;
    
    [super dealloc];
}

- (NSString *)localizedMessage {
	return NSLocalizedString(self.message, @"Conflict");
}

@end
