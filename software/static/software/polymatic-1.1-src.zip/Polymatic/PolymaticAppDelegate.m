//
//  PolymaticAppDelegate.m
//  Polymatic
//
//  Created by Andrew Merenbach on 4/16/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "PolymaticAppDelegate.h"

#import "DXMainWindowController.h"
#import "DXPreferencesWindowController.h"
#import "DXLogWindowController.h"
#import "DXConflictsWindowController.h"


@implementation PolymaticAppDelegate

@synthesize mainWindowController = m_mainWindowController;
@synthesize preferencesWindowController = m_preferencesWindowController;    // preferences window controller
@synthesize logWindowController = m_logWindowController;                    // log window controller
@synthesize conflictsWindowController = m_conflictsWindowController;        // conflicts window controller

- (id)init {
	self = [super init];
	if (self != nil) {
		m_mainWindowController = [[DXMainWindowController alloc] init];
		m_preferencesWindowController = [[DXPreferencesWindowController alloc] init];
        m_logWindowController = [[DXLogWindowController alloc] init];
		m_conflictsWindowController = [[DXConflictsWindowController alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_mainWindowController release];
	[m_preferencesWindowController release];
	[m_logWindowController release];
	[m_conflictsWindowController release];
	
	m_mainWindowController = nil;
	m_preferencesWindowController = nil;
	m_logWindowController = nil;
	m_conflictsWindowController = nil;
		
	[super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
	(void)self.mainWindowController.window;			// make sure that window is loaded for first-slot loading below
	(void)self.preferencesWindowController.window;	// prepare our preferences window controller for access
	(void)self.logWindowController.window;			// prepare our window controller for access
	(void)self.conflictsWindowController.window;	// prepare our conflict window controller for access

	[[NSNotificationCenter defaultCenter] addObserver:self.preferencesWindowController selector:@selector(resetAllSlotsNotificationReceived:) name:DXPreferencesResetSlotsNotificationName object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self.logWindowController selector:@selector(logNode:) name:DXLogNodeNotificationName object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self.conflictsWindowController selector:@selector(conflictsGenerated:) name:DXNewConflictNotificationName object:nil];
	
	[self.mainWindowController loadFirstSlotFromDefaults];
	[self.mainWindowController showWindow:nil];
	
	// show the log window (if the preference is set)
	if ([[NSUserDefaults standardUserDefaults] boolForKey:DXPreferencesShowLogAtStartupKey]) {
		[self.logWindowController showWindow:nil];
		[self.mainWindowController.window makeKeyAndOrderFront:nil];
	}
}

- (void)applicationWillTerminate:(NSNotification *)notification {
	[self.mainWindowController saveFirstSlotToDefaults];	
}

@end

@implementation PolymaticAppDelegate (ShowWindowCovers)

- (IBAction)showMainWindow:(id)sender {
    [self.mainWindowController showWindow:sender];
}

- (IBAction)showPreferencesWindow:(id)sender {
    [self.preferencesWindowController showWindow:sender];
}

- (IBAction)showLogWindow:(id)sender {
    [self.logWindowController showWindow:sender];
}

@end