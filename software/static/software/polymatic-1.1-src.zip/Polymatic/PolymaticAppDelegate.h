//
//  PolymaticAppDelegate.h
//  Polymatic
//
//  Created by Andrew Merenbach on 4/16/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class DXMainWindowController;
@class DXPreferencesWindowController;
@class DXLogWindowController;
@class DXConflictsWindowController;


@interface PolymaticAppDelegate : NSObject {
	DXMainWindowController *m_mainWindowController;
	DXPreferencesWindowController *m_preferencesWindowController;
	DXLogWindowController *m_logWindowController;
	DXConflictsWindowController *m_conflictsWindowController;
}

@property (readonly) DXMainWindowController *mainWindowController;
@property (readonly) DXPreferencesWindowController *preferencesWindowController;
@property (readonly) DXLogWindowController *logWindowController;
@property (readonly) DXConflictsWindowController *conflictsWindowController;

- (id)init;
- (void)dealloc;
- (void)applicationDidFinishLaunching:(NSNotification *)notification;
- (void)applicationWillTerminate:(NSNotification *)notification;

@end

@interface PolymaticAppDelegate (ShowWindowCovers)
- (IBAction)showMainWindow:(id)sender;
- (IBAction)showPreferencesWindow:(id)sender;
- (IBAction)showLogWindow:(id)sender;
@end
