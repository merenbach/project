//
//  RDPreferencesWindowController.h
//  Randomness
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface RDPreferencesWindowController : NSWindowController {

}

+ (void)initialize;
- (id)init;

@end
