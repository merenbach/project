//
//  RDScriptCommands.h
//  Randomness
//
//  Created by Andrew Merenbach on 21/11/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface RDBasicScriptCommand : NSScriptCommand {
}

- (id)performDefaultImplementation;

@end
