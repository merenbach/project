//
//  RDPreferencesWindowController.m
//  Randomness
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "RDPreferencesWindowController.h"
#import "Randomness_AppDelegate.h"
#import "RDNumberAspectController.h"
#import "RDStringAspectController.h"
#import "RDLotteryAspectController.h"


@implementation RDPreferencesWindowController

+ (void)initialize {
	NSDictionary *initialValues;
	
	initialValues = [[NSDictionary alloc] initWithObjectsAndKeys:
		nil];
	[[NSUserDefaultsController sharedUserDefaultsController] setInitialValues:initialValues];
	[initialValues release];
	
	initialValues = [[NSDictionary alloc] initWithObjectsAndKeys:	
		[NSNumber numberWithInt:1], RDRandomNumberMinimumValueKey,
		[NSNumber numberWithInt:10], RDRandomNumberMaximumValueKey,
		[NSNumber numberWithInt:1], RDRandomNumberResultQuantityKey,
		[NSNumber numberWithBool:NO], RDRandomNumberSortResultsKey,
		
		[NSNumber numberWithInt:0], RDRandomStringMinimumValueKey,
		[NSNumber numberWithInt:9], RDRandomStringMaximumValueKey,
		[NSNumber numberWithInt:10], RDRandomStringResultLengthKey,
		[NSNumber numberWithBool:NO], RDRandomStringSortResultsKey,
		
		[NSNumber numberWithInt:1], RDLotteryMinimumValueKey,
		[NSNumber numberWithInt:49], RDLotteryMaximumValueKey,
		[NSNumber numberWithInt:6], RDLotteryResultCountKey,
		[NSNumber numberWithInt:1], RDLotteryTicketCountKey,
		[NSNumber numberWithBool:NO], RDLotterySortResultsKey,
		
		nil];
	[[NSUserDefaults standardUserDefaults] registerDefaults:initialValues];
	[initialValues release];
}

- (id)init {
	self = [super initWithWindowNibName:@"Preferences"];
	return self;
}

@end
