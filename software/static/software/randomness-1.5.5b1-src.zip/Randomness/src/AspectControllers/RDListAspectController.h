//
//  RDListAspectController.h
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDAspectController.h"

extern NSString *RDListResultCountKey;
extern NSString *RDListTicketCountKey;
extern NSString *RDListSortResultsKey;

@class AMTableView;


@interface RDListAspectController : RDAspectController {
@private
	IBOutlet NSArrayController *arrayController;
	IBOutlet AMTableView *tableView;
    
    /* properties */
    NSInteger m_resultCount;
    NSInteger m_ticketCount;
    BOOL m_sortResults;
	NSArray *m_numberList;
}

@property (assign, readwrite) NSInteger resultCount;
@property (assign, readwrite) NSInteger ticketCount;
@property (assign, readwrite) BOOL sortResults;
@property (copy, readwrite) NSArray *numberList;

- (void)toggleRunningGeneration:(id)sender;

- (void)importEntries:(id)sender;
- (void)importPanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
- (void)exportEntries:(id)sender;
- (void)exportPanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
- (void)clearEntries:(id)sender;
- (void)clearEntriesAlertDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;
//- (NSArray *)numbersFromArrayController;

@end
