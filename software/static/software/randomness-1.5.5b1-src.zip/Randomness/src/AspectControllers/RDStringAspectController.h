//
//  RDStringAspectController.h
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDAspectController.h"

extern NSString *RDRandomStringMinimumValueKey;
extern NSString *RDRandomStringMaximumValueKey;
extern NSString *RDRandomStringResultLengthKey;
extern NSString *RDRandomStringSortResultsKey;


@interface RDStringAspectController : RDAspectController {
@private
	NSInteger m_minimumValue;
	NSInteger m_maximumValue;
    BOOL m_sortResults;
    
    NSInteger m_resultLength;
}

@property (assign, readwrite) NSInteger minimumValue;
@property (assign, readwrite) NSInteger maximumValue;
@property (assign, readwrite) BOOL sortResults;
@property (assign, readwrite) NSInteger resultLength;

- (void)toggleRunningGeneration:(id)sender;

@end
