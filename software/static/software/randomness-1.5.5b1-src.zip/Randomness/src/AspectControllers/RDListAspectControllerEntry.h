//
//  RDListAspectControllerEntry.h
//  Randomness
//
//  Created by Andrew Merenbach on 8/16/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *RDListAspectNumberKey;

@interface RDListAspectControllerEntry : NSObject {
    // properties
	NSNumber *m_number;
}

- (id)init;
+ (id)entry;

- (id)initWithNumber:(NSNumber *)aNumber;
+ (id)entryWithNumber:(NSNumber *)aNumber;

- (void)dealloc;

- (NSComparisonResult)compare:(RDListAspectControllerEntry *)other;

@property (copy, readwrite) NSNumber *number;

@end
