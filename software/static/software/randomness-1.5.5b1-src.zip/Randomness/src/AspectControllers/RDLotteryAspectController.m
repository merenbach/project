//
//  RDLotteryAspectController.m
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "RDLotteryAspectController.h"
#import "RDLotteryGenerator.h"

NSString *RDLotteryMinimumValueKey = @"lotteryMinimumValue";
NSString *RDLotteryMaximumValueKey = @"lotteryMaximumValue";
NSString *RDLotteryResultCountKey = @"lotteryResultCount";
NSString *RDLotteryTicketCountKey = @"lotteryTicketCount";
NSString *RDLotterySortResultsKey = @"lotterySort";


@implementation RDLotteryAspectController

- (id)init {
	self = [super initWithNibName:[[self class] nibName]];
    if (self) {
		m_minimumValue = 0;
		m_maximumValue = 0;
		m_resultCount = 0;
		m_ticketCount = 0;
		
		m_sortResults = NO;
		
		//AM_ticketList = [[NSString alloc] init];
	}
	return self;
}

+ (NSString *)nibName {
	return @"LotteryAspect";
}

/*- (void)dealloc {
	//[AM_ticketList release];
	//AM_ticketList = nil;
	
	[super dealloc];
}*/

- (void)toggleRunningGeneration:(id)sender {
    // If already running, cancel and exit
    if (self.isGenerating) {
        //[equationCalculator removeObserver:self forKeyPath:@"isFinished"];
        //[operationQueue cancelAllOperations];
        //[equationCalculator cancel];
        //operationQueue = nil;
        //equationCalculator = nil;
        self.isGenerating = NO;
    }
    else {
		{
			NSUInteger min = self.minimumValue;
			NSUInteger max = self.maximumValue;
			
			if (min > max) {
				NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
										   @"Range Error", RDAlertTitleKey,
										   @"The minimum cannot exceed the maximum.", RDAlertMessageKey,
										   nil];
				[[NSApp delegate] performSelectorOnMainThread:@selector(displayAlert:) withObject:alertDict waitUntilDone:YES];
				return;
			}
			
			NSUInteger count = self.resultCount;
			NSUInteger totalNums = max - min + 1;
			
			if (count > totalNums) {
				NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
										   @"Range Error", RDAlertTitleKey,
										   @"You cannot draw more numbers than are in the pool.", RDAlertMessageKey,
										   nil];
				[[NSApp delegate] performSelectorOnMainThread:@selector(displayAlert:) withObject:alertDict waitUntilDone:YES];
				return;
			}
		}
		
		
        // If not running, start up the operation queue
        self.isGenerating = YES;
        self.outputString = @"";
        //startDate = [NSDate date];
        //self.time = 0.0;
        //timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
        
        // Create an expression tree for A * A * A + B * ( A * B + B )
        //equationCalculator = [[XQEquationCalculator alloc] initWithScale:self.cachedScaleOfNotation];
        //equationCalculator.dividend = self.cachedDividend;
        //equationCalculator.divisor = self.cachedDivisor;
        //equationCalculator.scaleOfNotation = self.cachedScaleOfNotation;
        
        RDLotteryGenerator *generator = [RDLotteryGenerator generator];
        
        generator.minimumValue = self.minimumValue;
        generator.maximumValue = self.maximumValue;
        generator.sortResults = self.sortResults;
        generator.resultCount = self.resultCount;
        generator.ticketCount = self.ticketCount;
        
        // Observe the complete expression to see when it is done
        [generator addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
        
        // Add operations to a operation queue
        //operationQueue = [NSOperationQueue new];
        //[operationQueue setMaxConcurrentOperationCount:numberOfCores];
        
        self.generator = generator;
        
        [generationOperationQueue addOperation:generator];
    }
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ( [keyPath isEqual:@"isFinished"] && self.generator == object ) {
        RDGenerator *generator = self.generator;
        [self performSelectorOnMainThread:@selector(finishGeneration:) withObject:generator.outputString waitUntilDone:YES];
        
        [generator removeObserver:self forKeyPath:@"isFinished"];
        //operationQueue = nil;
        self.generator = nil;

        self.isGenerating = NO;
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)loadValuesFromDefaults {
	[super loadValuesFromDefaults];
	
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	self.minimumValue = [userDefaults integerForKey:RDLotteryMinimumValueKey];
	self.maximumValue = [userDefaults integerForKey:RDLotteryMaximumValueKey];
	self.resultCount = [userDefaults integerForKey:RDLotteryResultCountKey];
	self.ticketCount = [userDefaults integerForKey:RDLotteryTicketCountKey];
	self.sortResults = [userDefaults boolForKey:RDLotterySortResultsKey];
}

- (void)saveValuesToDefaults {
	[super saveValuesToDefaults];

	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setInteger:self.minimumValue forKey:RDLotteryMinimumValueKey];
	[userDefaults setInteger:self.maximumValue forKey:RDLotteryMaximumValueKey];
	[userDefaults setInteger:self.resultCount forKey:RDLotteryResultCountKey];
	[userDefaults setInteger:self.ticketCount forKey:RDLotteryTicketCountKey];
	[userDefaults setBool:self.sortResults forKey:RDLotterySortResultsKey];
}

+ (NSString *)label {
	return @"RDLotteryAspectControllerLabel";
}

+ (NSString *)identifier {
	return @"Lottery";
}

@synthesize minimumValue = m_minimumValue;
@synthesize maximumValue = m_maximumValue;
@synthesize sortResults = m_sortResults;

@synthesize resultCount = m_resultCount;
@synthesize ticketCount = m_ticketCount;

@end
