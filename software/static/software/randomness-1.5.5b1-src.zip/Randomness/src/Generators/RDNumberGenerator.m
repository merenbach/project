//
//  RDNumberGenerator.m
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import "RDNumberGenerator.h"


@implementation RDNumberGenerator

- (id)init {
    self = [super init];
    if (self) {
        m_minimumValue = 0;
        m_maximumValue = 0;
        m_resultQuantity = 0;
        m_sortResults = NO;
    }
    return self;
}

- (void)main {
	NSString *string = @"";
		
	NSUInteger min = self.minimumValue;
	NSUInteger max = self.maximumValue;
	NSUInteger count = self.resultQuantity;
	
	if (min <= max) {
		NSMutableArray *array = [NSMutableArray arrayWithCapacity:count];
		
		while (!self.isCancelled && (count--)) {
			NSUInteger n = generateRandomInteger(min, max);
			[array addObject:[NSNumber numberWithUnsignedInt:n]];
		}
		if (self.sortResults) [array sortUsingSelector:@selector(compare:)];

		string = [array componentsJoinedByString:AMCommaDelimiterString];
		
	} else {
		// invalid input, so do nothing...
	}
	
    if (self.isCancelled) return;
	self.outputString = string;
}

@synthesize minimumValue = m_minimumValue;
@synthesize maximumValue = m_maximumValue;
@synthesize sortResults = m_sortResults;
@synthesize resultQuantity = m_resultQuantity;

@end
