//
//  RDStringGenerator.m
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import "RDStringGenerator.h"


@implementation RDStringGenerator

- (id)init {
    self = [super init];
    if (self) {
        m_minimumValue = 0;
        m_maximumValue = 0;
        m_resultLength = 0;
        m_sortResults = NO;
    }
    return self;
}

- (void)main {
	NSString *string = @"";
	
	NSUInteger min = self.minimumValue;
	NSUInteger max = self.maximumValue;
	NSUInteger len = self.resultLength;
    
    if (min <= max) {
		NSMutableArray *array = [NSMutableArray array];

		while (!self.isCancelled && (len--)) {
			NSUInteger curnum = generateRandomInteger(min, max);
			[array addObject:[NSNumber numberWithUnsignedInt:curnum]];
		}
		
		if (self.sortResults) [array sortUsingSelector:@selector(compare:)];
		
		string = [array componentsJoinedByString:@""];
		
	} else {
		// invalid input, so do nothing...
	}
	
    if (self.isCancelled) return;
	self.outputString = string;
}

@synthesize minimumValue = m_minimumValue;
@synthesize maximumValue = m_maximumValue;
@synthesize sortResults = m_sortResults;
@synthesize resultLength = m_resultLength;

@end
