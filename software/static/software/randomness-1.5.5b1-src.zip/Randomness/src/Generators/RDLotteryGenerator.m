//
//  RDLotteryGenerator.m
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import "RDLotteryGenerator.h"


@implementation RDLotteryGenerator

- (id)init {
    self = [super init];
    if (self) {
        m_minimumValue = 0;
        m_maximumValue = 0;
        m_resultCount = 0;
        m_ticketCount = 0;
        m_sortResults = NO;
    }
    return self;
}

- (void)main {
	NSString *string = @"";
	
	NSMutableArray *resultsArray;
	
	NSMutableArray *lottoNums;
	NSMutableArray *randomArray;
	NSMutableArray *lotteryPool;

    NSUInteger min = self.minimumValue;
    NSUInteger max = self.maximumValue;
    NSUInteger count = self.resultCount;
    NSUInteger tickets = self.ticketCount;
	BOOL sortResults = self.sortResults;
	
    if (min <= max) {	// sanity-check
        NSUInteger totalNums = max - min + 1;

		if (count <= totalNums) {
			lottoNums = [NSMutableArray arrayWithCapacity:totalNums];
			randomArray = [NSMutableArray arrayWithCapacity:count];
			resultsArray = [NSMutableArray arrayWithCapacity:tickets];
			
			for (NSUInteger i = min; i <= max && !self.isCancelled; ++i) {
				[lottoNums addObject:[NSNumber numberWithUnsignedInt:i]];
			}
			
			for (NSUInteger d = 0; d < tickets && !self.isCancelled; ++d) {	// [NOTE][?] should this line be above????
				lotteryPool = [lottoNums mutableCopy];
				for (NSUInteger n = 0; n < count; n++) {
					id theNumber = [lotteryPool objectAtIndex:random()%([lotteryPool count])];
					[randomArray addObject:theNumber];
					[lotteryPool removeObjectIdenticalTo:theNumber];
				}
				[lotteryPool release];
					
				if (sortResults) [randomArray sortUsingSelector:@selector(compare:)];
				[resultsArray addObject:[randomArray componentsJoinedByString:AMCommaDelimiterString]];
				[randomArray removeAllObjects];
			}
			
			string = [resultsArray componentsJoinedByString:AMNewlineDelimiterString];
			
		} else {
			// invalid input, so do nothing...
		}
	} else {
		// invalid input, so do nothing...
	}
	
    if (self.isCancelled) return;
	self.outputString = string;
}

@synthesize minimumValue = m_minimumValue;
@synthesize maximumValue = m_maximumValue;
@synthesize sortResults = m_sortResults;
@synthesize resultCount = m_resultCount;
@synthesize ticketCount = m_ticketCount;

@end
