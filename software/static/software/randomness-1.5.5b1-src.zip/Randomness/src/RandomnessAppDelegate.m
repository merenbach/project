//
//  RandomnessAppDelegate.m
//  Randomness
//
//  Created by Andrew Merenbach on 1/23/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "RandomnessAppDelegate.h"
#import "NSWindow+AMAdditions.h"

#import "RDNumberAspectController.h"
#import "RDStringAspectController.h"
#import "RDLotteryAspectController.h"
#import "RDListAspectController.h"


@implementation RandomnessAppDelegate

/*- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}*/

+ (void)initialize {
    srandom(time(NULL));	// seed the random number generator
}

- (id)init {
    self = [super init];
    if (self) {
        //blankView = [[NSView alloc] initWithFrame:NSZeroRect];
        
        NSMutableDictionary *aspectControllers = [NSMutableDictionary dictionary];
        {
            RDAspectController *numberAspectController = [[RDNumberAspectController alloc] init];
            RDAspectController *stringAspectController = [[RDStringAspectController alloc] init];
            RDAspectController *lotteryAspectController = [[RDLotteryAspectController alloc] init];
            RDAspectController *listAspectController = [[RDListAspectController alloc] init];
            
            [aspectControllers setObject:numberAspectController forKey:[RDNumberAspectController identifier]];
            [aspectControllers setObject:stringAspectController forKey:[RDStringAspectController identifier]];
            [aspectControllers setObject:lotteryAspectController forKey:[RDLotteryAspectController identifier]];
            [aspectControllers setObject:listAspectController forKey:[RDListAspectController identifier]];
            
            [numberAspectController release];
            [stringAspectController release];
            [lotteryAspectController release];
            [listAspectController release];
        }
        
        m_aspectControllers = [aspectControllers copy];
        
        m_aspectControllerIdentifiers = [[NSArray alloc] initWithObjects:
										 [RDNumberAspectController identifier],
										 [RDStringAspectController identifier],
										 [RDLotteryAspectController identifier],
										 [RDListAspectController identifier],
										 nil];
        
        m_aspectSegmentedControl = nil;
    }
    return self;
}

- (void)dealloc {
    //[blankView release];
    //blankView = nil;
    
    [m_aspectControllers release];
    m_aspectControllers = nil;
    
    [m_aspectControllerIdentifiers release];
    m_aspectControllerIdentifiers = nil;
    
    [super dealloc];
}

- (void)awakeFromNib {
    [self loadAllValuesFromDefaults];
    //[self configureAspects];
    [self loadDefaultAspect:nil];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    [self saveAllValuesToDefaults];
}

/* we're a single-window app, so we'll return YES from this delegate method */
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication {
    return YES;
}

- (void)loadAllValuesFromDefaults {
    NSArray *controllers = [self.aspectControllers allValues];
    [controllers makeObjectsPerformSelector:@selector(loadValuesFromDefaults) withObject:nil];
}

- (void)saveAllValuesToDefaults {
    NSArray *controllers = [self.aspectControllers allValues];
    [controllers makeObjectsPerformSelector:@selector(saveValuesToDefaults) withObject:nil];
}


- (void)displayAlert:(NSDictionary *)infoDict {
    NSBeep();
    
    NSAlert *alert = [NSAlert alertWithMessageText:[infoDict objectForKey:RDAlertTitleKey]
									 defaultButton:NSLocalizedString(@"Cancel", @"Cancel")
								   alternateButton:nil
									   otherButton:nil
						 informativeTextWithFormat:[infoDict objectForKey:RDAlertMessageKey]];
    [alert setAlertStyle:NSInformationalAlertStyle];
    [alert beginSheetModalForWindow:self.window modalDelegate:nil didEndSelector:NULL contextInfo:nil];
}

@synthesize window = m_window;
@synthesize aspectTabView = m_aspectTabView;
@synthesize aspectControllerIdentifiers = m_aspectControllerIdentifiers;
@synthesize aspectControllers = m_aspectControllers;
@synthesize aspectSegmentedControl = m_aspectSegmentedControl;

@end

@implementation RandomnessAppDelegate (Aspects)

/*- (void)configureAspects {
 [aspectTabView setDelegate:self];
 
 
 RDNumberAspectController *ac1 = [aspectControllers objectForKey:[RDNumberAspectController identifier]];
 RDStringAspectController *ac2 = [aspectControllers objectForKey:[RDStringAspectController identifier]];
 RDLotteryAspectController *ac3 = [aspectControllers objectForKey:[RDLotteryAspectController identifier]];
 RDListAspectController *ac4 = [aspectControllers objectForKey:[RDListAspectController identifier]];
 
 NSArray *tabs = [aspectTabView tabViewItems];
 for (NSTabViewItem *item in tabs) {
 [aspectTabView removeTabViewItem:item];
 }
 
 
 
 
 NSTabViewItem *tv1 = [[NSTabViewItem alloc] initWithIdentifier:@"number"];
 [tv1 setLabel:@"Number"];
 [tv1 setView:[ac1 view]];
 
 NSTabViewItem *tv2 = [[NSTabViewItem alloc] initWithIdentifier:@"string"];
 [tv2 setLabel:@"String"];
 [tv2 setView:[ac2 view]];
 
 NSTabViewItem *tv3 = [[NSTabViewItem alloc] initWithIdentifier:@"lottery"];
 [tv3 setLabel:@"Lottery"];
 [tv3 setView:[ac3 view]];
 
 NSTabViewItem *tv4 = [[NSTabViewItem alloc] initWithIdentifier:@"list"];
 [tv4 setLabel:@"List"];
 [tv4 setView:[ac4 view]];
 
 [aspectTabView addTabViewItem:tv1];
 [aspectTabView addTabViewItem:tv2];
 [aspectTabView addTabViewItem:tv3];
 [aspectTabView addTabViewItem:tv4];
 }*/

/*- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem {
 // kludge
 
 RDAspectController *controller = nil;
 
 NSString *identifier = [tabViewItem identifier];
 if ([identifier isEqualToString:@"number"]) {
 controller = [aspectControllers objectForKey:[RDNumberAspectController identifier]];
 }
 else if ([identifier isEqualToString:@"string"]) {
 controller = [aspectControllers objectForKey:[RDStringAspectController identifier]];
 }
 else if ([identifier isEqualToString:@"lottery"]) {
 controller = [aspectControllers objectForKey:[RDLotteryAspectController identifier]];
 }
 else if ([identifier isEqualToString:@"list"]) {
 controller = [aspectControllers objectForKey:[RDListAspectController identifier]];
 }
 
 NSRect frame = [[controller view] frame];
 NSLog(@"frame = %@", NSStringFromRect(frame));
 [window resizeToSize:frame.size];
 }*/
//- (BOOL)tabView:(NSTabView *)tabView shouldSelectTabViewItem:(NSTabViewItem *)tabViewItem


- (void)loadDefaultAspect:(id)sender {
    [self loadNumberAspect:sender];	// this may be changed some time
}

- (void)loadNumberAspect:(id)sender {
    [self loadAspectWithIdentifier:@"Number"];
}

- (void)loadStringAspect:(id)sender {
    [self loadAspectWithIdentifier:@"String"];
}

- (void)loadLotteryAspect:(id)sender {
    [self loadAspectWithIdentifier:@"Lottery"];
}

- (void)loadListAspect:(id)sender {
    [self loadAspectWithIdentifier:@"List"];
}

- (IBAction)changeAspect:(id)sender {
    NSInteger tag = [sender selectedSegment];
    [self loadAspectWithIdentifier:[self.aspectControllerIdentifiers objectAtIndex:tag]];
}

- (void)loadAspectWithIdentifier:(NSString *)identifier {
    RDAspectController *controller = [self.aspectControllers objectForKey:identifier];
    NSView *view = [controller view];
	
    NSArray *idents = self.aspectControllerIdentifiers;
    NSUInteger idx = [idents indexOfObject:identifier];
    [self.aspectSegmentedControl setSelectedSegment:idx];
	
	
    /* the following line does nothing when command is dispatched from toolbar,
	 but does have an effect when the command is dispatched from the menu */
    //[[window toolbar] setSelectedItemIdentifier:[controller identifier]];
    
    /* swap the content view of the main window */
    //[window setContentView:blankView];
    NSView *cv = [self.window contentView];
    [[[cv subviews] lastObject] removeFromSuperview];   // remove the window content view's contents
    
    //[window setTitle:@"Randomness"];
    [self.window resizeToSize:[view frame].size];
    
    [cv addSubview:view];
	
	//[window setTitle:[NSString stringWithFormat:@"Randomness (%@)", NSLocalizedStringFromTable([controller label], @"Aspects", @"")]];
    //[window setContentView:view];
}

@end

