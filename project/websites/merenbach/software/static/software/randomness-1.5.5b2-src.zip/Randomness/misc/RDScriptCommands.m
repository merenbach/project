//
//  RDScriptCommands.m
//  Randomness
//
//  Created by Andrew Merenbach on 21/11/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "RDScriptCommands.h"
#import "Randomness_AppDelegate.h"

#import "RDNumberAspectController.h"
#import "RDStringAspectController.h"
//#import "RDLotteryAspectController.h"


@implementation RDBasicScriptCommand

- (id)performDefaultImplementation {
	id returnValue = nil;

	NSString *commandName = [[self commandDescription] commandName];
	if ([commandName isEqualToString:@"generate random number"]) {
		RDRandomNumberGenerator *generator = [[RDRandomNumberGenerator alloc] init];
		id minimumValue, maximumValue, quantityValue;
		{
			NSDictionary *args = [self evaluatedArguments];
			minimumValue = [args objectForKey:@"with lower bound"];
			maximumValue = [args objectForKey:@"with upper bound"];
			quantityValue = [args objectForKey:@"with result quantity"];
		}
		[generator setMinimumValue:[minimumValue intValue]];
		[generator setMaximumValue:[maximumValue intValue]];
		[generator setResultQuantity:[quantityValue intValue]];
		
		returnValue = [generator generatedString];
		
		[generator release];
	} else if ([commandName isEqualToString:@"generate random string"]) {
		RDRandomStringGenerator *generator = [[RDRandomStringGenerator alloc] init];
		id minimumValue, maximumValue, lengthValue;
		{
			NSDictionary *args = [self evaluatedArguments];
			minimumValue = [args objectForKey:@"with lower bound"];
			maximumValue = [args objectForKey:@"with upper bound"];
			lengthValue = [args objectForKey:@"with result length"];
		}
		[generator setMinimumValue:[minimumValue intValue]];
		[generator setMaximumValue:[maximumValue intValue]];
		[generator setResultLength:[lengthValue intValue]];
		
		returnValue = [generator generatedString];
		
		[generator release];
	}
	return returnValue;
}

@end
