//
//  RDAspectController.h
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

static unsigned int generateRandomInteger(unsigned int lower_bound, unsigned int upper_bound) {
	return random()%(upper_bound - lower_bound + 1) + lower_bound;
}

extern NSString *RDAlertTitleKey;
extern NSString *RDAlertMessageKey;

extern NSString *AMSpaceString;
extern NSString *AMCommaDelimiterString;
extern NSString *AMNewlineDelimiterString;

@class RDGenerator;

@interface RDAspectController : NSViewController {
    RDGenerator *m_generator;


	BOOL m_generating;
	NSString *m_outputString;
    
    NSOperationQueue *m_generationOperationQueue;
	NSMutableArray *currentOperations;

	
	//IBOutlet NSTextView *outputTextView;
	//IBOutlet NSButton *sortCheckBox;
}

- (id)initWithNibName:(NSString *)nibName;
- (void)dealloc;
+ (NSString *)nibName;

+ (NSString *)label;
+ (NSString *)identifier;

- (void)loadValuesFromDefaults;
- (void)saveValuesToDefaults;

- (void)setNilValueForKey:(NSString *)key;

- (NSString *)outputString;
- (void)setOutputString:(NSString *)aString;
- (void)clearOutputString:(id)sender;

- (void)finishGeneration:(NSString *)string;

@property (retain, readwrite) RDGenerator *generator;

@property (assign, readwrite) BOOL isGenerating;
@property (copy, readwrite) NSString *outputString;

@property (retain, readwrite) NSOperationQueue *generationOperationQueue;

@end
