//
//  RDLotteryAspectController.h
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDAspectController.h"

extern NSString *RDLotteryMinimumValueKey;
extern NSString *RDLotteryMaximumValueKey;
extern NSString *RDLotteryResultCountKey;
extern NSString *RDLotteryTicketCountKey;
extern NSString *RDLotterySortResultsKey;


@interface RDLotteryAspectController : RDAspectController {
    /* properties */
	NSInteger m_minimumValue;
	NSInteger m_maximumValue;
    BOOL m_sortResults;

	NSInteger m_resultCount;
    NSInteger m_ticketCount;

	//NSString *AM_ticketList;
}

@property (assign, readwrite) NSInteger minimumValue;
@property (assign, readwrite) NSInteger maximumValue;
@property (assign, readwrite) BOOL sortResults;
@property (assign, readwrite) NSInteger resultCount;
@property (assign, readwrite) NSInteger ticketCount;

- (void)toggleRunningGeneration:(id)sender;

@end
