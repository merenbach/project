//
//  RDNumberAspectController.h
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDAspectController.h"

extern NSString *RDRandomNumberMinimumValueKey;
extern NSString *RDRandomNumberMaximumValueKey;
extern NSString *RDRandomNumberResultQuantityKey;
extern NSString *RDRandomNumberSortResultsKey;


@interface RDNumberAspectController : RDAspectController {
	NSInteger m_minimumValue;
	NSInteger m_maximumValue;
    BOOL m_sortResults;
    	
    NSInteger m_resultQuantity;
}

@property (assign, readwrite) NSInteger minimumValue;
@property (assign, readwrite) NSInteger maximumValue;
@property (assign, readwrite) BOOL sortResults;
@property (assign, readwrite) NSInteger resultQuantity;

- (void)toggleRunningGeneration:(id)sender;

@end
