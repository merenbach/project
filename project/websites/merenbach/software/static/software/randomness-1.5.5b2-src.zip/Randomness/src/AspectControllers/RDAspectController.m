//
//  RDAspectController.m
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "RDAspectController.h"

NSString *RDAlertTitleKey = @"title";
NSString *RDAlertMessageKey = @"message";

NSString *AMSpaceString = @" ";
NSString *AMCommaDelimiterString = @", ";
NSString *AMNewlineDelimiterString = @"\n";

@interface RDGeneratingStatusValueTransformer : NSValueTransformer {}
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSArray *)transformedValue:(id)value;
@end

@implementation RDAspectController

+ (void)initialize {
	NSValueTransformer *vt;
	
	vt = [[RDGeneratingStatusValueTransformer alloc] init];
	[NSValueTransformer setValueTransformer:vt forName:@"GeneratingStatus"];
	[vt release];
}

/*+ (id)controller {
	return [[[[self class] alloc] init] autorelease];
}*/

- (id)initWithNibName:(NSString *)nibName {
    self = [super init];
    if (self) {
        if (![NSBundle loadNibNamed:nibName owner:self]) {
            [self release];
            self = nil;
        } else {
            m_generating = NO;
			m_outputString = [[NSString alloc] init];
            
            m_generationOperationQueue = [NSOperationQueue new];
			
			
			currentOperations = [[NSMutableArray alloc] init];
		}
    }
    
    return self;
}

- (void)dealloc {
	[m_outputString release];
	m_outputString = nil;
    
    [m_generationOperationQueue release];
    m_generationOperationQueue = nil;
	
	[currentOperations release];
	currentOperations = nil;
    
    [super dealloc];
}

+ (NSString *)nibName {
	return nil;
}

+ (NSString *)label {
	return @"Dummy";
}

+ (NSString *)identifier {
	return @"Dummy";
}

- (void)toggleRunningGeneration:(id)sender {
    // do nothing
    return;
}

/*- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ( [keyPath isEqual:@"isFinished"] && generator == object ) {
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}*/


- (void)loadValuesFromDefaults {
	/* do nothing */
}

- (void)saveValuesToDefaults {
	/* do nothing */
}

/* for when we put a blank or otherwise-invalid value into a form cell */
- (void)setNilValueForKey:(NSString *)key {
	//[self willChangeValueForKey:key];
	[self setValue:[NSNumber numberWithInt:0] forKey:key];
	//[self didChangeValueForKey:key];
}

- (void)clearOutputString:(id)sender {
	self.outputString = @"";
}

- (void)finishGeneration:(NSString *)string {
    self.outputString = string;
}

@synthesize generator = m_generator;
@synthesize isGenerating = m_generating;
@synthesize outputString = m_outputString;
@synthesize generationOperationQueue = m_generationOperationQueue;

@end


@implementation RDGeneratingStatusValueTransformer

+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSArray *)transformedValue:(id)value {
	id result = nil;
	
	if (value) {
		if ([value boolValue] == NO) {
			result = [[NSBundle mainBundle] localizedStringForKey:@"Generate" value:@"Generate" table:nil];
		} else {
			result = [[NSBundle mainBundle] localizedStringForKey:@"Stop" value:@"Stop" table:nil];
		}
	}
	
	return result;
}

@end
