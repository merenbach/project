//
//  RDGenerator.m
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import "RDGenerator.h"


@implementation RDGenerator

- (id)init {
    self = [super init];
    if (self) {
        m_outputString = [@"" copy];
    }
    return self;
}

+ (id)generator {
    return [[[[self class] alloc] init] autorelease];
}

- (void)dealloc {
    [m_outputString release];
    m_outputString = nil;
    
    [super dealloc];
}

@synthesize outputString = m_outputString;

@end
