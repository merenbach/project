//
//  RDListGenerator.m
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import "RDListGenerator.h"
#import "RDListAspectControllerEntry.h"


@implementation RDListGenerator

- (id)init {
    self = [super init];
    if (self) {
        m_resultCount = 0;
        m_ticketCount = 0;
        m_sortResults = NO;
        m_numberList = [[NSArray alloc] init];
    }
    return self;
}

- (void)dealloc {
    [m_numberList release];
    m_numberList = nil;
    
    [super dealloc];
}

- (void)main {
	NSString *string = @"";
	NSMutableArray *resultsArray;
	
	NSMutableArray *lottoNums;
	NSMutableArray *randomArray;
	NSMutableArray *lotteryPool;

    NSUInteger count = self.resultCount;
    NSUInteger tickets = self.ticketCount;    // implicit cast
    BOOL sortResults = self.sortResults;
        
    //NSArray *numbers = [self numbersFromNumberList];
    
	NSArray *numbers = self.numberList;
    
	NSUInteger totalNums = [numbers count];
	
	if (count <= totalNums) {
		lottoNums = [numbers copy];
		randomArray = [NSMutableArray arrayWithCapacity:count];
		resultsArray = [NSMutableArray arrayWithCapacity:tickets];
		
		
		for (NSUInteger d = 0; d < tickets && !self.isCancelled; ++d) {	// [NOTE][?] should this line be above????
			lotteryPool = [lottoNums mutableCopy];
			for (NSUInteger n = 0; n < count; n++) {
				NSUInteger poolCount = [lotteryPool count];
				RDListAspectControllerEntry *theNumber = [lotteryPool objectAtIndex:random()%poolCount];
				[randomArray addObject:theNumber];
				[lotteryPool removeObjectIdenticalTo:theNumber];
			}
			[lotteryPool release];
				
			if (sortResults) [randomArray sortUsingSelector:@selector(compare:)];
			
			
			NSArray *newNumbers = [self numbersFromNumberEntries:randomArray];
			NSString *newNumbersString = [newNumbers componentsJoinedByString:AMCommaDelimiterString];
			
			[resultsArray addObject:newNumbersString];
			[randomArray removeAllObjects];
		}
		
		string = [resultsArray componentsJoinedByString:AMNewlineDelimiterString];
		[lottoNums release];
		
	} else {
		// invalid input, so do nothing...
	}
	
    if (self.isCancelled) return;
    self.outputString = string;
}

// originally - (NSArray *)numbersFromArrayController
/*- (NSArray *)numbersFromNumberList {
	NSMutableArray *numbers = [NSMutableArray array];
		
    for (RDListAspectControllerEntry *entry in self.numberList) {
		[numbers addObject:[entry valueForKey:RDListAspectNumberKey]];
	}

	return numbers;
}*/

- (NSArray *)numbersFromNumberEntries:(NSArray *)array {
	NSMutableArray *numbers = [NSMutableArray array];
	
    for (RDListAspectControllerEntry *entry in array) {
		[numbers addObject:[entry valueForKey:RDListAspectNumberKey]];
	}
	
	return numbers;	
}

@synthesize resultCount = m_resultCount;
@synthesize ticketCount = m_ticketCount;
@synthesize sortResults = m_sortResults;
@synthesize numberList = m_numberList;

@end
