//
//  RDGenerator.h
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDAspectController.h" /* kludge */


@interface RDGenerator : NSOperation {
    NSString *m_outputString;
    
}

+ (id)generator;

@property (copy, readwrite) NSString *outputString;

@end
