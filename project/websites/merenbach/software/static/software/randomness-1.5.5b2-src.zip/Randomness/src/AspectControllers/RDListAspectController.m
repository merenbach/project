//
//  RDListAspectController.m
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "RDListAspectController.h"
#import "AMTableView.h"
#import "RDListAspectControllerEntry.h"
#import "RandomnessAppDelegate.h"

#import "RDListGenerator.h"

NSString *RDListResultCountKey = @"RDListCount";
NSString *RDListTicketCountKey = @"RDListTickets";
NSString *RDListSortResultsKey = @"RDListSort";



@implementation RDListAspectController

- (id)init {
	self = [super initWithNibName:[[self class] nibName]];
    if (self) {
		m_resultCount = 0;
		m_ticketCount = 0;
		m_sortResults = NO;
		m_numberList = [[NSArray alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_numberList release];
	m_numberList = nil;
	
	[super dealloc];
}

+ (NSString *)nibName {
	return @"ListAspect";
}

- (void)awakeFromNib {
	tableView.spaceKeyAdds = NO;
	tableView.enterKeyAdds = NO;
	tableView.deleteKeyRemoves = NO;

	NSSortDescriptor *sd = [[NSSortDescriptor alloc] initWithKey:RDListAspectNumberKey ascending:YES];
	[arrayController setSortDescriptors:[NSArray arrayWithObject:sd]];
	[sd release];
}

- (void)toggleRunningGeneration:(id)sender {
    // If already running, cancel and exit
    if (self.isGenerating) {
        //[equationCalculator removeObserver:self forKeyPath:@"isFinished"];
        //[operationQueue cancelAllOperations];
        //[equationCalculator cancel];
        //operationQueue = nil;
        //equationCalculator = nil;
        self.isGenerating = NO;
    } else {
		{
			
			NSUInteger resultCount = self.resultCount;
			//NSUInteger ticketCount = self.ticketCount;
			
			NSArray *nums = self.numberList;
			NSUInteger totalNums = [nums count];
			
			if (resultCount > totalNums) {
				NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
										   @"Range Error", RDAlertTitleKey,
										   @"You cannot draw more numbers than are in the pool.", RDAlertMessageKey,
										   nil];
				[[NSApp delegate] performSelectorOnMainThread:@selector(displayAlert:) withObject:alertDict waitUntilDone:YES];
				
				
				return;
			}
			
			/*{
			
				RandomnessAppDelegate *delegate = [NSApp delegate];
				NSDictionary *maxParams = delegate.maxParameters;
				
				NSUInteger countMax = [[maxParams objectForKey:@"RDListCountMax"] integerValue];
				NSUInteger ticketsMax = [[maxParams objectForKey:@"RDListCountMax"] integerValue];
				NSLog(@"countMax = %i", countMax);
				NSLog(@"tMax = %i", ticketsMax);
				if (resultCount > countMax || ticketCount > ticketsMax) {
					NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
											   @"Range Error", RDAlertTitleKey,
											   @"One or more values are out of range.  Please correct them and try again.", RDAlertMessageKey,
											   nil];
					[[NSApp delegate] performSelectorOnMainThread:@selector(displayAlert:) withObject:alertDict waitUntilDone:YES];
					
					return;
				}
			}*/
		
		}
		
		
		
        // If not running, start up the operation queue
        self.isGenerating = YES;
        self.outputString = @"";
        //startDate = [NSDate date];
        //self.time = 0.0;
        //timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
        
        // Create an expression tree for A * A * A + B * ( A * B + B )
        //equationCalculator = [[XQEquationCalculator alloc] initWithScale:self.cachedScaleOfNotation];
        //equationCalculator.dividend = self.cachedDividend;
        //equationCalculator.divisor = self.cachedDivisor;
        //equationCalculator.scaleOfNotation = self.cachedScaleOfNotation;
        
        RDListGenerator *generator = [RDListGenerator generator];
        
        //self.numberList = [self numbersFromArrayController];
        
        
        generator.resultCount = self.resultCount;
        generator.ticketCount = self.ticketCount;
        generator.sortResults = self.sortResults;
        generator.numberList = self.numberList;
        
        // Observe the complete expression to see when it is done
        [generator addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
        
        // Add operations to a operation queue
        //operationQueue = [NSOperationQueue new];
        //[operationQueue setMaxConcurrentOperationCount:numberOfCores];
        
        //self.generator = generator;
        [currentOperations addObject:generator];
        [self.generationOperationQueue addOperation:generator];
    }
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	RDGenerator *generator = object;

    if ( [keyPath isEqual:@"isFinished"] && [currentOperations containsObject:generator] ) {
        //RDGenerator *generator = self.generator;
        [self performSelectorOnMainThread:@selector(finishGeneration:) withObject:generator.outputString waitUntilDone:YES];
        
        [generator removeObserver:self forKeyPath:@"isFinished"];
        //operationQueue = nil;
        //self.generator = nil;
		[currentOperations removeObject:generator];
        self.isGenerating = NO;
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)loadValuesFromDefaults {
	[super loadValuesFromDefaults];
	
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	self.resultCount = [userDefaults integerForKey:RDListResultCountKey];
	self.ticketCount = [userDefaults integerForKey:RDListTicketCountKey];
	self.sortResults = [userDefaults boolForKey:RDListSortResultsKey];
}

- (void)saveValuesToDefaults {
	[super saveValuesToDefaults];

	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setInteger:self.resultCount forKey:RDListResultCountKey];
	[userDefaults setInteger:self.ticketCount forKey:RDListTicketCountKey];
	[userDefaults setBool:self.sortResults forKey:RDListSortResultsKey];
}

+ (NSString *)label {
	return @"RDListAspectControllerLabel";
}

+ (NSString *)identifier {
	return @"List";
}

- (void)importEntries:(id)sender {
	if (!self.isGenerating) {
		NSOpenPanel *op;
		
		op = [NSOpenPanel openPanel];
		
		[op
			beginSheetForDirectory:nil
			file:nil
			types:[NSArray arrayWithObject:@"txt"]
			modalForWindow:[NSApp mainWindow]
			modalDelegate:self
			didEndSelector:@selector(importPanelDidEnd:returnCode:contextInfo:)
			contextInfo:NULL];
			
	} else {
		NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
			@"Program Busy", RDAlertTitleKey,
			@"You cannot import or export entries while the program is drawing from the list.", RDAlertMessageKey,
			nil];
		[[NSApp delegate] displayAlert:alertDict];
	}
}

- (void)importPanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo {
	if (returnCode == NSOKButton) {
		NSError *error = nil;
		
		NSString *string = [[NSString alloc] initWithContentsOfFile:[sheet filename]
			encoding:NSUTF8StringEncoding
			error:&error];
			
		if (error) {
			[[NSApplication sharedApplication] presentError:error];
		}
		
		NSMutableArray *entries = [[NSMutableArray alloc] init];

		NSArray *numberStrings = [string componentsSeparatedByString:AMNewlineDelimiterString];
        
		for (NSString *numberString in numberStrings) {
            NSNumber *number = [NSNumber numberWithUnsignedInteger:[numberString integerValue]];
			RDListAspectControllerEntry *entry = [RDListAspectControllerEntry entryWithNumber:number];
			[entries addObject:entry];
		}
		
		[arrayController setSortDescriptors:nil];
		self.numberList = entries;
		
		[entries release];
		[string release];
	}
}

- (void)exportEntries:(id)sender {
	if (!self.isGenerating) {
		NSSavePanel *sp;
		
		sp = [NSSavePanel savePanel];
		
		[sp setCanSelectHiddenExtension:YES];
		[sp setRequiredFileType:@"txt"];
		
		[sp
			beginSheetForDirectory:nil
			file:@"Randomness List Entries"
			modalForWindow:[NSApp mainWindow]
			modalDelegate:self
			didEndSelector:@selector(exportPanelDidEnd:returnCode:contextInfo:)
			contextInfo:NULL];
			
	} else {
		NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
			@"Program Busy", RDAlertTitleKey,
			@"You cannot import or export entries while the program is drawing from the list.", RDAlertMessageKey,
			nil];
		[[NSApp delegate] displayAlert:alertDict];
	}
}

- (void)exportPanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode == NSOKButton) {
		NSMutableArray *numbers = [[NSMutableArray alloc] init];
        
        NSArray *arrObj = [arrayController arrangedObjects];
        for (id entry in arrObj) {
            [numbers addObject:[entry valueForKey:RDListAspectNumberKey]];
		}
		
		NSString *entries = [numbers componentsJoinedByString:AMNewlineDelimiterString];
		[numbers release];
		
		NSError *error = nil;
		[entries writeToFile:[sheet filename]
			atomically:YES
			encoding:NSUTF8StringEncoding
			error:&error];
		
		if (error) {
			[[NSApplication sharedApplication] presentError:error];
		}
	}
}


- (void)clearEntries:(id)sender {
	if (!self.isGenerating) {
		NSAlert *alert = [[[NSAlert alloc] init] autorelease];
		[alert addButtonWithTitle:@"OK"];
		[alert addButtonWithTitle:@"Cancel"];
		[alert setMessageText:@"Delete all entries?"];
		[alert setInformativeText:@"Deleted entries cannot be restored."];
		[alert setAlertStyle:NSWarningAlertStyle];

		[alert beginSheetModalForWindow:[NSApp mainWindow]
						  modalDelegate:self
						 didEndSelector:@selector(clearEntriesAlertDidEnd:returnCode:contextInfo:)
							contextInfo:nil];
	} else {
		NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
								   @"Program Busy", RDAlertTitleKey,
								   @"You cannot remove entries while the program is drawing from the list.", RDAlertMessageKey,
								   nil];
		[[NSApp delegate] displayAlert:alertDict];
	}
}

- (void)clearEntriesAlertDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode == NSAlertFirstButtonReturn) {
		self.numberList = [NSArray array];
		
	}
}

/*- (NSArray *)numbersFromArrayController {
	NSMutableArray *numbers = [NSMutableArray array];
	
	NSEnumerator *e = [self.numberList objectEnumerator];
	id number;
	
	while (number = [e nextObject]) {
		[numbers addObject:[number valueForKey:RDListAspectNumberKey]];
	}

	return numbers;
}*/

@synthesize resultCount = m_resultCount;
@synthesize ticketCount = m_ticketCount;
@synthesize sortResults = m_sortResults;
@synthesize numberList = m_numberList;

@end
