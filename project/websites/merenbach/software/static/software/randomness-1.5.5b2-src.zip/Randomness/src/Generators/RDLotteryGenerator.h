//
//  RDLotteryGenerator.h
//  Randomness
//
//  Created by Andrew Merenbach on 2/21/09.
//  Copyright 2009 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RDGenerator.h"


@interface RDLotteryGenerator : RDGenerator {
	NSInteger m_minimumValue;
	NSInteger m_maximumValue;
    BOOL m_sortResults;

	NSInteger m_resultCount;
    NSInteger m_ticketCount;
}

@property (assign, readwrite) NSInteger minimumValue;
@property (assign, readwrite) NSInteger maximumValue;
@property (assign, readwrite) BOOL sortResults;
@property (assign, readwrite) NSInteger resultCount;
@property (assign, readwrite) NSInteger ticketCount;

@end
