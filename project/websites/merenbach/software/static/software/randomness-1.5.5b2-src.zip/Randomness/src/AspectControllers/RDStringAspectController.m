//
//  RDStringAspectController.m
//  Randomness
//
//  Created by Andrew Merenbach on 6/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "RDStringAspectController.h"
#import "RDStringGenerator.h"


NSString *RDRandomStringMinimumValueKey = @"RDStringMinimum";
NSString *RDRandomStringMaximumValueKey = @"RDStringMaximum";
NSString *RDRandomStringResultLengthKey = @"RDStringLength";
NSString *RDRandomStringSortResultsKey = @"RDStringSort";

@implementation RDStringAspectController

- (id)init {
	self = [super initWithNibName:[[self class] nibName]];
	if (self) {
		m_minimumValue = 0;
		m_maximumValue = 0;
		m_resultLength = 0;
		
		m_sortResults = 0;
	}
	return self;
}

+ (NSString *)nibName {
	return @"StringAspect";
}

- (void)toggleRunningGeneration:(id)sender {
    // If already running, cancel and exit
    if (self.isGenerating) {
        //[equationCalculator removeObserver:self forKeyPath:@"isFinished"];
        //[operationQueue cancelAllOperations];
        //[equationCalculator cancel];
        //operationQueue = nil;
        //equationCalculator = nil;
        self.isGenerating = NO;
    }
    else {
		// validate input...
		{
			NSUInteger min = self.minimumValue;
			NSUInteger max = self.maximumValue;
			
			if (min > max) {
				NSDictionary *alertDict = [NSDictionary dictionaryWithObjectsAndKeys:
										   @"Range Error", RDAlertTitleKey,
										   @"The minimum cannot exceed the maximum.", RDAlertMessageKey,
										   nil];
				[[NSApp delegate] performSelectorOnMainThread:@selector(displayAlert:) withObject:alertDict waitUntilDone:YES];
				return;
			}
		}
		
		
		
        // If not running, start up the operation queue
        self.isGenerating = YES;
        self.outputString = @"";
        //startDate = [NSDate date];
        //self.time = 0.0;
        //timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
        
        // Create an expression tree for A * A * A + B * ( A * B + B )
        //equationCalculator = [[XQEquationCalculator alloc] initWithScale:self.cachedScaleOfNotation];
        //equationCalculator.dividend = self.cachedDividend;
        //equationCalculator.divisor = self.cachedDivisor;
        //equationCalculator.scaleOfNotation = self.cachedScaleOfNotation;
        
        RDStringGenerator *generator = [RDStringGenerator generator];
        
        generator.minimumValue = self.minimumValue;
        generator.maximumValue = self.maximumValue;
        generator.sortResults = self.sortResults;
        generator.resultLength = self.resultLength;
        
        // Observe the complete expression to see when it is done
        [generator addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
        
        // Add operations to a operation queue
        //operationQueue = [NSOperationQueue new];
        //[operationQueue setMaxConcurrentOperationCount:numberOfCores];
        
        //self.generator = generator;
        [currentOperations addObject:generator];
        [self.generationOperationQueue addOperation:generator];
    }
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	RDGenerator *generator = object;
    if ( [keyPath isEqual:@"isFinished"] && [currentOperations containsObject:generator] ) {
        //RDGenerator *generator = self.generator;
        [self performSelectorOnMainThread:@selector(finishGeneration:) withObject:generator.outputString waitUntilDone:YES];
        
        [generator removeObserver:self forKeyPath:@"isFinished"];
		[currentOperations removeObject:generator];
        //operationQueue = nil;
        //self.generator = nil;

        self.isGenerating = NO;
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)loadValuesFromDefaults {
	[super loadValuesFromDefaults];
	
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	self.minimumValue = [userDefaults integerForKey:RDRandomStringMinimumValueKey];
	self.maximumValue = [userDefaults integerForKey:RDRandomStringMaximumValueKey];
	self.resultLength = [userDefaults integerForKey:RDRandomStringResultLengthKey];
	self.sortResults = [userDefaults boolForKey:RDRandomStringSortResultsKey];
}

- (void)saveValuesToDefaults {
	[super saveValuesToDefaults];

	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults setInteger:self.minimumValue forKey:RDRandomStringMinimumValueKey];
	[userDefaults setInteger:self.maximumValue forKey:RDRandomStringMaximumValueKey];
	[userDefaults setInteger:self.resultLength forKey:RDRandomStringResultLengthKey];
	[userDefaults setBool:self.sortResults forKey:RDRandomStringSortResultsKey];
}

+ (NSString *)label {
	return @"RDStringAspectControllerLabel";
}

+ (NSString *)identifier {
	return @"String";
}

@synthesize minimumValue = m_minimumValue;
@synthesize maximumValue = m_maximumValue;
@synthesize sortResults = m_sortResults;
@synthesize resultLength = m_resultLength;

@end
