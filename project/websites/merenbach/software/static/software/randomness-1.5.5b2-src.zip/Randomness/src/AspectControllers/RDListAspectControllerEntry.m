//
//  RDListAspectControllerEntry.m
//  Randomness
//
//  Created by Andrew Merenbach on 8/16/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "RDListAspectControllerEntry.h"

NSString *RDListAspectNumberKey = @"number";


@implementation RDListAspectControllerEntry

- (id)init {
	self = [super init];
    if (self) {
		m_number = [[NSNumber alloc] initWithUnsignedInteger:0];
	}
	return self;
}

+ (id)entry {
    return [[[[self class] alloc] init] autorelease];
}

- (id)initWithNumber:(NSNumber *)aNumber {
    self = [self init];
    if (self) {
        m_number = [aNumber copy];
    }
    return self;
}

+ (id)entryWithNumber:(NSNumber *)aNumber {
    return [[[[self class] alloc] initWithNumber:aNumber] autorelease];
}

- (void)dealloc {
	[m_number release];
	m_number = nil;

	[super dealloc];
}

- (NSComparisonResult)compare:(RDListAspectControllerEntry *)other {
	return [self.number compare:other.number];
}

/* we need the following two methods to prevent nil comparisons */
- (NSNumber *)number {
	NSNumber *number = m_number;
	if (!number) {
		number = [NSNumber numberWithUnsignedInteger:0];
	}
	return [[number retain] autorelease];
	
}

- (void)setNumber:(NSNumber *)aNumber {
	if (!aNumber) {
		aNumber = [NSNumber numberWithUnsignedInteger:0];
	}
	
	if (m_number != aNumber) {
		[m_number release];
		m_number = [aNumber copy];
	}
}
/* end "following two methods to prevent nil comparisons" */


//@synthesize number = m_number;

@end
