//
//  RandomnessAppDelegate.h
//  Randomness
//
//  Created by Andrew Merenbach on 1/23/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RandomnessAppDelegate : NSObject {
    NSWindow *m_window;
	NSTabView *m_aspectTabView;

	//NSView *blankView;	// used in swapping the interface aspects
	NSDictionary *m_aspectControllers;

	NSArray *m_aspectControllerIdentifiers;

	NSSegmentedControl *m_aspectSegmentedControl;
	
	NSDictionary *m_maxParameters;
}

- (void)loadAllValuesFromDefaults;
- (void)saveAllValuesToDefaults;

- (void)displayAlert:(NSDictionary *)infoDict;

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSTabView *aspectTabView;

@property (copy, readwrite) NSArray *aspectControllerIdentifiers;
@property (copy, readwrite) NSDictionary *aspectControllers;
@property (retain, readwrite, nonatomic) IBOutlet NSSegmentedControl *aspectSegmentedControl;

@property (copy, readonly) NSDictionary *maxParameters;

@end

@interface RandomnessAppDelegate (Aspects)

- (void)loadDefaultAspect:(id)sender;
- (void)loadNumberAspect:(id)sender;
- (void)loadStringAspect:(id)sender;
- (void)loadLotteryAspect:(id)sender;
- (void)loadListAspect:(id)sender;

- (IBAction)changeAspect:(id)sender;
- (void)loadAspectWithIdentifier:(NSString *)identifier;

@end
