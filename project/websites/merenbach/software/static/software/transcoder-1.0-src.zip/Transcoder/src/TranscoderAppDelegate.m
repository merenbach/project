//
//  TranscoderAppDelegate.m
//  Transcoder
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "TranscoderAppDelegate.h"
#import "TCMainWindowController.h"
#import "TCEncodingsWindowController.h"
#import "TCStringEncodingWrapper.h"


@implementation TranscoderAppDelegate

@synthesize mainWindowController = m_mainWindowController;
@synthesize encodingsWindowController = m_encodingsWindowController;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_mainWindowController = [[TCMainWindowController alloc] init];
		m_encodingsWindowController = [[TCEncodingsWindowController alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_mainWindowController release];
	m_mainWindowController = nil;
	
	[m_encodingsWindowController release];
	m_encodingsWindowController = nil;

	[super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	(void)self.mainWindowController.window;
	(void)self.encodingsWindowController.window;
	
	[[NSNotificationCenter defaultCenter] addObserver:self.mainWindowController selector:@selector(changeSourceEncoding:) name:TCChangedSourceEncodingNotificationName object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self.mainWindowController selector:@selector(changeMedianEncoding:) name:TCChangedMedianEncodingNotificationName object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self.mainWindowController selector:@selector(changeTargetEncoding:) name:TCChangedTargetEncodingNotificationName object:nil];
	
	[self.mainWindowController loadAllValuesFromDefaults];
	[self.mainWindowController showWindow:nil];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    [self.mainWindowController saveAllValuesToDefaults];
}

- (IBAction)changeEncoding:(id)sender {
	NSInteger tag = [sender selectedSegment];
	switch(tag) {
		case 0:	// source
			[self.mainWindowController changeSourceEncoding:sender];
			break;
			
		case 1: // median
			[self.mainWindowController changeMedianEncoding:sender];
			break;
			
		case 2: // target
			[self.mainWindowController changeTargetEncoding:sender];
			break;
			
		default:
			// do nothing
			break;
	}	
}

@end

@implementation TranscoderAppDelegate (ScriptingMethods)

- (BOOL)application:(NSApplication *)sender delegateHandlesKey:(NSString *)key {
    BOOL b = [key isEqualToString:@"sourceString"] ||
	[key isEqualToString:@"targetString"] ||
	[key isEqualToString:@"sourceEncoding"] ||
	[key isEqualToString:@"medianEncoding"] ||
	[key isEqualToString:@"targetEncoding"] ||
	[key isEqualToString:@"skipMedianEncoding"] ||
	[key isEqualToString:@"allowLossyConversion"];
    return b;
}

// cover method for scriptability
- (void)exchangeEncodingsScriptingCover:(id)sender {
	[self.mainWindowController exchangeEncodings:sender];
}

- (NSString *)sourceString {
	return self.mainWindowController.sourceString;
}

- (void)setSourceString:(NSString *)aString {
	self.mainWindowController.sourceString = aString;
}

- (NSString *)targetString {
	return self.mainWindowController.targetString;
}

- (void)setTargetString:(NSString *)aString {
	self.mainWindowController.targetString = aString;
}

- (NSInteger)sourceEncoding {
	TCStringEncodingWrapper *wrapper = self.mainWindowController.sourceEncodingWrapper;
	return [wrapper.stringEncodingNumber integerValue];
}

- (void)setSourceEncoding:(NSInteger)anInteger {
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:anInteger];
	self.mainWindowController.sourceEncodingWrapper = wrapper;
}

- (NSInteger)medianEncoding {
	TCStringEncodingWrapper *wrapper = self.mainWindowController.sourceEncodingWrapper;
	return [wrapper.stringEncodingNumber integerValue];
}

- (void)setMedianEncoding:(NSInteger)anInteger {
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:anInteger];
	self.mainWindowController.medianEncodingWrapper = wrapper;
}

- (NSInteger)targetEncoding {
	TCStringEncodingWrapper *wrapper = self.mainWindowController.sourceEncodingWrapper;
	return [wrapper.stringEncodingNumber integerValue];
}

- (void)setTargetEncoding:(NSInteger)anInteger {
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:anInteger];
	self.mainWindowController.targetEncodingWrapper = wrapper;
}

- (BOOL)skipMedianEncoding {
	return self.mainWindowController.skipMedianEncoding;
}

- (void)setSkipMedianEncoding:(BOOL)aBool {
	self.mainWindowController.skipMedianEncoding = aBool;
}

- (BOOL)allowsLossyConversion {
	return self.mainWindowController.allowsLossyConversion;
}

- (void)setAllowsLossyConversion:(BOOL)aBool {
	self.mainWindowController.allowsLossyConversion = aBool;
}

/*- (void)revertSourceString:(NSString *)string {
	//NSString *currentSourceString = self.sourceString;
	//NSUndoManager *um = [self.sourceTextView undoManager];
	//[um registerUndoWithTarget:self selector:@selector(revertSourceString:) object:currentSourceString];
	self.sourceString = string;
}
*/

- (void)revertTargetString:(NSString *)string {
	NSString *currentTargetString = self.mainWindowController.targetString;
	NSUndoManager *um = [self.mainWindowController.targetTextView undoManager];
	[um registerUndoWithTarget:self selector:@selector(revertTargetString:) object:currentTargetString];
	self.mainWindowController.targetString = string;
}

@end


@implementation TranscoderAppDelegate (ShowWindowCovers)

- (IBAction)showMainWindow:(id)sender {
	[self.mainWindowController showWindow:self];
}

- (IBAction)showEncodingsWindow:(id)sender {
	[self.encodingsWindowController showWindow:self];
}

@end
