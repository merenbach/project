//
//  TCStringEncodingWrapper.h
//  StringFixer
//
//  Created by Andrew Merenbach on 26/11/2004.
//  Copyright 2004-2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TCStringEncodingWrapper : NSObject {
    // properties
	CFStringEncoding m_internalStringEncoding;
	NSValue *m_stringEncodingValue;
	NSString *m_stringEncodingName;
	NSNumber *m_stringEncodingNumber;
}

@property (assign, readwrite) CFStringEncoding internalStringEncoding;
@property (copy, readwrite) NSString *stringEncodingName;
@property (copy, readwrite) NSNumber *stringEncodingNumber;
@property (copy, readwrite) NSValue *stringEncodingValue;

@property (assign, readonly) NSStringEncoding convertedStringEncoding;	// we have a method for this

- (id)init;
- (id)initWithEncoding:(CFStringEncoding)anEncoding;
+ (id)wrapperWithEncoding:(CFStringEncoding)anEncoding;

- (NSString *)description;
- (NSStringEncoding)convertedStringEncoding;

@end

/*@interface TCValueToNumberValueTransformer : NSValueTransformer {
}

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;

@end
*/