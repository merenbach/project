//
//  TranscoderAppDelegate.h
//  Transcoder
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class TCEncodingController;
@class TCMainWindowController;
@class TCEncodingsWindowController;


@interface TranscoderAppDelegate : NSObject {	
	TCMainWindowController *m_mainWindowController;
	TCEncodingsWindowController *m_encodingsWindowController;
}

//@property (assign) IBOutlet NSSplitView *mainSplitView;
@property (assign) TCMainWindowController *mainWindowController;
@property (assign) TCEncodingsWindowController *encodingsWindowController;


- (IBAction)changeEncoding:(id)sender;

@end

@interface TranscoderAppDelegate (ScriptingMethods)

- (void)exchangeEncodingsScriptingCover:(id)sender;
//- (void)revertSourceString:(NSString *)string;
- (void)revertTargetString:(NSString *)string;

@end

@interface TranscoderAppDelegate (ShowWindowCovers)
- (IBAction)showMainWindow:(id)sender;
- (IBAction)showEncodingsWindow:(id)sender;
@end
