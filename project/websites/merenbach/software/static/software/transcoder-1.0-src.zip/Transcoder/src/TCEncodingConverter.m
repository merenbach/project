//
//  TCEncodingConverter.m
//  Transcoder
//
//  Created by Andrew Merenbach on 1/25/08.
//  Copyright 2008-2010 Andrew Merenbach. All rights reserved.
//

#import "TCEncodingConverter.h"
#import "TCStringEncodingWrapper.h"


@implementation TCEncodingConverter

@synthesize sourceString = m_sourceString;
@synthesize targetString = m_targetString;
@synthesize sourceEncodingWrapper = m_sourceEncodingWrapper;
@synthesize medianEncodingWrapper = m_medianEncodingWrapper;
@synthesize targetEncodingWrapper = m_targetEncodingWrapper;
@synthesize skipMedianEncoding = m_skipMedianEncoding;
@synthesize allowsLossyConversion = m_allowsLossyConversion;

- (id)init {
	self = [super init];
	if (self) {
		m_sourceString = [[NSString alloc] initWithString:@""];
		m_targetString = [[NSString alloc] initWithString:@""];
		m_sourceEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		m_medianEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		m_targetEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		m_skipMedianEncoding = NO;
		m_allowsLossyConversion = NO;
	}
	return self;
}

- (id)initWithString:(NSString *)string {
	self = [self init];
	if (self) {
		m_sourceString = [string copy];
	}
	return self;
}

- (void)dealloc {
    [m_sourceString release];
    m_sourceString = nil;
    
    [m_targetString release];
    m_targetString = nil;
    
    [m_sourceEncodingWrapper release];
    m_sourceEncodingWrapper = nil;
	
	[m_medianEncodingWrapper release];
	m_medianEncodingWrapper = nil;
    
    [m_targetEncodingWrapper release];
    m_targetEncodingWrapper = nil;
    
    [super dealloc];
}

- (void)main {
	[self convert];
}

- (void)convert {
	if (self.isCancelled) return;

	BOOL skipMedian = self.skipMedianEncoding;
	
	NSString *newTargetString = @"";

	if (skipMedian) {
		newTargetString = [self convertedStringWithoutMedianEncoding];
	} else {
		newTargetString = [self convertedStringWithMedianEncoding];
	}

	if (self.isCancelled) return;
	self.targetString = newTargetString;
}

- (NSString *)convertedStringWithMedianEncoding {
	if (self.isCancelled) return nil;

	NSString *newTargetString = @"";
	
	NSString *source = self.sourceString;
	
	if (source != nil) {
		NSStringEncoding sourceEncoding = self.sourceEncodingWrapper.convertedStringEncoding;
		NSStringEncoding medianEncoding = self.medianEncodingWrapper.convertedStringEncoding;
		NSStringEncoding targetEncoding = self.targetEncodingWrapper.convertedStringEncoding;
		//BOOL skipMedian = self.skipMedianEncoding;
		BOOL allowLossy = self.allowsLossyConversion;

		NSData *translationData1 = [source dataUsingEncoding:sourceEncoding
										allowLossyConversion:allowLossy];
		
		if (self.isCancelled) return nil;
		if (translationData1 != nil) {
			newTargetString = [[[NSString alloc] initWithData:translationData1
													 encoding:medianEncoding] autorelease];
			if (self.isCancelled) return nil;
			if (newTargetString != nil) {
				NSData *translationData2 = [newTargetString
											dataUsingEncoding:medianEncoding
											allowLossyConversion:allowLossy];
				if (self.isCancelled) return nil;
				if (translationData2 != nil) {
					newTargetString = [[[NSString alloc] initWithData:translationData2
															 encoding:targetEncoding] autorelease];
					
					if (self.isCancelled) return nil;
					if (newTargetString == nil) {
						// invalid output
						newTargetString = @"Unable to convert between encodings.";
					}
				} else {
					newTargetString = @"Unable to convert data without loss.  Select \"Allow lossy conversion\" first to proceed.";
				}
			} else {
				// invalid output
				newTargetString = @"Unable to convert between encodings.";
			}
			
		}
		else {
			newTargetString = @"Unable to convert data without loss.  Select \"Allow lossy conversion\" first to proceed.";
		}
	}

	return newTargetString;
}

- (NSString *)convertedStringWithoutMedianEncoding {
	if (self.isCancelled) return nil;
	NSString *newTargetString = @"";
	
	NSString *source = self.sourceString;

	if (self.isCancelled) return nil;
	if (source != nil) {
		NSStringEncoding sourceEncoding = self.sourceEncodingWrapper.convertedStringEncoding;
		//NSStringEncoding medianEncoding = self.medianEncodingWrapper.convertedStringEncoding;
		NSStringEncoding targetEncoding = self.targetEncodingWrapper.convertedStringEncoding;
		//BOOL skipMedian = self.skipMedianEncoding;
		BOOL allowLossy = self.allowsLossyConversion;

		NSData *translationData = [source dataUsingEncoding:sourceEncoding allowLossyConversion:allowLossy];
		
		if (self.isCancelled) return nil;
		if (translationData != nil) {
			newTargetString = [[[NSString alloc] initWithData:translationData encoding:targetEncoding] autorelease];
			
			if (self.isCancelled) return nil;
			if (newTargetString == nil) {
				// invalid output
				newTargetString = @"Unable to convert between encodings.";
			}
		} else {
			newTargetString = @"Unable to convert data without loss.  Select \"Allow lossy conversion\" first to proceed.";
		}
	}
	
	return newTargetString;
}

@end
