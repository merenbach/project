//
//  XQScriptCommands.h
//  Quotient
//
//  Created by Andrew Merenbach on 21/11/06.
//  Copyright 2006-2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TCBasicScriptCommand : NSScriptCommand {
}

- (id)performDefaultImplementation;
- (NSString *)evaluateTranscodeCommand;

@end
