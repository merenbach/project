//
//  TCEncodingsWindowController.h
//  Transcoder
//
//  Created by Andrew Merenbach on 2/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


extern NSString *TCChangedSourceEncodingNotificationName;
extern NSString *TCChangedMedianEncodingNotificationName;
extern NSString *TCChangedTargetEncodingNotificationName;


@class TCEncodingController;


@interface TCEncodingsWindowController : NSWindowController {
	NSArrayController *m_encodingsArrayController;
	TCEncodingController *m_encodingController;
	NSSegmentedControl *m_assignmentSegmentedControl;
}

@property (assign) IBOutlet NSArrayController *encodingsArrayController;
@property (assign) IBOutlet TCEncodingController *encodingController;
@property (assign) IBOutlet NSSegmentedControl *assignmentSegmentedControl;

- (void)windowDidLoad;
- (void)prepareEncodings;
- (CFStringEncoding)currentStringEncodingSelection;
- (IBAction)changeEncoding:(id)sender;

- (IBAction)assignSourceEncoding:(id)sender;
- (IBAction)assignMedianEncoding:(id)sender;
- (IBAction)assignTargetEncoding:(id)sender;

@end
