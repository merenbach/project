//
//  XQScriptCommands.m
//  Quotient
//
//  Created by Andrew Merenbach on 21/11/06.
//  Copyright 2006-2010 Andrew Merenbach. All rights reserved.
//

#import "TCScriptCommands.h"
#import "TCMainWindowController.h"
#import "TranscoderAppDelegate.h"
#import "TCEncodingConverter.h"
#import "TCStringEncodingWrapper.h"


@implementation TCBasicScriptCommand

- (id)performDefaultImplementation {
    id returnValue = nil;

    TranscoderAppDelegate *delegate = [NSApp delegate];

    NSString *commandName = [[self commandDescription] commandName];
    if ([commandName isEqualToString:@"transcode"]) {
		[delegate.mainWindowController transcodeText:self];
		
    } else if ([commandName isEqualToString:@"exchange encodings"]) {
		[delegate exchangeEncodingsScriptingCover:self];
		
	} else if ([commandName isEqualToString:@"transcode text"]) {
        returnValue = [self evaluateTranscodeCommand];
        
    }
    
    return returnValue;
}

- (NSString *)evaluateTranscodeCommand {
	NSString *retVal = nil;
	
	//TranscoderAppDelegate *delegate = [NSApp delegate];

	NSDictionary *args = [self evaluatedArguments];
	NSString *textArg = [args objectForKey:@""];
	NSString *sArg = [args objectForKey:@"sourceEncoding"];
	NSString *mArg = [args objectForKey:@"medianEncoding"];	// optional
	NSString *tArg = [args objectForKey:@"targetEncoding"];

	NSNumber *skipMedianNumber = [args objectForKey:@"skipMedianEncoding"];
	NSNumber *allowLossyNumber = [args objectForKey:@"allowLossyConversion"];
	
	NSInteger sNum = [sArg integerValue];
	NSInteger mNum = [mArg integerValue];
	NSInteger tNum = [tArg integerValue];

	BOOL skipMedian = [skipMedianNumber boolValue];
	BOOL allowLossy = [allowLossyNumber boolValue];
	
	TCStringEncodingWrapper *sWrap = [TCStringEncodingWrapper wrapperWithEncoding:sNum];
	TCStringEncodingWrapper *mWrap = [TCStringEncodingWrapper wrapperWithEncoding:mNum];
	TCStringEncodingWrapper *tWrap = [TCStringEncodingWrapper wrapperWithEncoding:tNum];

	TCEncodingConverter *converter = [[TCEncodingConverter alloc] init];
	converter.sourceString = textArg;
	converter.sourceEncodingWrapper = sWrap;
	converter.medianEncodingWrapper = mWrap;
	converter.targetEncodingWrapper = tWrap;
	converter.allowsLossyConversion = allowLossy;
	converter.skipMedianEncoding = skipMedian;
	
	[converter convert];
	retVal = converter.targetString;
	
	[converter release];
	
	return retVal;
}

@end
