//
//  TCMainWindowController.m
//  Transcoder
//
//  Created by Andrew Merenbach on 4/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "TCMainWindowController.h"
#import "TCEncodingsWindowController.h"
#import "TCStringEncodingWrapper.h"
#import "TCEncodingConverter.h"

CGFloat TCMinimumHeightForSourceTextView = 80;
CGFloat TCMinimumHeightForTargetTextView = 80;


@implementation TCMainWindowController

@synthesize sourceTextView = m_sourceTextView;
@synthesize targetTextView = m_targetTextView;
@synthesize textSplitView = m_textSplitView;
@synthesize skipMedianEncoding = m_skipMedianEncoding;
@synthesize allowsLossyConversion = m_allowsLossyConversion;
@synthesize sourceString = m_sourceString;
@synthesize targetString = m_targetString;
@synthesize sourceEncodingWrapper = m_sourceEncodingWrapper;
@synthesize medianEncodingWrapper = m_medianEncodingWrapper;
@synthesize targetEncodingWrapper = m_targetEncodingWrapper;

@synthesize opQueue = m_opQueue;

- (id)init {
	self = [super initWithWindowNibName:@"MainWindow"];
	if (self != nil) {
		m_opQueue = [[NSOperationQueue alloc] init];
		
		//self.allEncodings = nil;
		m_skipMedianEncoding = NO;
		m_allowsLossyConversion = NO;
		m_sourceString = [@"" copy];
		m_targetString = [@"" copy];
		m_sourceEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		m_medianEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		m_targetEncodingWrapper = [[TCStringEncodingWrapper alloc] init];
		
		converters = [[NSMutableArray alloc] init];
	}		
	return self;
}
	
- (void)dealloc {
	[m_opQueue release];
	m_opQueue = nil;
	
	[m_sourceString release];
	m_sourceString = nil;
	
	[m_medianEncodingWrapper release];
	m_medianEncodingWrapper = nil;
	
	[m_targetString release];
	m_targetString = nil;
	
	[m_sourceEncodingWrapper release];
	m_sourceEncodingWrapper = nil;
	
	[m_targetEncodingWrapper release];
	m_targetEncodingWrapper = nil;
	
	//[m_encodingConverter release];
	//m_encodingConverter = nil;
	
	[converters release];
	converters = nil;
	
	[super dealloc];
}

- (void)transcodeText:(id)sender {
	NSString *currentTargetString = self.targetString;
	NSUndoManager *um = [self.targetTextView undoManager];
	[um registerUndoWithTarget:self selector:@selector(revertTargetString:) object:currentTargetString];
	
	[self transcode];
}

- (IBAction)changeSourceEncoding:(NSNotification *)notification {
	TCStringEncodingWrapper *wrapper = [notification object];
	self.sourceEncodingWrapper = wrapper;
	//[[NSNotificationCenter defaultCenter] postNotificationName:@"TCEncodingsChanged" object:self];
}

- (IBAction)changeMedianEncoding:(NSNotification *)notification {
	TCStringEncodingWrapper *wrapper = [notification object];
	self.medianEncodingWrapper = wrapper;
	//[[NSNotificationCenter defaultCenter] postNotificationName:@"TCEncodingsChanged" object:self];
}

- (IBAction)changeTargetEncoding:(NSNotification *)notification {
	TCStringEncodingWrapper *wrapper = [notification object];
	self.targetEncodingWrapper = wrapper;
	//[[NSNotificationCenter defaultCenter] postNotificationName:@"TCEncodingsChanged" object:self];
}

- (void)exchangeEncodings:(id)sender {
	id tempSource = self.sourceEncodingWrapper;
	id tempTarget = self.targetEncodingWrapper;
	
	NSString *tempSourceText = self.sourceString;
	NSString *tempTargetText = self.targetString;
	
	self.sourceEncodingWrapper = tempTarget;
	self.targetEncodingWrapper = tempSource;
	
	self.sourceString = tempTargetText;
	self.targetString = tempSourceText;
}

/*- (NSStringEncoding)sourceEncoding {
 return self.sourceEncodingWrapper.convertedStringEncoding;
 }
 
 - (NSStringEncoding)medianEncoding {
 return self.medianEncodingWrapper.convertedStringEncoding;
 }
 
 - (NSStringEncoding)targetEncoding {
 return self.targetEncodingWrapper.convertedStringEncoding;
 }*/

- (void)transcode {
	TCEncodingConverter *converter = [[TCEncodingConverter alloc] initWithString:self.sourceString];
	converter.skipMedianEncoding = self.skipMedianEncoding;
	converter.allowsLossyConversion = self.allowsLossyConversion;
	converter.sourceEncodingWrapper = self.sourceEncodingWrapper;
	converter.medianEncodingWrapper = self.medianEncodingWrapper;
	converter.targetEncodingWrapper = self.targetEncodingWrapper;
	
	[converter addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
	
	[converters addObject:converter];
	[self.opQueue addOperation:converter];
	
	[converter release];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	TCEncodingConverter *converter = object;
	
	if ([keyPath isEqualToString:@"isFinished"] && [converters containsObject:converter]) {
		//self.targetString = converter.targetString;	// are we on a different thread...?
		[self performSelectorOnMainThread:@selector(finishTranscodingWithConverter:) withObject:converter waitUntilDone:YES];
	} else {
		[super observeValueForKeyPath:keyPath
							 ofObject:object
							   change:change
							  context:context];
	}
}

- (void)finishTranscodingWithConverter:(TCEncodingConverter *)converter {
	[converter removeObserver:self forKeyPath:@"isFinished"];
	
	self.targetString = converter.targetString;
	//self.sourceString = converter.targetString;
	[converters removeObject:converter];
}

- (void)loadAllValuesFromDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    self.sourceString = [userDefaults objectForKey:@"sourceString"];
    self.targetString = [userDefaults objectForKey:@"targetString"];
	self.skipMedianEncoding = [userDefaults boolForKey:@"skipMedianEncoding"];
	self.allowsLossyConversion = [userDefaults boolForKey:@"allowsLossyConversion"];
	
	NSInteger sourceEncoding = [userDefaults integerForKey:@"sourceEncoding"];
	NSInteger medianEncoding = [userDefaults integerForKey:@"medianEncoding"];
	NSInteger targetEncoding = [userDefaults integerForKey:@"targetEncoding"];
	
	TCStringEncodingWrapper *sourceWrapper = [TCStringEncodingWrapper wrapperWithEncoding:sourceEncoding];
	TCStringEncodingWrapper *medianWrapper = [TCStringEncodingWrapper wrapperWithEncoding:medianEncoding];
	TCStringEncodingWrapper *targetWrapper = [TCStringEncodingWrapper wrapperWithEncoding:targetEncoding];
	
	self.sourceEncodingWrapper = sourceWrapper;
	self.medianEncodingWrapper = medianWrapper;
	self.targetEncodingWrapper = targetWrapper;
}

- (void)saveAllValuesToDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:self.sourceString forKey:@"sourceString"];
    [userDefaults setObject:self.targetString forKey:@"targetString"];
    [userDefaults setBool:self.skipMedianEncoding forKey:@"skipMedianEncoding"];
    [userDefaults setBool:self.allowsLossyConversion forKey:@"allowsLossyConversion"];
	
	TCStringEncodingWrapper *sourceWrapper = self.sourceEncodingWrapper;
	TCStringEncodingWrapper *medianWrapper = self.medianEncodingWrapper;
	TCStringEncodingWrapper *targetWrapper = self.targetEncodingWrapper;
	
	NSInteger sourceEncoding = sourceWrapper.internalStringEncoding;
	NSInteger medianEncoding = medianWrapper.internalStringEncoding;
	NSInteger targetEncoding = targetWrapper.internalStringEncoding;
	
	[userDefaults setInteger:sourceEncoding forKey:@"sourceEncoding"];
	[userDefaults setInteger:medianEncoding forKey:@"medianEncoding"];
	[userDefaults setInteger:targetEncoding forKey:@"targetEncoding"];
}

/*- (void)toggleLossyConversion:(id)sender {
 [self setAllowLossyConversion:![self allowLossyConversion]];
 }*/

/*- (BOOL)validateToolbarItem:(NSToolbarItem *)theItem
 {
 BOOL flag = YES;
 
 if ([[theItem itemIdentifier] isEqualToString:@"Lossy"]) {
 BOOL lossyAllowed = [self allowLossyConversion];
 
 NSImage *image = lossyAllowed ? [NSImage imageNamed:@"Remove"] : [NSImage imageNamed:@"Add"];
 NSString *label = lossyAllowed ? @"Lossy" : @"Non-Lossy";
 
 [theItem setImage:image];
 [theItem setLabel:label];
 }	
 return flag;
 }*/

@end


@implementation TCMainWindowController (SplitViewDelegateMethods)

- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
	CGFloat newPosition = proposedPosition;
	if (sender == self.textSplitView) {
		if (proposedPosition < TCMinimumHeightForSourceTextView) {
			newPosition = TCMinimumHeightForSourceTextView;
		} else if (proposedPosition > NSHeight([sender frame]) - TCMinimumHeightForTargetTextView) {
			newPosition = NSHeight([sender frame]) - TCMinimumHeightForTargetTextView;
		}
	}
	return newPosition;
}

/*  During live resize of the window, lock the left side, the collection
 side, and resize the tableside
 The frames have to be set to add up to the total size minus the divider
 thickness */
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize {
	if (sender == self.textSplitView) {
		//detect if it's a window resize
		if ([sender inLiveResize]) {
			CGFloat dt = [sender dividerThickness];
			
			//info needed
			NSRect tmpRect = [sender bounds];
			NSArray *subviews =  [sender subviews];
			NSView *collectionsSide = [subviews objectAtIndex:0];
			NSView *tableSide = [subviews objectAtIndex:1];
			CGFloat collectionHeight = [collectionsSide bounds].size.height;
			
			//tableside frame: full size minus collection width and divider
			// My divider thickness is hard coded here as 1
			tmpRect.size.height = tmpRect.size.height - collectionHeight - dt;
			tmpRect.origin.y = tmpRect.origin.y + collectionHeight + dt;
			[tableSide setFrame:tmpRect];
			
			//collection frame stays the same
			tmpRect.size.height = collectionHeight;
			tmpRect.origin.y = 0;
			[collectionsSide setFrame:tmpRect];
		}
		else {
			// this is needed since we use autosave
			[sender adjustSubviews];
		}
	}
}

- (void)windowDidResize:(NSNotification *)notification {
	NSWindow *window = [notification object];
	if (window == self.window) {
		NSSplitView *sv = self.textSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat h = NSHeight(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (h < (TCMinimumHeightForTargetTextView - dt)) {
			h = TCMinimumHeightForTargetTextView - dt;
			
			// get the differential between the height we want and the height of the bottom rectangle
			CGFloat diff = h - NSHeight(rect);
			
			// resize the top view to the new height and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.height -= diff;
			topRect.origin.y += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}
	}
}

/*- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize
 {
 NSRect newFrame = [sender frame];
 CGFloat dt = [sender dividerThickness];
 
 //NSView *leftView = self.splitViewBottomView;
 //NSView *rightView = self.splitViewTopView;
 NSView *leftView = self.splitViewTopView;
 NSView *rightView = self.splitViewBottomView;
 
 // this is the fixed view (right)
 // on top on being fixed it is also collapsible
 NSRect rightFrame = [self.splitViewBottomView frame];
 // this is the flexible view (left)
 NSRect leftFrame = [self.splitViewTopView frame];
 
 rightFrame.size.height = newFrame.size.height;
 leftFrame.size.height = newFrame.size.height;
 
 if (![self.recordsSplitView isSubviewCollapsed:rightView]) {
 NSLog(@"not collapsed");
 rightFrame.origin.x = newFrame.size.width - rightFrame.size.width;
 rightFrame.origin.y = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - rightFrame.size.width - dt;
 } else {
 NSLog(@"collapsed");
 rightFrame.origin.x = newFrame.size.width;
 rightFrame.origin.y = 0;
 rightFrame.size.width = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - dt;
 }
 [leftView setFrame: leftFrame];
 [rightView setFrame:rightFrame];
 }*/

@end
