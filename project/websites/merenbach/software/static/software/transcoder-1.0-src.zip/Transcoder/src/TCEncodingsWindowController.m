//
//  TCEncodingsWindowController.m
//  Transcoder
//
//  Created by Andrew Merenbach on 2/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "TCEncodingsWindowController.h"
#import "TCStringEncodingWrapper.h"

NSString *TCChangedSourceEncodingNotificationName = @"TCChangedSourceEncoding";
NSString *TCChangedMedianEncodingNotificationName = @"TCChangedMedianEncoding";
NSString *TCChangedTargetEncodingNotificationName = @"TCChangedTargetEncoding";


@implementation TCEncodingsWindowController

@synthesize encodingsArrayController = m_encodingsArrayController;
@synthesize encodingController = m_encodingController;
@synthesize assignmentSegmentedControl = m_assignmentSegmentedControl;

- (id)init {
	self = [super initWithWindowNibName:@"Encodings"];
	return self;
}

- (void)windowDidLoad {
	[self prepareEncodings];
	
	/* set up initial sort descriptor priorities */
	NSSortDescriptor *nameSortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"stringEncodingName" ascending:YES] autorelease];
	NSSortDescriptor *valueSortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"stringEncodingNumber" ascending:YES] autorelease];
	[self.encodingsArrayController setSortDescriptors:[NSArray arrayWithObjects:valueSortDescriptor, nameSortDescriptor, nil]];
	//[encodingsArrayController rearrangeObjects];	// not currently necessary?
	//[encodingsTableView reloadData];	// not currently necessary?
}

- (void)prepareEncodings {
	NSMutableArray *encodings = [NSMutableArray array];
	
	const CFStringEncoding *availableEncodings = CFStringGetListOfAvailableEncodings();
	
	while (*availableEncodings != kCFStringEncodingInvalidId) {
		TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:*availableEncodings++];
		[encodings addObject:wrapper];
	}
	
	[self.encodingsArrayController setContent:[NSArray arrayWithArray:encodings]];
	//self.allEncodings = encodings;
}

- (CFStringEncoding)currentStringEncodingSelection {
	CFStringEncoding encoding = 0;
	
	TCStringEncodingWrapper *wrapper = [[self.encodingsArrayController selectedObjects] lastObject];
	NSValue *value = wrapper.stringEncodingValue;
	
	//id proxyWrapper = [self.encodingsArrayController selection];
	//NSValue *proxyValue = [proxyWrapper valueForKey:@"stringEncodingValue"];
	
	if (wrapper != nil && value != nil) {
		[value getValue:&encoding];
	} else {
		encoding = CFStringGetSystemEncoding();
	}
	
	return encoding;
}

- (IBAction)changeEncoding:(id)sender {
	if (sender == self.assignmentSegmentedControl) {
		NSInteger tag = [[sender cell] tagForSegment:[sender selectedSegment]];
		
		switch(tag) {
			case 1:	// source
				[self assignSourceEncoding:sender];
				break;

			case 2:	// median
				[self assignMedianEncoding:sender];
				break;
				
			case 3:	// target
				[self assignTargetEncoding:sender];
				break;
				
			default:
				// do nothing
				break;
		}
	}
}

- (IBAction)assignSourceEncoding:(id)sender {
	CFStringEncoding encoding = [self currentStringEncodingSelection];
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:encoding];
	[[NSNotificationCenter defaultCenter] postNotificationName:TCChangedSourceEncodingNotificationName object:wrapper];
}

- (IBAction)assignMedianEncoding:(id)sender {
	CFStringEncoding encoding = [self currentStringEncodingSelection];
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:encoding];
	[[NSNotificationCenter defaultCenter] postNotificationName:TCChangedMedianEncodingNotificationName object:wrapper];
}

- (IBAction)assignTargetEncoding:(id)sender {
	CFStringEncoding encoding = [self currentStringEncodingSelection];
	TCStringEncodingWrapper *wrapper = [TCStringEncodingWrapper wrapperWithEncoding:encoding];
	[[NSNotificationCenter defaultCenter] postNotificationName:TCChangedTargetEncodingNotificationName object:wrapper];				
}


@end
