//
//  TCStringEncodingWrapper.m
//  StringFixer
//
//  Created by Andrew Merenbach on 26/11/2004.
//  Copyright 2004-2010 Andrew Merenbach. All rights reserved.
//

#import "TCStringEncodingWrapper.h"

@implementation TCStringEncodingWrapper

/* other requisite methods */
/*- (NSComparisonResult)compare:(id)otherValue {
	return [AM_stringEncodingValue compare:otherValue];
}*/

/*- (BOOL)isEqualToValue:(NSValue *)aValue {
	return [AM_stringEncodingValue isEqualToValue:aValue];
}*/

- (id)init {
	self = [super init];
	if (self) {
		CFStringEncoding anEncoding = CFStringGetSystemEncoding();

		m_internalStringEncoding = anEncoding;
		m_stringEncodingName = [[NSString alloc] initWithString:(NSString *)CFStringGetNameOfEncoding(anEncoding)];
		m_stringEncodingNumber = [[NSNumber alloc] initWithUnsignedLong:anEncoding];
		m_stringEncodingValue = [[NSValue alloc] initWithBytes:&anEncoding objCType:@encode(CFStringEncoding)];
	}
	return self;
}

- (id)initWithEncoding:(CFStringEncoding)anEncoding {
	self = [self init];
	if (self) {
		m_internalStringEncoding = anEncoding;
		m_stringEncodingName = [[NSString alloc] initWithString:(NSString *)CFStringGetNameOfEncoding(anEncoding)];
		m_stringEncodingNumber = [[NSNumber alloc] initWithUnsignedLong:anEncoding];
		m_stringEncodingValue = [[NSValue alloc] initWithBytes:&anEncoding objCType:@encode(CFStringEncoding)];
	}
	return self;
}

- (void)dealloc {
    [m_stringEncodingName release];
    m_stringEncodingName = nil;
    
    [m_stringEncodingNumber release];
    m_stringEncodingNumber = nil;
    
    [m_stringEncodingValue release];
    m_stringEncodingValue = nil;
    
    [super dealloc];
}

+ (id)wrapperWithEncoding:(CFStringEncoding)anEncoding {
	return [[[[self class] alloc] initWithEncoding:anEncoding] autorelease];
}

- (NSString *)description {
	return [NSString stringWithFormat:@"%@ (%@)", self.stringEncodingName, self.stringEncodingNumber];
}

- (NSStringEncoding)convertedStringEncoding {
	return CFStringConvertEncodingToNSStringEncoding(self.internalStringEncoding);
}

@synthesize internalStringEncoding = m_internalStringEncoding;
@synthesize stringEncodingName = m_stringEncodingName;
@synthesize stringEncodingNumber = m_stringEncodingNumber;
@synthesize stringEncodingValue = m_stringEncodingValue;

@end

/*@implementation TCValueToNumberValueTransformer

+ (Class)transformedValueClass { return [NSNumber class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	return [NSNumber numberWithUnsignedLong:[value unsignedLongValue]];
}

@end
*/