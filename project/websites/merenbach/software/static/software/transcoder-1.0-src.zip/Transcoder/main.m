//
//  main.m
//  Transcoder
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
