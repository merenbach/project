//
//  TCEncodingConverter.h
//  Transcoder
//
//  Created by Andrew Merenbach on 1/25/08.
//  Copyright 2008-2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class TCStringEncodingWrapper;


@interface TCEncodingConverter : NSOperation {
	// property ivars
	NSString *m_sourceString;
	NSString *m_targetString;
	TCStringEncodingWrapper *m_sourceEncodingWrapper;
	TCStringEncodingWrapper *m_medianEncodingWrapper;
	TCStringEncodingWrapper *m_targetEncodingWrapper;
	BOOL m_skipMedianEncoding;
	BOOL m_allowsLossyConversion;
}

@property (copy, readwrite) NSString *sourceString;
@property (copy, readwrite) NSString *targetString;
@property (retain, readwrite) TCStringEncodingWrapper *sourceEncodingWrapper;
@property (retain, readwrite) TCStringEncodingWrapper *medianEncodingWrapper;
@property (retain, readwrite) TCStringEncodingWrapper *targetEncodingWrapper;
@property (assign, readwrite) BOOL skipMedianEncoding;
@property (assign, readwrite) BOOL allowsLossyConversion;

- (id)init;
- (id)initWithString:(NSString *)string;
- (void)dealloc;
- (void)main;
- (void)convert;

- (NSString *)convertedStringWithMedianEncoding;
- (NSString *)convertedStringWithoutMedianEncoding;

@end
