//
//  TCMainWindowController.h
//  Transcoder
//
//  Created by Andrew Merenbach on 4/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class TCEncodingController;
@class TCStringEncodingWrapper;
@class TCEncodingConverter;


@interface TCMainWindowController : NSWindowController {
	NSTextView *m_sourceTextView;
	NSTextView *m_targetTextView;
	NSSplitView *m_textSplitView;
	
	// property ivars
	//NSArray *allEncodings;
	BOOL m_allowsLossyConversion;
	BOOL m_skipMedianEncoding;
	NSString *m_sourceString;	
	NSString *m_targetString;
	TCStringEncodingWrapper *m_sourceEncodingWrapper;
	TCStringEncodingWrapper *m_medianEncodingWrapper;
	TCStringEncodingWrapper *m_targetEncodingWrapper;
	
	// other ivars
	NSOperationQueue *m_opQueue;
	//TCEncodingConverter *m_encodingConverter;
	
	NSMutableArray *converters;
}

@property (assign) IBOutlet NSTextView *sourceTextView;
@property (assign) IBOutlet NSTextView *targetTextView;
@property (assign) IBOutlet NSSplitView *textSplitView;
@property (assign, readwrite) BOOL skipMedianEncoding;
@property (assign, readwrite) BOOL allowsLossyConversion;
@property (copy, readwrite) NSString *sourceString;
@property (copy, readwrite) NSString *targetString;
@property (retain, readwrite) TCStringEncodingWrapper *sourceEncodingWrapper;
@property (retain, readwrite) TCStringEncodingWrapper *medianEncodingWrapper;
@property (retain, readwrite) TCStringEncodingWrapper *targetEncodingWrapper;

@property (retain, readwrite) NSOperationQueue *opQueue;

- (void)transcodeText:(id)sender;
- (IBAction)changeSourceEncoding:(id)sender;
- (IBAction)changeMedianEncoding:(id)sender;
- (IBAction)changeTargetEncoding:(id)sender;
//- (IBAction)changeEncoding:(id)sender;

- (void)exchangeEncodings:(id)sender;
- (void)transcode;
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
- (void)finishTranscodingWithConverter:(TCEncodingConverter *)converter;

- (void)loadAllValuesFromDefaults;
- (void)saveAllValuesToDefaults;

@end


@interface TCMainWindowController (SplitViewDelegateMethods)
//- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset;
//- (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset;
- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset;
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize;
- (void)windowDidResize:(NSNotification *)notification;
@end
