//
//  CBPopUpButton.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on Fri Jan 10 2003.
//  Copyright (c) 2003 Andrew Merenbach. All rights reserved.
//

#import "CBScalePopUpButton.h"
#import "CBCalculator.h"
#import "CBScaleMenu.h"


NSString *CBScaleHeatKey = @"CBHeatScales";
NSString *CBScaleMassKey = @"CBMassScales";
NSString *CBScaleMolesKey = @"CBMolarScales";
NSString *CBScalePressureKey = @"CBPressureScales";
NSString *CBScaleTemperatureKey = @"CBTemperatureScales";
NSString *CBScaleVolumeKey = @"CBVolumeScales";
NSString *CBScaleMassMolesKey = @"CBMassMoleScales";

NSString *CBScaleSeparatorKey = @"CBScaleSeparator";

/*static NSMenuItem *createMenuItem(NSString *title, int tag) {
	NSMenuItem *item = [[[NSMenuItem alloc] initWithTitle:NSLocalizedString(title,@"") action:NULL keyEquivalent:@""] autorelease];
	[item setRepresentedObject :title];
	[item setTag:tag];
	
	return item;
}*/

/*#define createMenuItem(title, tag) \
	[[[NSMenuItem alloc] initWithTitle:NSLocalizedString(title,@"") action:NULL keyEquivalent:@""] autorelease]*/

/*NSDictionary *menus() {
	static NSDictionary *dict = nil;
	
	if (!dict) {
		NSBundle *bundle = [NSBundle mainBundle];
		NSString *path = [bundle pathForResource:@"ScaleMenus" ofType:@"plist"];
		NSDictionary *loadedMenus = [[NSDictionary alloc] initWithContentsOfFile:path];
		NSEnumerator *categoryEnumerator = [loadedMenus keyEnumerator];
		id currentMenu;

		NSMutableDictionary *output = [[NSMutableDictionary alloc] init];
		
		while (currentMenu = [categoryEnumerator nextObject]) {
			NSMenu *menu = [[NSMenu alloc] initWithTitle:@""];
			NSEnumerator *titleEnumerator = [[loadedMenus objectForKey:currentMenu] objectEnumerator];
			id currentTitle;
			while (currentTitle = [titleEnumerator nextObject]) {
				if (![currentTitle isEqualToString:CBScaleSeparatorKey]) {
					NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:NSLocalizedStringFromTable(currentTitle, @"Scales", @"") action:NULL keyEquivalent:@""];
					[item setRepresentedObject:currentTitle];
					[menu addItem:item];
					[item release];
				} else {
					[menu addItem:[NSMenuItem separatorItem]];
				}
			}
			[output setObject:menu forKey:currentMenu];
			[menu release];
		}

		[loadedMenus release];
		
		dict = [output copy];
		[output release];

	}

	return dict;
}*/

/*static NSArray *menuContentsNew(NSString *key) {
	static NSDictionary *dict = nil;
	
	if (!dict) {
		NSBundle *bundle = [NSBundle mainBundle];	// [TODO] is this a kludge? shouldn't we be using our own bundle?
		NSString *path = [bundle pathForResource:@"Scales" ofType:@"plist"];
		dict = [[NSDictionary alloc] initWithContentsOfFile:path];
	}
	
	return [dict objectForKey:key];
}*/

#pragma mark -

@implementation NSPopUpButton (CBAdditions)

- (NSInteger)tagOfSelectedItem {
	return [[self cell] tagOfSelectedItem];
}

- (id)representedObjectOfSelectedItem {
	return [[self cell] representedObjectOfSelectedItem];
}

- (id)itemWithRepresentedObject:(id)anObject {
	return [self itemAtIndex:[self indexOfItemWithRepresentedObject:anObject]];
}

- (void)selectItemWithRepresentedObject:(id)anObject {
	[[self cell] selectItemWithRepresentedObject:anObject];
}

@end


@implementation NSPopUpButtonCell (CBAdditions)

- (NSInteger)tagOfSelectedItem {
	return [[self selectedItem] tag];
}

- (id)itemWithRepresentedObject:(id)anObject {
	return [self itemAtIndex:[self indexOfItemWithRepresentedObject:anObject]];
}

- (void)selectItemWithRepresentedObject:(id)anObject {
	[self selectItemAtIndex:[self indexOfItemWithRepresentedObject:anObject]];
}

- (id)representedObjectOfSelectedItem {
	return [[self selectedItem] representedObject];
}

@end

#pragma mark -

@implementation CBScalePopUpButton

@synthesize measurementScale = m_measurementScale;

- (id)initWithFrame:(NSRect)frameRect pullsDown:(BOOL)flag {
	self = [super initWithFrame:frameRect pullsDown:flag];
	if (self != nil) {
		//NSMenu *menu = [menus() objectForKey:[self category]];
		//[self setMenu:menu];
		//[menu release];
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
		
		m_measurementScale = [[CBMeasurementScale alloc] init];
		
		NSString *key = [self toolMenuBindingKey];
		
		if (key != nil && ![key isEqualToString:@""]) {
			[self bind:@"content" toObject:self.measurementScale withKeyPath:key options:nil];
			[self bind:@"contentObjects" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".self"] options:nil];
			[self bind:@"contentValues" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".localizedTitle"] options:nil];
			
			//m_initialScale = [[self.measurementScale valueForKey:key] objectAtIndex:0];
			
		}
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		//NSMenu *menu = [menus() objectForKey:[self category]];
		//[self setMenu:menu];
		//[menu release];
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
		
		m_measurementScale = [[CBMeasurementScale alloc] init];
		
		NSString *key = [self toolMenuBindingKey];
		
		if (key != nil && ![key isEqualToString:@""]) {
			[self bind:@"content" toObject:self.measurementScale withKeyPath:key options:nil];
			[self bind:@"contentObjects" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".self"] options:nil];
			[self bind:@"contentValues" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".localizedTitle"] options:nil];
		}
	}
	return self;
}
		 
- (void)finalize {
	[self unbind:@"content"];
	[self unbind:@"contentObjects"];
	[self unbind:@"contentValues"];
	
	[super finalize];
}

- (void)dealloc {
	[self unbind:@"content"];
	[self unbind:@"contentObjects"];
	[self unbind:@"contentValues"];
	
	[super dealloc];
}

- (NSString *)toolMenuBindingKey {
	return nil;
}

- (NSString *)category { return @"Dummy"; }

//- (BOOL)hasMolarScale { return [CBCalculator scaleIsMolar:[self representedObjectOfSelectedItem]]; }

@end

@implementation CBScalePopUpButtonCell

@synthesize measurementScale = m_measurementScale;

- (id)initTextCell:(NSString *)aString pullsDown:(BOOL)flag {
	self = [super initTextCell:aString pullsDown:flag];
	if (self != nil) {
		//NSMenu *menu = [menus() objectForKey:[self category]];
		//[self setMenu:menu];
		//[menu release];
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
		
		m_measurementScale = [[CBMeasurementScale alloc] init];
		
		NSString *key = [self toolMenuBindingKey];
		
		if (key != nil && ![key isEqualToString:@""]) {
			[self bind:@"content" toObject:self.measurementScale withKeyPath:key options:nil];
			[self bind:@"contentObjects" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".self"] options:nil];
			[self bind:@"contentValues" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".localizedTitle"] options:nil];
		}		
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		//NSMenu *menu = [menus() objectForKey:[self category]];
		//[self setMenu:menu];
		//[menu release];
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
		
		m_measurementScale = [[CBMeasurementScale alloc] init];
		
		NSString *key = [self toolMenuBindingKey];
		
		if (key != nil && ![key isEqualToString:@""]) {
			[self bind:@"content" toObject:self.measurementScale withKeyPath:key options:nil];
			[self bind:@"contentObjects" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".self"] options:nil];
			[self bind:@"contentValues" toObject:self.measurementScale withKeyPath:[key stringByAppendingString:@".localizedTitle"] options:nil];
		}		
	}
	return self;
}

- (void)finalize {
	[self unbind:@"content"];
	[self unbind:@"contentObjects"];
	[self unbind:@"contentValues"];
	
	[super finalize];
}

- (void)dealloc {
	[self unbind:@"content"];
	[self unbind:@"contentObjects"];
	[self unbind:@"contentValues"];
	
	[super dealloc];
}

- (NSString *)toolMenuBindingKey {
	return nil;
}

- (NSString *)category { return @"Dummy"; }

//- (BOOL)hasMolarScale { return [CBCalculator scaleIsMolar:[self representedObjectOfSelectedItem]]; }

@end

/*@implementation CBPopUpButtonMolarScaleSelectedVT

+ (Class)transformedValueClass { return [NSNumber class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
	NSNumber *num = nil;
	if (value != nil && [value boolValue] == YES) {
		//string = [NSString stringWithCharacters:&star length:1];
	}
	return string;
}

@end
*/