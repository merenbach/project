//
//  CBPeriodicTableLegendRecord.m
//  Valence
//
//  Created by Andrew Merenbach on 4/11/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableLegendRecord.h"


@implementation CBPeriodicTableLegendRecord

@synthesize color = m_color;
@synthesize title = m_title;
@dynamic localizedTitle;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_color = [[NSColor whiteColor] retain];
		m_title = [[NSString alloc] initWithString:@""];
	}
	return self;
}

+ (id)record {
	return [[[[self class] alloc] init] autorelease];	
}

- (void)dealloc {
	[m_color release];
	[m_title release];
	
	m_color = nil;
	m_title = nil;
	
	[super dealloc];
}

- (NSString *)localizedTitle {
	return NSLocalizedStringFromTable(self.title, @"PeriodicTable", self.title);	
}

@end
