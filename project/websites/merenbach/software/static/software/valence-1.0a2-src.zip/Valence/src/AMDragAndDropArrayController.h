//
//  AMDragAndDropArrayController.h
//  A sorting, rearrangeable NSArrayController subclass
//
//  Created by Andrew Merenbach on 7/24/07.
//  Copyright 2007-2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *MovedRowsType;
extern NSString *CopiedRowsType;
extern NSString *ArchivedRowsType;


@interface AMDragAndDropArrayController : NSArrayController {
	NSTableView *m_associatedTableView;

	BOOL m_isDraggingEnabled;
	BOOL m_isDroppingEnabled;
	BOOL m_isDraggingEnabledWithCopy;
}

@property (assign) IBOutlet NSTableView *associatedTableView;
@property (assign, readwrite) BOOL isDraggingEnabled;
@property (assign, readwrite) BOOL isDroppingEnabled;
@property (assign, readwrite) BOOL isDraggingEnabledWithCopy;
@property (copy, readonly) NSArray *pasteboardTypesForDragging;

- (NSArray *)pasteboardTypesForDragging;

@end


@interface AMDragAndDropArrayController (TableViewDataSource)
// table view drag and drop support

- (BOOL)tableView:(NSTableView *)tv
	writeRowsWithIndexes:(NSIndexSet *)rowIndexes
	toPasteboard:(NSPasteboard*)pboard;

- (NSDragOperation)tableView:(NSTableView*)tv
	validateDrop:(id <NSDraggingInfo>)info
	proposedRow:(NSInteger)row
	proposedDropOperation:(NSTableViewDropOperation)op;
    
- (BOOL)tableView:(NSTableView*)tv
	acceptDrop:(id <NSDraggingInfo>)info
	row:(NSInteger)row
	dropOperation:(NSTableViewDropOperation)op;


// utility methods

//- (void)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet 
//										toIndex:(NSUInteger)index;
//- (void)copyObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet 
//										toIndex:(NSUInteger)index;

- (NSIndexSet *)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)fromIndexSet 
												toIndex:(NSUInteger)index;
- (NSIndexSet *)copyObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet 
												toIndex:(NSUInteger)index;
//- (NSUInteger)rowsAboveRow:(NSUInteger)row inIndexSet:(NSIndexSet *)indexSet;

@end
