/* Tool */

#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class AMTableView;
@class AMDragAndDropArrayController;
@class CBExpressionTextField;

@interface CBEquilibriumTool : CBToolViewController
{
	AMTableView *m_reactantsTableView;
	AMTableView *m_productsTableView;
	
	AMDragAndDropArrayController *m_reactantsArrayController;
	AMDragAndDropArrayController *m_productsArrayController;
	
	NSArray *m_reactantsArray;
	NSArray *m_productsArray;
	
	double m_equilibriumValue;
	NSString *m_favoredSubstance;
}

@property (assign) IBOutlet AMTableView *reactantsTableView;
@property (assign) IBOutlet AMTableView *productsTableView;
@property (assign) IBOutlet AMDragAndDropArrayController *reactantsArrayController;
@property (assign) IBOutlet AMDragAndDropArrayController *productsArrayController;
@property (copy, readwrite) NSArray *reactantsArray;
@property (copy, readwrite) NSArray *productsArray;
@property (assign, readwrite) double equilibriumValue;
@property (copy, readwrite) NSString *favoredSubstance;

- (void)awakeFromNib;
- (IBAction)calculate:(id)sender;

@end