//
//  CBMolarMassCalculation.m
//  Valence
//
//  Created by Andrew Merenbach on 4/10/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMolarMassCalculation.h"
#import "CBFormulaEvaluator.h"
#import "CBExpressionEvaluator.h"


@implementation CBMolarMassCalculation

@synthesize formula = m_formula;
@synthesize molesPerGram = m_molesPerGram;
@synthesize gramsPerMole = m_gramsPerMole;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_formula = [[NSString alloc] initWithString:@""];
		m_molesPerGram = 0;
		m_gramsPerMole = 0;
	}
	return self;
}

- (void)dealloc {
	[m_formula release];
	m_formula = nil;
	
	[super dealloc];
}

- (void)main {
	NSString *formula = self.formula;
	if (formula != nil && ![formula isEqualToString:@""]) {
		CBFormulaEvaluator *formulaEvaluator = [[[CBFormulaEvaluator alloc] initWithFormula:formula] autorelease];
		NSString *equation = [formulaEvaluator evaluate];
		CBExpressionEvaluator *expressionEvaluator;
		NSDecimalNumber *molesPerGramTemp;
		NSDecimalNumber *gramsPerMoleTemp;
		
		if (nil != equation) {
			expressionEvaluator = [[[CBExpressionEvaluator alloc] initWithExpression:equation] autorelease];
			gramsPerMoleTemp = [expressionEvaluator evaluate];
			self.gramsPerMole = [gramsPerMoleTemp doubleValue];
			
			if (gramsPerMoleTemp != nil && ![gramsPerMoleTemp isEqualToNumber:[NSDecimalNumber zero]]) {
				molesPerGramTemp = [[NSDecimalNumber one] decimalNumberByDividingBy:gramsPerMoleTemp];
				self.molesPerGram = [molesPerGramTemp doubleValue];
			}
			
		}
		
		
		/*{
		 NSMutableArray *results = [[NSMutableArray alloc] init];
		 
		 NSDecimalNumber *result;
		 unsigned c;
		 NSArray *elements = [formulaEvaluator elements];
		 
		 NSEnumerator *e = [elements objectEnumerator];
		 NSString *element;
		 
		 while (element = [e nextObject]) {
		 
		 NSDecimalNumber *numberOfAtoms = [formulaEvaluator numberOfAtomsForSymbol:element];
		 NSDecimalNumber *mass = [formulaEvaluator massForSymbol:element];
		 NSDecimalNumber *percent = [NSDecimalNumber decimalNumberWithString:@"100"];
		 
		 NSDecimalNumber *result = [mass decimalNumberByMultiplyingBy:percent];
		 result = [result decimalNumberByDividingBy:output];
		 result = [result decimalNumberByMultiplyingBy:numberOfAtoms];
		 
		 NSDictionary *entry = [[NSDictionary alloc] initWithObjectsAndKeys:
		 element, @"elementSymbol",
		 result, @"elementPercentage",
		 nil];
		 [results addObject:entry];
		 [entry release];
		 }
		 
		 [percentageArrayController setContent:results];
		 [results release];
		 }*/
		
		{
			/*NSString *f;
			 if (NumAtoms[c]>1) {
			 f = [element stringByAppendingFormat:@"%i", NumAtoms[c]];
			 } else {
			 f = element;
			 }
			 
			 if (output) {
			 //[output compare:[NSDecimalNumber zero]] == NSOrderedDescending
			 result = a[ANofAtom[c]]["mass"]*NumAtoms[c]*100/parseFloat(MM);
			 } else {
			 result = [NSDecimalNumber zero];
			 }*/
		}
	}
}

@end
