//
//  CBToolsOutlineView.h
//  Valence
//
//  Created by Andrew Merenbach on 4/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AMOutlineView.h"


@interface CBToolsOutlineView : NSOutlineView {

}

- (NSRect)frameOfOutlineCellAtRow:(NSInteger)row;

@end
