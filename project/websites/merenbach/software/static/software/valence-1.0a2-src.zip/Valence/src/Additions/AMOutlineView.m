//
//  AMOutlineView.m
//  A subclass of NSOutlineView
//
//  Created by Andrew Merenbach on 1/1/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "AMOutlineView.h"

#define AM_SPACE_CHARACTER @" "


@implementation AMOutlineView

@synthesize am_consumedKeyDown = m_am_consumedKeyDown;

@synthesize spaceKeyAdds = m_spaceKeyAdds;
@synthesize enterKeyAdds = m_enterKeyAdds;
@synthesize deleteKeyRemoves = m_deleteKeyRemoves;
@synthesize spaceKeySendsDoubleAction = m_spaceKeySendsDoubleAction;
@synthesize enterKeySendsDoubleAction = m_enterKeySendsDoubleAction;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_am_consumedKeyDown = NO;	// for sanity, even though it gets set to NO at every call to -keyDown:
		
		m_spaceKeyAdds = NO;
		m_enterKeyAdds = NO;
		m_deleteKeyRemoves = NO;
		
		m_spaceKeySendsDoubleAction = NO;
		m_enterKeySendsDoubleAction = NO;
	}
	return self;
}

- (id)initWithFrame:(NSRect)frameRect {
	self = [super initWithFrame:frameRect];
	if (self != nil) {
		m_am_consumedKeyDown = NO;	// for sanity, even though it gets set to NO at every call to -keyDown:
		
		m_spaceKeyAdds = NO;
		m_enterKeyAdds = NO;
		m_deleteKeyRemoves = NO;
		
		m_spaceKeySendsDoubleAction = NO;
		m_enterKeySendsDoubleAction = NO;
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		m_am_consumedKeyDown = NO;	// for sanity, even though it gets set to NO at every call to -keyDown:
		
		m_spaceKeyAdds = NO;
		m_enterKeyAdds = NO;
		m_deleteKeyRemoves = NO;
		
		m_spaceKeySendsDoubleAction = NO;
		m_enterKeySendsDoubleAction = NO;
	}
	return self;
}

@end

@implementation AMOutlineView (DLKeyDownOperations)

- (void)keyDown:(NSEvent *)event {
    self.am_consumedKeyDown = NO;
    [self interpretKeyEvents:[NSArray arrayWithObject:event]]; 
    if (!self.am_consumedKeyDown) [super keyDown:event];
}

- (void)doCommandBySelector:(SEL)selector {
    self.am_consumedKeyDown = [self tryToPerform:selector with:nil]; 
}

/* credit to Daryn on Cocoa-dev */
- (void)scrollToRow:(NSInteger)row selectRow:(BOOL)select {
	NSIndexSet *indices = [NSIndexSet indexSetWithIndex:row];
	if (select) [self selectRowIndexes:indices byExtendingSelection:NO];
	[self scrollRowToVisible:row];
}

- (void)scrollLineUp:(id)sender {
	NSInteger row = 0;
	
	NSIndexSet *rows = [self selectedRowIndexes];
	if ([rows count] > 0) {
		row = [rows firstIndex];
	} else {
		row = (-1);
	}
	
	//NSInteger numberOfRows = [self numberOfRows];
	if (row > 0) {
		row--;
	}
	[self scrollToRow:row selectRow:YES];
}

- (void)scrollLineDown:(id)sender {
	NSInteger row = 0;
	
	NSIndexSet *rows = [self selectedRowIndexes];
	if ([rows count] > 0) {
		row = [rows lastIndex];
	} else {
		row = (-1);
	}
	
	NSInteger numberOfRows = [self numberOfRows];
	if (row < numberOfRows - 1) {
		row++;
	}
	[self scrollToRow:row selectRow:YES];
}

/*- (void)scrollLineUp:(id)sender {
	NSInteger row = [self selectedRow];
	if (row < 0) row = [self numberOfRows];
	if (--row >= 0) [self scrollToRow:row selectRow:YES];
}

- (void)scrollLineDown:(id)sender {
	NSInteger row = [self selectedRow];
	NSInteger numberOfRows = [self numberOfRows];
	if (row < 0) row = (-1);
	if (++row < numberOfRows) [self scrollToRow:row selectRow:YES];
}*/

- (void)moveDown:(id)sender {
	[self scrollLineDown:sender];
}

- (void)moveUp:(id)sender {
	[self scrollLineUp:sender];
}

- (void)scrollToBeginningOfDocument:(id)sender {
	NSInteger numberOfRows = [self numberOfRows];
	if (numberOfRows) [self scrollToRow:0 selectRow:NO];
}

- (void)scrollToEndOfDocument:(id)sender {
	NSInteger numberOfRows = [self numberOfRows];
	if (numberOfRows) [self scrollToRow:(numberOfRows - 1) selectRow:NO];
}

@end

@implementation AMOutlineView (DataMethods)

- (void)delete:(id)sender {
	if (self.deleteKeyRemoves) {
		id dataSource = [self dataSource];
		if ([dataSource respondsToSelector:@selector(remove:)]) {
			[dataSource performSelector:@selector(remove:) withObject:self];
		}
	}
}

- (void)deleteBackward:(id)sender {
	[self delete:sender];
}

- (void)deleteForward:(id)sender {
	[self delete:sender];
}

- (void)insertNewline:(id)sender {
	if (self.enterKeySendsDoubleAction && !self.enterKeyAdds) {
		[self sendAction:[self doubleAction] to:[self target]];
	} /*else if ([self returnKeyAdds] && ![self returnKeySendsDoubleAction]) {
		id dataSource = [self dataSource];
		if ([dataSource respondsToSelector:@selector(add:)]) {
			[dataSource performSelector:@selector(add:) withObject:self];
		}
	}*/ else {
		[super insertNewline:sender];
	}
}

- (void)insertText:(id)aString {
	if ([aString isEqualToString:AM_SPACE_CHARACTER]) {
		if (self.spaceKeySendsDoubleAction && !self.spaceKeyAdds) {
			[self sendAction:[self doubleAction] to:[self target]];
		} else if (self.spaceKeyAdds && !self.spaceKeySendsDoubleAction) {
			id dataSource = [self dataSource];
			if ([dataSource respondsToSelector:@selector(add:)]) {
				[dataSource performSelector:@selector(add:) withObject:self];
			}
		} else if (self.spaceKeyAdds && self.spaceKeySendsDoubleAction) {
			NSLog(@"[AMOutlineView] Invalid configuration: space key both adds and sends double action.");
		} else {
			// do nothing
		}
	}
}

@end
