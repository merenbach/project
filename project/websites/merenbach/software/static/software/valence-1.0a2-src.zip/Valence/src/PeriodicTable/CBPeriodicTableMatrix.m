//
//  CBPeriodicTableMatrix.m
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 05/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableMatrix.h"
//#import "CBPeriodicTableMatrix_Animation.h"

#import "CBPeriodicTableButtonCell.h"

#import "CBPeriodicTableValueTransformers.h"
#import "CBPeriodicTableElement.h"

// [TODO] set search menu to allow searches based on cell attributes!
//static float disabledAlphaPercentage = 25.0;

//#define AM_ELM_PTLocalizedKey(bundle, key) [bundle localizedStringForKey:key value:key table:@"PeriodicTable"]

const CGFloat ELM_PT_LABEL_SIZE = 10.0;

const CGFloat ELM_INTERCELL_WIDTH = 1.0;
const CGFloat ELM_INTERCELL_HEIGHT = 0.0;
//const float ELM_FOOTNOTE_LABEL_SIZE = 12.0;

@implementation CBPeriodicTableMatrix

@synthesize colorsDict = m_colorsDict;

@synthesize currentColorScheme = m_currentColorScheme;
@synthesize elementColorMap = m_elementColorMap;

+ (void)initialize {
	NSValueTransformer *vt;
	
	vt = [[ELMArrayLocalizationValueTransformer alloc] initWithTableName:@"PeriodicTable"];
	[NSValueTransformer setValueTransformer:vt forName:@"PeriodicTableKeyToNameLocalizer"];
	[vt release];
/*	[NSValueTransformer setValueTransformer:[[[CBPTColorNameValueTransformer alloc] init] autorelease]
		forName:@"CBPTColorNameValueTransformer"];
*/
}

/*- (NSString *)localizedPeriodicTableNameFor(NSString *)key inBundle:(NSBundle *)bundle {
	return [bundle localizedStringForKey:key value:key table:@"PeriodicTable"];
}*/

- (id)initWithFrame:(NSRect)frameRect {
	if (self = [super initWithFrame:frameRect]) {
		//NSString *path = [[NSBundle mainBundle] pathForResource:@"PeriodicTableColors" ofType:@"plist"];
		//m_colorsDict = [[NSDictionary alloc] initWithContentsOfFile:path];

		/* animation for search results */
		/*{
			foundAnimation = [[NSAnimation alloc] initWithDuration:2 animationCurve:NSAnimationEaseInOut];
			[foundAnimation setAnimationBlockingMode:NSAnimationNonblocking];
			[foundAnimation setDelegate:self];

			float i;
			for (i = 0; i <= 1; i += 0.05) {
				[foundAnimation addProgressMark:i];
			}
		}*/

		/*if (path = [[NSBundle mainBundle] pathForResource:@"PeriodicTableLegend" ofType:@"plist"] {
			AM_periodicTableLegend = [[NSDictionary alloc] initWithContentsOfFile:path];
		} else {
			// [TODO] error?
			AM_periodicTableLegend = [[NSDictionary allocWithZone:[self zone]] init];
		}*/
	}
	return self;
}

/*- (id)initWithFrame:(NSRect)frameRect mode:(int)aMode prototype:(NSCell *)aCell numberOfRows:(int)rowsHigh numberOfColumns:(int)colsWide {
	NSLog(@"2");
		return [super initWithFrame:frameRect mode:aMode prototype:aCell numberOfRows:rowsHigh numberOfColumns:colsWide];
}

- (id)initWithFrame:(NSRect)frameRect mode:(int)aMode cellClass:(Class)factoryId numberOfRows:(int)rowsHigh numberOfColumns:(int)colsWide {
	NSLog(@"3");
	return [super initWithFrame:frameRect mode:aMode cellClass:factoryId numberOfRows:rowsHigh numberOfColumns:colsWide];
}*/


- (void)dealloc {
	[m_colorsDict release];
	m_colorsDict = nil;
	
	//[cellArrayController release];
	//cellArrayController = nil;
	[connectorTransform release];
	[connector1 release];
	[connector2 release];

	connectorTransform = nil;
	connector1 = nil;
	connector2 = nil;

	//[self setAnimationTimer:nil];

	[elementCells release];
	elementCells = nil;

	[super dealloc];
}

- (void)awakeFromNib {
	{
		/*NSArray *colorKeys = [self.colorsDict allKeys];
		NSMutableDictionary *colorMap = [NSMutableDictionary dictionary];
		
		for (id theColorKey in colorKeys) {
			NSDictionary *colorSubdict = [self.colorsDict objectForKey:theColorKey];
			NSArray *colorSubdictKeys = [colorSubdict allKeys];
			NSMutableDictionary *colorSubMap = [[NSMutableDictionary alloc] init];
			
			for (id theColorRefKey in colorSubdictKeys) {
				NSArray *colorVals = [colorSubdict objectForKey:theColorRefKey];
				[colorSubMap setObject:[NSColor
					colorWithCalibratedRed:[[colorVals objectAtIndex:0] floatValue] / (CGFloat)100.0
						green:[[colorVals objectAtIndex:1] floatValue] / (CGFloat)100.0
						blue:[[colorVals objectAtIndex:2] floatValue] / (CGFloat)100.0
						alpha:1.0]
					forKey:theColorRefKey];
				
				[colorSubMap setObject:theColorKey forKey:@"name"];
					
			}
			[colorMap setObject:colorSubMap forKey:theColorKey];
			[colorSubMap release];
		}*/
		
		//self.elementColorMap = colorMap;
	}
	
	connectorTransform = [[NSAffineTransform transform] retain];

	connector1 = [[NSBezierPath bezierPath] retain];
	connector2 = [[NSBezierPath bezierPath] retain];
	
	CGFloat lineWidth = 1.0;
	[connector1 setLineWidth:lineWidth];
	[connector2 setLineWidth:lineWidth];
	
	CGFloat flatness = [NSBezierPath defaultFlatness];
	[connector1 setFlatness:flatness];
	[connector2 setFlatness:flatness];
	
	//[connector1 setCachesBezierPath:YES];
	//[connector2 setCachesBezierPath:YES];
	
	[self setMode:NSHighlightModeMatrix];
	[self setSelectionByRect:NO];
	[self setDrawsBackground:NO];
	//[self setAutosizesCells:YES];
	[self setPostsFrameChangedNotifications:YES];
	[self setTabKeyTraversesCells:YES];
		
	//[self prepareCells];	// shouldn't be here
	
	
	
}

- (void)drawRect:(NSRect)rect {
	/*[[NSColor grayColor] set];
	[NSBezierPath setDefaultLineWidth:2.0];
	[NSBezierPath strokeRect:rect];*/


	[super drawRect:rect];
	[self drawConnectors:rect];
	//[self drawFootnoteSeriesLabels:rect];
}

- (void)recalculateConnectorPaths {
	//cachedBoundsSizeForConnectors = [self bounds].size;

	NSInteger connectorTag1 = 56;
	NSCell *bariumCell = [self cellWithTag:connectorTag1];
	NSCell *lanthanumCell = [self cellWithTag:connectorTag1 + 1];
	
	NSInteger connectorTag2 = 88;
	NSCell *radiumCell = [self cellWithTag:connectorTag2];
	NSCell *actiniumCell = [self cellWithTag:connectorTag2 + 1];
	
	NSArray *connection1 = [NSArray arrayWithObjects:bariumCell, lanthanumCell, nil];
	NSArray *connection2 = [NSArray arrayWithObjects:radiumCell, actiniumCell, nil];
	NSArray *connections = [NSArray arrayWithObjects:connection1, connection2, nil];
	
	for (NSArray *connection in connections) {
		NSInteger row1, row2, col1, col2;
		
		[self getRow:&row1 column:&col1 ofCell:[connection objectAtIndex:0]];
		[self getRow:&row2 column:&col2 ofCell:[connection objectAtIndex:1]];
		
		//NSLog(@"row/col = %i, %i", row1, col1);
		//- (NSRect)cellFrameAtRow:(int)row column:(int)column
		NSRect sourceRect = [self cellFrameAtRow:row1 column:col1];
		NSRect destinationRect = [self cellFrameAtRow:row2 column:col2];
		
		NSPoint startPoint = NSMakePoint(NSMaxX(sourceRect), NSMidY(sourceRect));
		NSPoint endPoint = NSMakePoint(NSMinX(destinationRect), NSMidY(destinationRect));
		
		/*NSPoint midPoint = NSMakePoint(NSMidX(destinationRect) - NSMidX(sourceRect),
			NSMidY(destinationRect) - NSMidY(sourceRect));
		*/
		
		//NSRect unionRect = NSUnionRect(sourceRect, destinationRect);
		//NSPoint midPoint = NSMakePoint(NSMidX(unionRect), NSMidY(unionRect));
		
		CGFloat xDistance = NSMinX(destinationRect) - NSMaxX(sourceRect);
		//float yDistance = NSMinY(destinationRect) - NSMaxY(sourceRect);
		
		// what about *relative* control points to make calculations easier?		

		NSPoint curveControlPointAbove1, curveControlPointAbove2;
		
		if ([connection isEqual:connection1]) {
			curveControlPointAbove1 = NSMakePoint(NSMaxX(sourceRect) + xDistance * 4.0 / 6.0, NSMaxY(sourceRect));
			curveControlPointAbove2 = NSMakePoint(NSMaxX(sourceRect) + xDistance * 3.0 / 6.0, NSMinY(destinationRect));
			
			//[NSBezierPath strokeCurveFrom]
			[connector1 removeAllPoints];			
			[connector1 moveToPoint:startPoint];
			[connector1 curveToPoint:endPoint controlPoint1:curveControlPointAbove1 controlPoint2:curveControlPointAbove2];
		} else {
			curveControlPointAbove1 = NSMakePoint(NSMaxX(sourceRect) + xDistance * 3.0 / 6.0, NSMaxY(sourceRect));
			curveControlPointAbove2 = NSMakePoint(NSMaxX(sourceRect) + xDistance * 2.0 / 6.0, NSMinY(destinationRect));

			[connector2 removeAllPoints];
			[connector2 moveToPoint:startPoint];
			[connector2 curveToPoint:endPoint controlPoint1:curveControlPointAbove1 controlPoint2:curveControlPointAbove2];
		}
	}
}

- (void)handleResize {

/*NSLog(@"=======");
NSLog(@"cellSize = %@", NSStringFromSize([self cellSize]));
NSLog(@"selfSize = %@", NSStringFromRect([self frame]));
NSLog(@"selfRows = %i", [self numberOfRows]);
NSLog(@"selfCols = %i", [self numberOfColumns]);
NSLog(@"-------");
*/

	NSSize spacing = [self intercellSpacing];

	NSInteger numCols = 19;
	NSInteger numRows = 11;
	
	NSSize frameSize = [self frame].size;
	//[self setIntercellSpacing:NSMakeSize(-1.0, -1.0)];
	
	CGFloat cellWidth = frameSize.width / (CGFloat)numCols - spacing.width;
	CGFloat cellHeight = frameSize.height / (CGFloat)numRows - spacing.height;
	//[self setAutosizesCells:YES];
	[self setCellSize:NSMakeSize(cellWidth, cellHeight)];
	//NSLog(@"{rw, rh} = {%lf, %lf}", rowWidth, rowHeight);
	
/*NSLog(@"cellSize = %@", NSStringFromSize([self cellSize]));
NSLog(@"selfSize = %@", NSStringFromRect([self frame]));
NSLog(@"selfRows = %i", [self numberOfRows]);
NSLog(@"selfCols = %i", [self numberOfColumns]);
NSLog(@"========");
  */  
	[self recalculateConnectorPaths];
	//[self setNeedsDisplay:YES];
}


/*- (void)resizeSubviewsWithOldSize:(NSSize)oldBoundsSize {
	[super resizeSubviewsWithOldSize:oldBoundsSize];
	
	NSInteger numCols = 19;
	NSInteger numRows = 11;
	
	NSSize frameSize = [self frame].size;
	//[self setIntercellSpacing:NSMakeSize(-1.0, -1.0)];
	
	CGFloat rowHeight = frameSize.height / (CGFloat)numRows;
	CGFloat rowWidth = frameSize.width / (CGFloat)numCols;
	
	[self setCellSize:NSMakeSize(rowWidth, rowHeight)];
	
	
	[self recalculateConnectorPaths];
	[self setNeedsDisplay:YES];
	//NSSize newBoundsSize = [self bounds].size;
	//NSSize originalBoundSize = cachedFrameForConnectors.size;
	//NSLog(@"%@ -> %@ -> %@", NSStringFromSize(originalBoundSize), NSStringFromSize(oldBoundsSize), NSStringFromSize(newBoundsSize));
	//[connectorTransform scaleXBy:(newBoundsSize.width / originalBoundSize.width) yBy:(newBoundsSize.height / originalBoundSize.height)];
}*/

- (void)drawConnectors:(NSRect)rect {
	[NSGraphicsContext saveGraphicsState];

	NSShadow *shadow = [[NSShadow alloc] init];
	
	[shadow setShadowOffset:NSMakeSize(-2.0, -2.0)];
	[shadow setShadowBlurRadius:3.0];
	//[shadow setShadowColor:[NSColor shadowColor]];
	
	[shadow set];
		
	
	// set, concat?
	/*NSSize currentBoundsSize = [self bounds].size;
	NSAffineTransform *transform = [NSAffineTransform transform];
	[transform scaleXBy:(currentBoundsSize.width / cachedBoundsSizeForConnectors.width)
		yBy:(currentBoundsSize.height / cachedBoundsSizeForConnectors.height)];*/
	
	//NSBezierPath *transformedConnector1 = [connectorTransform transformBezierPath:connector1];
	//NSBezierPath *transformedConnector2 = [connectorTransform transformBezierPath:connector2];

	[[NSColor darkGrayColor] setStroke];
	[connector1 stroke];
	[connector2 stroke];
	
	[shadow release];

	[NSGraphicsContext restoreGraphicsState];
	
	

	/*
return;

	int connectorTag1 = 56;
	NSCell *bariumCell = [self cellWithTag:connectorTag1];
	NSCell *lanthanumCell = [self cellWithTag:connectorTag1 + 1];
	
	int connectorTag2 = 88;
	NSCell *radiumCell = [self cellWithTag:connectorTag2];
	NSCell *actiniumCell = [self cellWithTag:connectorTag2 + 1];
	
	NSArray *connection1 = [NSArray arrayWithObjects:radiumCell, lanthanumCell, nil];
	NSArray *connections = [NSArray arrayWithObject:connection1];
	
	NSEnumerator *e = [connections objectEnumerator];
	id connection;
	int row1, row2, col1, col2;
	while (connection = [e nextObject]) {
		[self getRow:&row1 column:&col1 ofCell:[connection objectAtIndex:0]];
		[self getRow:&row2 column:&col2 ofCell:[connection objectAtIndex:1]];
		
		NSLog(@"row/col = %i, %i", row1, col1);
		//- (NSRect)cellFrameAtRow:(int)row column:(int)column
		NSRect sourceRect = [self cellFrameAtRow:row1 column:col1];
		NSRect destinationRect = [self cellFrameAtRow:row2 column:col2];
		
		NSPoint startPoint = NSMakePoint(NSMaxX(sourceRect), (int)(sourceRect.size.height / 2.0));
		NSPoint endPoint = NSMakePoint(NSMinX(destinationRect), (int)(destinationRect.size.height / 2.0));
		
		[[NSColor blackColor] set];
		NSBezierPath *path = [NSBezierPath bezierPath];
		[path moveToPoint:startPoint];
		[path lineToPoint:endPoint];
		[path setLineWidth:3.0];
		
		[path stroke];
		//[path release];
	}*/
}

/*- (void)drawFootnoteSeriesLabels:(NSRect)rect {
	NSString *lanthanidesLabel = @"Lanthanides";
	NSString *actinidesLabel = @"Actinides";

	int connectorTag1 = 57;
	int connectorTag2 = 89;
	
	NSCell *lanthanumCell = [self cellWithTag:connectorTag1];
	NSCell *actiniumCell = [self cellWithTag:connectorTag2];
	
	int lanthanumRow, lanthanumCol;
	int actiniumRow, actiniumCol;
	
	if ([self getRow:&lanthanumRow column:&lanthanumCol ofCell:lanthanumCell]) {
	
	}
	
	if ([self getRow:&actiniumRow column:&actiniumCol ofCell:actiniumCell]) {
	
	}


	
	NSRect lanthanumCellFrame = [self cellFrameAtRow:lanthanumRow  column:lanthanumCol];
	NSRect actiniumCellFrame = [self cellFrameAtRow:actiniumRow column:actiniumCol];
	
	NSPoint lanthanidesPoint, actinidesPoint;

	NSDictionary *attributes;

	{
		NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
		[paragraphStyle setAlignment:NSCenterTextAlignment];

		attributes = [[NSDictionary alloc] initWithObjectsAndKeys:
			[NSColor blackColor], NSForegroundColorAttributeName,
			[NSFont labelFontOfSize:ELM_FOOTNOTE_LABEL_SIZE], NSFontAttributeName,
			paragraphStyle, NSParagraphStyleAttributeName,
			//[NSColor greenColor], NSBackgroundColorAttributeName,
			nil
		];
		
		[paragraphStyle release];
	}
	
	lanthanidesPoint = NSMakePoint(lanthanumCellFrame.size.width, NSMidY(lanthanumCellFrame) - 0.5 * ELM_FOOTNOTE_LABEL_SIZE);
	actinidesPoint = NSMakePoint(actiniumCellFrame.size.width, NSMidY(actiniumCellFrame) - 0.5 * ELM_FOOTNOTE_LABEL_SIZE);

	[lanthanidesLabel drawAtPoint:lanthanidesPoint withAttributes:attributes];
	[actinidesLabel drawAtPoint:actinidesPoint withAttributes:attributes];

	[attributes release];
}*/

- (void)searchElements:(BOOL)blank {
	NSArray *cells = [self cells];
	if (!blank) {
		for (CBPeriodicTableButtonCell *cell in cells) {
			CBPeriodicTableElement *element = [cell representedObject];
			if (element.isSearchResult) {
				[cell setEnabled:YES];
				[cell setShouldDrawFocus:YES];
			} else {
				[cell setEnabled:NO];
				[cell setShouldDrawFocus:NO];
			}
		}
	} else {
		for (CBPeriodicTableButtonCell *cell in cells) {
			//if (!cell.isPeriodCell && !cell.isGroupCell) {
				[cell setEnabled:YES];
			//} else {
			//	[cell setEnabled:NO];
			//}
			[cell setShouldDrawFocus:NO];
		}
	}
	[self setNeedsDisplay:YES];

	
	/*NSPredicate *pred = [elementsArrayController filterPredicate];
	NSArray *arrangedFilteredElements = [elementsArrayController arrangedObjects];
	if (pred != nil) {
		for (id cell in elementCells) {
			if ([arrangedFilteredElements containsObject:[cell representedObject]]) {
				[cell setEnabled:YES];
				[cell setShouldDrawFocus:YES];
			} else {
				[cell setEnabled:NO];
				[cell setShouldDrawFocus:NO];
			}
			[self setNeedsDisplay:YES];
		}
	} else {
		for (id cell in elementCells) {
			[cell setEnabled:YES];
			[cell setShouldDrawFocus:NO];
		}
		
		[self setNeedsDisplay:YES];
	}*/
}

+ (Class)cellClass {
	return [CBPeriodicTableButtonCell class];	
}

- (void)prepareCells:(NSArray *)elements {
	NSDictionary *numberAttributes = [CBPeriodicTableButtonCell numberAttributes];
	NSDictionary *symbolAttributes = [CBPeriodicTableButtonCell symbolAttributes];

	NSInteger numCols = 19;
	NSInteger numRows = 11;
	
	NSSize frameSize = [self frame].size;
	[self setIntercellSpacing:NSMakeSize(ELM_INTERCELL_WIDTH, ELM_INTERCELL_HEIGHT)];
	
	CGFloat rowHeight = frameSize.height / (CGFloat)numRows;
	CGFloat rowWidth = frameSize.width / (CGFloat)numCols;
	
	[self setCellSize:NSMakeSize(rowWidth, rowHeight)];
	
	[self renewRows:numRows columns:numCols];

/*	{
		NSMutableArray *elementCellsTemp = [NSMutableArray array];

		NSBundle *bundle = [NSBundle mainBundle];
		NSString *path = [bundle pathForResource:@"PeriodicTable" ofType:@"plist"];
		NSArray *cellDataArray = [NSArray arrayWithContentsOfFile:path];
		id currentCell;
		
		for (NSArray *rowArray in cellDataArray) {
			for (NSDictionary *cellDict in rowArray) {
				NSInteger atomicNumber = [[cellDict objectForKey:@"atomicNumber"] integerValue];
				NSInteger periodNumber = [[cellDict objectForKey:@"periodNumber"] integerValue];
				NSInteger groupNumber = [[cellDict objectForKey:@"groupNumber"] integerValue];
				
				NSInteger tag = atomicNumber;
				currentCell = [[self cells] objectAtIndex:tag];
				if (tag > 0) {
					[currentCell setTag:tag];
					CBPeriodicTableElement *theElement = [elements objectAtIndex:tag - 1];
					[currentCell setRepresentedObject:theElement];
					
					NSString *numberString = [[NSString alloc] initWithFormat:@"%@\n",theElement.elementNumber];
					NSString *symbolString = [[NSString alloc] initWithFormat:@"%@", theElement.elementSymbol];
					NSAttributedString *numberAttributedString = [[NSAttributedString alloc] initWithString:numberString attributes:numberAttributes];
					NSAttributedString *symbolAttributedString = [[NSAttributedString alloc] initWithString:symbolString attributes:symbolAttributes];
					[numberString release];
					[symbolString release];
					
					NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] init];
					
					[attributedTitle appendAttributedString:numberAttributedString];
					[attributedTitle appendAttributedString:symbolAttributedString];
					
					[numberAttributedString release];
					[symbolAttributedString release];
					
					[currentCell setAttributedTitle:attributedTitle];
					
					[attributedTitle release];
					
					[elementCellsTemp addObject:currentCell];
					
					[currentCell setBordered:YES];
				} else {
					[currentCell setEnabled:NO];
					[currentCell setTransparent:YES];
					[currentCell setBordered:YES];
				}
			}*/
			
			
			/*NSArray *cells = [self cells];
			for (id cell in cells) {
				NSInteger tag = atomicNumber;
				if (tag > 0) {
					[currentCell setTag:tag];
					CBPeriodicTableElement *theElement = [elements objectAtIndex:tag - 1];
					[currentCell setRepresentedObject:theElement];
					
					NSString *numberString = [[NSString alloc] initWithFormat:@"%@\n",theElement.elementNumber];
					NSString *symbolString = [[NSString alloc] initWithFormat:@"%@", theElement.elementSymbol];
					NSAttributedString *numberAttributedString = [[NSAttributedString alloc] initWithString:numberString attributes:numberAttributes];
					NSAttributedString *symbolAttributedString = [[NSAttributedString alloc] initWithString:symbolString attributes:symbolAttributes];
					[numberString release];
					[symbolString release];
					
					NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] init];
					
					[attributedTitle appendAttributedString:numberAttributedString];
					[attributedTitle appendAttributedString:symbolAttributedString];
					
					[numberAttributedString release];
					[symbolAttributedString release];
					
					[currentCell setAttributedTitle:attributedTitle];
					
					[attributedTitle release];
					
					[elementCellsTemp addObject:currentCell];
					
					[currentCell setBordered:YES];
				} else {
					[currentCell setEnabled:NO];
					[currentCell setTransparent:YES];
					[currentCell setBordered:YES];
				}				
			}
		}
		
		elementCells = [elementCellsTemp copy];		
		
		[self recalculateConnectorPaths];
	}
	return;*/
	
	
	{
		NSBundle *bundle = [NSBundle mainBundle];
		NSString *path = [bundle pathForResource:@"PeriodicTable" ofType:@"plist"];
		NSArray *cellDataArray = [NSArray arrayWithContentsOfFile:path];
		
		NSMutableArray *elementCellsTemp = [NSMutableArray array];

		NSEnumerator *e2 = [[self cells] objectEnumerator];
		CBPeriodicTableButtonCell *currentCell;
		
		//while ( (layoutRow = [layoutRowEnumerator nextObject]) && 
		//	   (groupLayoutRow = [groupLayoutRowEnumerator nextObject]) && 
		//	   (periodLayoutRow = [periodLayoutRowEnumerator nextObject]) )
		for (NSArray *row in cellDataArray) {
			
			//layoutColumnEnumerator = [layoutRow objectEnumerator];
			//groupLayoutColumnEnumerator = [groupLayoutRow objectEnumerator];
			//periodLayoutColumnEnumerator = [periodLayoutRow objectEnumerator];
			
			for (NSDictionary *cellDict in row) {
				currentCell = [e2 nextObject];
			//while ( (layoutColumn = [layoutColumnEnumerator nextObject]) && 
			//	   (currentCell = [e2 nextObject]) && 
			//	   (groupLayoutColumn = [groupLayoutColumnEnumerator nextObject]) && 
			//	   (periodLayoutColumn = [periodLayoutColumnEnumerator nextObject]) )
				//NSInteger tag = [layoutColumn integerValue];
				//NSInteger tag = [[cellDict objectForKey:@"atomicNumber"] integerValue];
				BOOL visible = [[cellDict objectForKey:@"visible"] boolValue];
				if (visible) {
					NSInteger atomicNumber = [[cellDict objectForKey:@"atomicNumber"] integerValue];
					
					if (atomicNumber > 0) {
						[currentCell setTag:atomicNumber];
						CBPeriodicTableElement *theElement = [elements objectAtIndex:atomicNumber - 1];
						[currentCell setRepresentedObject:theElement];
							
						
						NSString *numberString = [[NSString alloc] initWithFormat:@"%@\n",theElement.elementNumber];
						NSString *symbolString = [[NSString alloc] initWithFormat:@"%@", theElement.elementSymbol];
							NSAttributedString *numberAttributedString = [[NSAttributedString alloc] initWithString:numberString attributes:numberAttributes];
							NSAttributedString *symbolAttributedString = [[NSAttributedString alloc] initWithString:symbolString attributes:symbolAttributes];
						[numberString release];
						[symbolString release];
						
						NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] init];

							[attributedTitle appendAttributedString:numberAttributedString];
							[attributedTitle appendAttributedString:symbolAttributedString];

						[numberAttributedString release];
						[symbolAttributedString release];
						
						[currentCell setAttributedTitle:attributedTitle];
						
						[attributedTitle release];
						
						[elementCellsTemp addObject:currentCell];

						[currentCell setBordered:YES];
					} else {
						NSInteger groupNumber = [[cellDict objectForKey:@"groupNumber"] integerValue];
						NSInteger periodNumber = [[cellDict objectForKey:@"periodNumber"] integerValue];
						
						// configure the label attributes
						NSMutableParagraphStyle *labelParagraphStyle = [[[NSParagraphStyle defaultParagraphStyle] mutableCopy] autorelease];
						[labelParagraphStyle setAlignment:NSCenterTextAlignment];
						NSDictionary *labelAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
													[NSColor darkGrayColor], NSForegroundColorAttributeName,
													[NSFont labelFontOfSize:ELM_PT_LABEL_SIZE], NSFontAttributeName,
													labelParagraphStyle, NSParagraphStyleAttributeName,
													nil];

						
						if (groupNumber > 0) {
							NSString *numberString = [NSString stringWithFormat:@"%i", groupNumber];
							NSAttributedString *numberAttributedString = [[NSAttributedString alloc] initWithString:numberString attributes:labelAttributes];
							[currentCell setAttributedTitle:numberAttributedString];
							currentCell.isGroupCell = YES;
							//[currentCell setEnabled:NO];
						} else if (periodNumber > 0) {
							NSString *numberString = [NSString stringWithFormat:@"%i", periodNumber];
							NSAttributedString *numberAttributedString = [[NSAttributedString alloc] initWithString:numberString attributes:labelAttributes];
							[currentCell setAttributedTitle:numberAttributedString];
							currentCell.isPeriodCell = YES;
							//[currentCell setEnabled:NO];
						}
						
						[currentCell setEnabled:NO];
						[currentCell setTransparent:NO];
						[currentCell setBordered:NO];
						
						//[currentCell setBezelStyle:NSShadowlessSquareBezelStyle];

						
						
						//[currentCell setBordered:NO];
						//currentCell.backgroundColor = [NSColor clearColor];
						
					}
				} else {
					[currentCell setEnabled:NO];
					[currentCell setTransparent:YES];
					[currentCell setBordered:YES];
				}
			}
		}

		elementCells = [elementCellsTemp copy];
	}
	
	[self recalculateConnectorPaths];
}

- (void)prepareElementColorMapFromTableData:(NSArray *)data {
	NSMutableDictionary *colorMap = [NSMutableDictionary dictionary];
		
	for (id dict in data) {
		NSString *parentIdentifier = [dict objectForKey:@"identifier"];
		NSArray *children = [dict objectForKey:@"children"];
		
		NSMutableDictionary *colorSubMap = [NSMutableDictionary dictionary];
		
		for (NSDictionary *child in children) {
			NSString *childIdentifier = [child objectForKey:@"identifier"];
			
			NSArray *colorVals = [child objectForKey:@"color"];
			NSInteger rVal = [[colorVals objectAtIndex:0] integerValue];
			NSInteger gVal = [[colorVals objectAtIndex:1] integerValue];
			NSInteger bVal = [[colorVals objectAtIndex:2] integerValue];
			
			[colorSubMap setObject:
				[NSColor colorWithCalibratedRed:(CGFloat)rVal / (CGFloat)100.0
										  green:(CGFloat)gVal / (CGFloat)100.0
										   blue:(CGFloat)bVal / (CGFloat)100.0
										  alpha:1.0]
								forKey:childIdentifier];
			
			[colorSubMap setObject:parentIdentifier forKey:@"name"];
			
		}
		[colorMap setObject:colorSubMap forKey:parentIdentifier];
	}
	
	self.elementColorMap = colorMap;
}

- (void)changeCurrentColorSchemeWithKey:(NSString *)key {
	self.currentColorScheme = [self.elementColorMap objectForKey:key];	// lastObject kludge
}

- (void)reloadCellColors {
	NSDictionary *colorMap = self.currentColorScheme;
	for (id cell in elementCells) {
		[cell takeColorFromColorMap:colorMap];
	}
	
	[self setNeedsDisplay:YES];
}

/*- (BOOL)isFlipped {
	return YES;	
}*/

@end
