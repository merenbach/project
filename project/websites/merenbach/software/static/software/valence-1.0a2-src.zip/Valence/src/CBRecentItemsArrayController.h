//
//  CBRecentItemsArrayController.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/29/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBRecentItemsArrayController : NSArrayController {
	unsigned AM_maxNumberOfRecentItems;
}

- (void)trimObjects;

- (unsigned)maxNumberOfRecentItems;
- (void)setMaxNumberOfRecentItems:(unsigned)anInt;

- (void)updateMaxNumberOfRecentItems:(NSNotification *)aNotification;

@end
