//
//  CBEquilibriumToolEntry.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CBEquilibriumToolEntry : NSObject <NSCopying> {
	NSString *m_substanceName;
	double m_concentrationValue;
	double m_coefficientValue;
}

@property (copy, readwrite) NSString *substanceName;
@property (assign, readwrite) double concentrationValue;
@property (assign, readwrite) double coefficientValue;

+ (NSArray *)copyKeys;
- (id)init;
- (void)dealloc;
- (id)copyWithZone:(NSZone *)zone;
- (NSDictionary *)dictionaryRepresentation;

@end