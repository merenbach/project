//
//  CBPeriodicTableLegendCell.m
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 04/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableLegendCell.h"
//#import "CBPeriodicTableValueTransformers.h"

//static void *BackgroundColorObservationContext = (void *)1091;

@implementation CBPeriodicTableLegendCell

/*+ (void)initialize {
	NSValueTransformer *vt = [[CBPTLocalizedStringTransformer alloc] init];
	[NSValueTransformer setValueTransformer:vt forName:@"CBPTLocalizedStringTransformer"];
	[vt release];
}*/

- (id)initTextCell:(NSString *)aString {
    self = [super initTextCell:aString];
    if (self != nil) {
        //AM_backgroundColor = [[NSColor grayColor] retain];
		[self setBordered:NO];
		[self setBezeled:NO];
		[self setEnabled:NO];
		//[self setBezelStyle:NSShadowlessSquareBezelStyle];
		//[self setButtonType:NSMomentaryPushInButton];
		//[self setGradientType:NSGradientNone];
    }
    return self;
}

/*- (void)dealloc {
	[AM_backgroundColor release];
	AM_backgroundColor = nil;

	[super dealloc];
}*/

- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView {
	[super drawWithFrame:cellFrame inView:controlView];

	NSRect insetFrame = NSInsetRect(cellFrame, 2.0, 2.0);
	
	[[NSColor darkGrayColor] set];
	[NSBezierPath setDefaultLineWidth:1.0];
	//[NSBezierPath setDefaultLineJoinStyle:NSMiterLineJoinStyle];
	[NSBezierPath strokeRect:insetFrame];

}

- (void)drawInteriorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView {
	[super drawInteriorWithFrame:cellFrame inView:controlView];
	
	NSRect interiorFrame = NSInsetRect(cellFrame, 2.0, 2.0);
	
	NSColor *color = [self objectValue];
	//NSColor *color = [[self colorSource] colorForKey:[self stringValue]];
	if (color) {
		//NSLog(@"%@",[self objectValue]);
		[[NSColor whiteColor] set];
		[NSBezierPath fillRect:interiorFrame];
	
		[[color colorWithAlphaComponent:0.25] set];
		[NSBezierPath fillRect:interiorFrame];
		
		//NSColor *swatchColor = [_cellColor colorWithAlphaComponent:0.25];
		//[[color colorWithAlphaComponent:0.25] drawSwatchInRect:cellFrame];
	}
}

/*- (NSColor *)backgroundColor {
	return [[AM_backgroundColor retain] autorelease];
}

- (void)setBackgroundColor:(NSColor *)aColor {
	if (aColor != AM_backgroundColor) {
		[AM_backgroundColor release];
		AM_backgroundColor = [aColor retain];
	}
}*/

@end
