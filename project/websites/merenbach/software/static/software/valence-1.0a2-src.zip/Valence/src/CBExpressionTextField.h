//
//  CBExpressionTextField.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/19/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBExpressionTextField : NSTextField {
}

- (void)updateFormattedValue:(NSNotification *)aNotification;

@end


@interface CBExpressionTextFieldCell : NSTextFieldCell {
}

- (void)updateFormattedValue:(NSNotification *)aNotification;

@end