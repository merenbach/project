//
//  AMOutlineView.h
//  A subclass of NSOutlineView
//
//  Created by Andrew Merenbach on 1/1/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AMOutlineView : NSOutlineView {
	BOOL m_am_consumedKeyDown;
	
	BOOL m_spaceKeyAdds;
	BOOL m_enterKeyAdds;
	BOOL m_deleteKeyRemoves;
	
	BOOL m_spaceKeySendsDoubleAction;
	BOOL m_enterKeySendsDoubleAction;
}

@property (assign, readwrite) BOOL am_consumedKeyDown;

@property (assign, readwrite) BOOL spaceKeyAdds;
@property (assign, readwrite) BOOL enterKeyAdds;
@property (assign, readwrite) BOOL deleteKeyRemoves;
@property (assign, readwrite) BOOL spaceKeySendsDoubleAction;
@property (assign, readwrite) BOOL enterKeySendsDoubleAction;

- (id)init;
- (id)initWithFrame:(NSRect)frameRect;
- (id)initWithCoder:(NSCoder *)aDecoder;

@end


@interface AMOutlineView (DLKeyDownOperations)

- (void)keyDown:(NSEvent *)event;
- (void)doCommandBySelector:(SEL)selector;

//- (void)cancelOperation:(id)sender;
//- (void)insertText:(NSString *)aString;	// for space beginning editing

@end

@interface AMOutlineView (DataMethods)

- (void)delete:(id)sender;
- (void)deleteBackward:(id)sender;
- (void)deleteForward:(id)sender;

- (void)insertNewline:(id)sender;
- (void)insertText:(id)aString;

@end
