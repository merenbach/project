#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBNormalityTool : CBToolViewController
{
	/*IBOutlet NSTextField *normalityV1Field;
	IBOutlet NSTextField *normalityV2Field;
	IBOutlet NSTextField *normalityN1Field;
	IBOutlet NSTextField *normalityN2Field;
	
	IBOutlet CBScalePopUpButton *normalityV1Menu;
	IBOutlet CBScalePopUpButton *normalityV2Menu;
	
	IBOutlet NSTextField *volumeV1Field;
	IBOutlet NSTextField *volumeV2Field;
	IBOutlet NSTextField *volumeN1Field;
	IBOutlet NSTextField *volumeN2Field;
	
	IBOutlet CBScalePopUpButton *volumeV1Menu;
	IBOutlet CBScalePopUpButton *volumeV2Menu;
	*/
	
	double m_normalityTabV1Value;
	double m_normalityTabV2Value;
	double m_normalityTabN1Value;
	double m_normalityTabN2Value;

	double m_volumeTabV1Value;
	double m_volumeTabV2Value;
	double m_volumeTabN1Value;
	double m_volumeTabN2Value;
	
	CBMeasurementScale *m_normalityTabV1Scale;
	CBMeasurementScale *m_normalityTabV2Scale;
	CBMeasurementScale *m_volumeTabV1Scale;
	CBMeasurementScale *m_volumeTabV2Scale;
}

@property (assign, readwrite) double normalityTabV1Value;
@property (assign, readwrite) double normalityTabV2Value;
@property (assign, readwrite) double normalityTabN1Value;
@property (assign, readwrite) double normalityTabN2Value;
@property (assign, readwrite) double volumeTabV1Value;
@property (assign, readwrite) double volumeTabV2Value;
@property (assign, readwrite) double volumeTabN1Value;
@property (assign, readwrite) double volumeTabN2Value;
@property (retain, readwrite) CBMeasurementScale *normalityTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *normalityTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV2Scale;

- (IBAction)calculateNormality:(id)sender;
- (IBAction)calculateVolume:(id)sender;

@end
