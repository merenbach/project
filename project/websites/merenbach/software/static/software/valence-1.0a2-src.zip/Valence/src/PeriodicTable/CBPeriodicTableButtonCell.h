//
//  CBPeriodicTableButtonCell.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 03/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef enum {
	CBPTElementButtonTypeInvisible,
	CBPTElementButtonTypeNormal,
	CBPTElementButtonTypeFocused,
	CBPTElementButtonTypeDisabled,
	ELMFamilyLabelButtonType,
	//ELMFamilyHorizontalConnector,
} CBPTElementButtonType;

@interface CBPeriodicTableButtonCell : NSButtonCell {
	BOOL m_shouldDrawFocus;
	BOOL m_isGroupCell;
	BOOL m_isPeriodCell;
}

@property (assign, readwrite) BOOL shouldDrawFocus;
@property (assign, readwrite) BOOL isGroupCell;
@property (assign, readwrite) BOOL isPeriodCell;

//@property (retain, readwrite) NSColor *

+ (CGFloat)disabledCellAlphaComponent;
+ (CGFloat)defaultBackgroundAlphaValue;

//- (void)activateNormalCellProfile;
//- (void)activateFocusedCellProfile;
//- (void)activateExcludedCellProfile;

+ (NSParagraphStyle *)cellParagraphStyle;
+ (NSDictionary *)symbolAttributes;
+ (NSDictionary *)numberAttributes;
+ (NSDictionary *)familyAttributes;
+ (NSDictionary *)periodAttributes;

- (void)takeColorFromColorMap:(NSDictionary *)colorMap;

@end
