//
//  CBMolarMassCalculation.h
//  Valence
//
//  Created by Andrew Merenbach on 4/10/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBMolarMassCalculation : NSOperation {
	NSString *m_formula;
	double m_molesPerGram;
	double m_gramsPerMole;
}

@property (copy, readwrite) NSString *formula;
@property (assign, readwrite) double molesPerGram;
@property (assign, readwrite) double gramsPerMole;

- (id)init;
- (void)dealloc;
- (void)main;

@end
