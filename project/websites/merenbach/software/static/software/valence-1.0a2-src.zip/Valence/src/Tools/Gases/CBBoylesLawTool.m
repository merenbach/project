#import "CBBoylesLawTool.h"
#import "CBCalculator.h"

@implementation CBBoylesLawTool

@synthesize pressureTabP1Value = m_pressureTabP1Value;
@synthesize pressureTabP2Value = m_pressureTabP2Value;
@synthesize pressureTabV1Value = m_pressureTabV1Value;
@synthesize pressureTabV2Value = m_pressureTabV2Value;

@synthesize volumeTabP1Value = m_volumeTabP1Value;
@synthesize volumeTabP2Value = m_volumeTabP2Value;
@synthesize volumeTabV1Value = m_volumeTabV1Value;
@synthesize volumeTabV2Value = m_volumeTabV2Value;

@synthesize pressureTabP1Scale = m_pressureTabP1Scale;
@synthesize pressureTabP2Scale = m_pressureTabP2Scale;
@synthesize pressureTabV1Scale = m_pressureTabV1Scale;
@synthesize pressureTabV2Scale = m_pressureTabV2Scale;

@synthesize volumeTabP1Scale = m_volumeTabP1Scale;
@synthesize volumeTabP2Scale = m_volumeTabP2Scale;
@synthesize volumeTabV1Scale = m_volumeTabV1Scale;
@synthesize volumeTabV2Scale = m_volumeTabV2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_pressureTabP1Value = 0;
		m_pressureTabP2Value = 0;
		m_pressureTabV1Value = 0;
		m_pressureTabV2Value = 0;
		
		m_volumeTabP1Value = 0;
		m_volumeTabP2Value = 0;
		m_volumeTabV1Value = 0;
		m_volumeTabV2Value = 0;
		
		m_pressureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_pressureTabV2Scale = [CBMeasurementScale initialVolumeScale];
		
		m_volumeTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_volumeTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_volumeTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV2Scale = [CBMeasurementScale initialVolumeScale];
	}
	return self;
}

- (void)dealloc {
	[m_pressureTabP1Scale release];
	[m_pressureTabP2Scale release];
	[m_pressureTabV1Scale release];
	[m_pressureTabV2Scale release];
	
	m_pressureTabP1Scale = nil;
	m_pressureTabP2Scale = nil;
	m_pressureTabV1Scale = nil;
	m_pressureTabV2Scale = nil;
	
	[m_volumeTabP1Scale release];
	[m_volumeTabP2Scale release];
	[m_volumeTabV1Scale release];
	[m_volumeTabV2Scale release];

	m_volumeTabP1Scale = nil;
	m_volumeTabP2Scale = nil;
	m_volumeTabV1Scale = nil;
	m_volumeTabV2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculatePressure:(id)sender
{
	double p1 = self.pressureTabP1Value;
	double p2;
	double v1 = self.pressureTabV1Value;
	double v2 = self.pressureTabV2Value;
	
	p1 = [CBCalculator convert:p1 fromScale:self.pressureTabP1Scale];
	v1 = [CBCalculator convert:v1 fromScale:self.pressureTabV1Scale];
	v2 = [CBCalculator convert:v2 fromScale:self.pressureTabV2Scale];

	/* finish up with the calculation itself */
	p2 = p1 * v1 / v2;
	p2 = [CBCalculator convert:p2 toScale:self.pressureTabP2Scale];
	
	self.pressureTabP2Value = p2;
}

- (IBAction)calculateVolume:(id)sender
{
	double p1 = self.volumeTabP1Value;
	double p2 = self.volumeTabP2Value;
	double v1 = self.volumeTabV1Value;
	double v2;

	p1 = [CBCalculator convert:p1 fromScale:self.volumeTabP1Scale];
	v1 = [CBCalculator convert:v1 fromScale:self.volumeTabV1Scale];
	p2 = [CBCalculator convert:p2 fromScale:self.volumeTabP2Scale];
		
	/* finish up with the calculation itself */
	v2 = v1 * p1 / p2;
	v2 = [CBCalculator convert:v2 toScale:self.volumeTabV2Scale];
	
	self.volumeTabV2Value = v2;
}

@end
