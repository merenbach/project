//
//  CBPeriodicTableInspectorWindow.h
//  Valence
//
//  Created by Andrew Merenbach on 4/10/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBPeriodicTableInspectorWindow : NSPanel {

}

- (BOOL)canBecomeKeyWindow;

@end


@interface CBPeriodicTableInspectorTextDisplay : NSTextView {
	BOOL m_mouseDraggedFlag;
}

@property (assign, readwrite) BOOL mouseDraggedFlag;

- (void)mouseDown:(id)sender;
- (void)mouseUp:(id)sender;
- (void)mouseDragged:(id)sender;

@end