#import "CBCombinedGasLawTool.h"
#import "CBCalculator.h"


@implementation CBCombinedGasLawTool

@synthesize pressureTabP1Value = m_pressureTabP1Value;
@synthesize pressureTabP2Value = m_pressureTabP2Value;
@synthesize pressureTabV1Value = m_pressureTabV1Value;
@synthesize pressureTabV2Value = m_pressureTabV2Value;
@synthesize pressureTabT1Value = m_pressureTabT1Value;
@synthesize pressureTabT2Value = m_pressureTabT2Value;

@synthesize volumeTabP1Value = m_volumeTabP1Value;
@synthesize volumeTabP2Value = m_volumeTabP2Value;
@synthesize volumeTabV1Value = m_volumeTabV1Value;
@synthesize volumeTabV2Value = m_volumeTabV2Value;
@synthesize volumeTabT1Value = m_volumeTabT1Value;
@synthesize volumeTabT2Value = m_volumeTabT2Value;

@synthesize temperatureTabP1Value = m_temperatureTabP1Value;
@synthesize temperatureTabP2Value = m_temperatureTabP2Value;
@synthesize temperatureTabV1Value = m_temperatureTabV1Value;
@synthesize temperatureTabV2Value = m_temperatureTabV2Value;
@synthesize temperatureTabT1Value = m_temperatureTabT1Value;
@synthesize temperatureTabT2Value = m_temperatureTabT2Value;

@synthesize pressureTabP1Scale = m_pressureTabP1Scale;
@synthesize pressureTabP2Scale = m_pressureTabP2Scale;
@synthesize pressureTabV1Scale = m_pressureTabV1Scale;
@synthesize pressureTabV2Scale = m_pressureTabV2Scale;
@synthesize pressureTabT1Scale = m_pressureTabT1Scale;
@synthesize pressureTabT2Scale = m_pressureTabT2Scale;

@synthesize volumeTabP1Scale = m_volumeTabP1Scale;
@synthesize volumeTabP2Scale = m_volumeTabP2Scale;
@synthesize volumeTabV1Scale = m_volumeTabV1Scale;
@synthesize volumeTabV2Scale = m_volumeTabV2Scale;
@synthesize volumeTabT1Scale = m_volumeTabT1Scale;
@synthesize volumeTabT2Scale = m_volumeTabT2Scale;

@synthesize temperatureTabP1Scale = m_temperatureTabP1Scale;
@synthesize temperatureTabP2Scale = m_temperatureTabP2Scale;
@synthesize temperatureTabV1Scale = m_temperatureTabV1Scale;
@synthesize temperatureTabV2Scale = m_temperatureTabV2Scale;
@synthesize temperatureTabT1Scale = m_temperatureTabT1Scale;
@synthesize temperatureTabT2Scale = m_temperatureTabT2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_pressureTabP1Value = 0;
		m_pressureTabP2Value = 0;
		m_pressureTabV1Value = 0;
		m_pressureTabV2Value = 0;
		m_pressureTabT1Value = 0;
		m_pressureTabT2Value = 0;
		
		m_volumeTabP1Value = 0;
		m_volumeTabP2Value = 0;
		m_volumeTabV1Value = 0;
		m_volumeTabV2Value = 0;
		m_volumeTabT1Value = 0;
		m_volumeTabT2Value = 0;

		m_temperatureTabP1Value = 0;
		m_temperatureTabP2Value = 0;
		m_temperatureTabV1Value = 0;
		m_temperatureTabV2Value = 0;
		m_temperatureTabT1Value = 0;
		m_temperatureTabT2Value = 0;
				
		m_pressureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_pressureTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_pressureTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_pressureTabT2Scale = [CBMeasurementScale initialTemperatureScale];
		
		m_volumeTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_volumeTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_volumeTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_volumeTabT2Scale = [CBMeasurementScale initialTemperatureScale];

		m_temperatureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_temperatureTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_temperatureTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_temperatureTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_temperatureTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_temperatureTabT2Scale = [CBMeasurementScale initialTemperatureScale];		
	}
	return self;
}

- (void)dealloc {
	[m_pressureTabP1Scale release];
	[m_pressureTabP2Scale release];
	[m_pressureTabV1Scale release];
	[m_pressureTabV2Scale release];
	[m_pressureTabT1Scale release];
	[m_pressureTabT2Scale release];

	m_pressureTabP1Scale = nil;
	m_pressureTabP2Scale = nil;
	m_pressureTabV1Scale = nil;
	m_pressureTabV2Scale = nil;
	m_pressureTabT1Scale = nil;
	m_pressureTabT2Scale = nil;
	
	[m_volumeTabP1Scale release];
	[m_volumeTabP2Scale release];
	[m_volumeTabV1Scale release];
	[m_volumeTabV2Scale release];
	[m_volumeTabT1Scale release];
	[m_volumeTabT2Scale release];
	
	m_volumeTabP1Scale = nil;
	m_volumeTabP2Scale = nil;
	m_volumeTabV1Scale = nil;
	m_volumeTabV2Scale = nil;
	m_volumeTabT1Scale = nil;
	m_volumeTabT2Scale = nil;
	
	[m_temperatureTabP1Scale release];
	[m_temperatureTabP2Scale release];
	[m_temperatureTabV1Scale release];
	[m_temperatureTabV2Scale release];
	[m_temperatureTabT1Scale release];
	[m_temperatureTabT2Scale release];
	
	m_temperatureTabP1Scale = nil;
	m_temperatureTabP2Scale = nil;
	m_temperatureTabV1Scale = nil;
	m_temperatureTabV2Scale = nil;
	m_temperatureTabT1Scale = nil;
	m_temperatureTabT2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculatePressure:(id)sender
{
	//double p1 = [pressureP1Field doubleValue];
	//double p2;
	//double v1 = [pressureV1Field doubleValue];
	//double v2 = [pressureV2Field doubleValue];
	//double t1 = [pressureT1Field doubleValue];
	//double t2 = [pressureT2Field doubleValue];
	
	double p1 = self.pressureTabP1Value;
	double p2;
	double v1 = self.pressureTabV1Value;
	double v2 = self.pressureTabV2Value;
	double t1 = self.pressureTabT1Value;
	double t2 = self.pressureTabT2Value;

	p1 = [CBCalculator convert:p1 fromScale:self.pressureTabP1Scale];
	v1 = [CBCalculator convert:v1 fromScale:self.pressureTabV1Scale];
	t1 = [CBCalculator convert:t1 fromScale:self.pressureTabT1Scale];
	
	v2 = [CBCalculator convert:v2 fromScale:self.pressureTabV2Scale];
	t2 = [CBCalculator convert:t2 fromScale:self.pressureTabT2Scale];

	/* finish up with the calculation itself */
	p2 = (p1 * v1 * t2) / (v2 * t1);
	p2 = [CBCalculator convert:p2 toScale:self.pressureTabP2Scale];
	
	//p2 = [CBCalculator convert:p2 toScaleMenu:pressureP2Menu];
	
	self.pressureTabP2Value = p2;
	//[pressureP2Field setDoubleValue:p2];
}

- (IBAction)calculateVolume:(id)sender
{
	//double p1 = [volumeP1Field doubleValue];
	//double p2 = [volumeP2Field doubleValue];
	//double v1 = [volumeV1Field doubleValue];
	//double v2;
	//double t1 = [volumeT1Field doubleValue];
	//double t2 = [volumeT2Field doubleValue];

	double p1 = self.volumeTabP1Value;
	double p2 = self.volumeTabP2Value;
	double v1 = self.volumeTabV1Value;
	double v2;
	double t1 = self.volumeTabT1Value;
	double t2 = self.volumeTabT2Value;	
	
	p1 = [CBCalculator convert:p1 fromScale:self.volumeTabP1Scale];
	v1 = [CBCalculator convert:v1 fromScale:self.volumeTabV1Scale];
	t1 = [CBCalculator convert:t1 fromScale:self.volumeTabT1Scale];
	
	p2 = [CBCalculator convert:p2 fromScale:self.volumeTabP2Scale];
	t2 = [CBCalculator convert:t2 fromScale:self.volumeTabT2Scale];

	/* finish up with the calculation itself */
	v2 = (p1 * v1 * t2) / (t1 * p2);
	v2 = [CBCalculator convert:v2 toScale:self.volumeTabV2Scale];
	
	self.volumeTabV2Value = v2;
	//[volumeV2Field setDoubleValue:v2];
}

- (IBAction)calculateTemperature:(id)sender
{
	//double p1 = [temperatureP1Field doubleValue];
	//double p2 = [temperatureP2Field doubleValue];
	//double v1 = [temperatureV1Field doubleValue];
	//double v2 = [temperatureV2Field doubleValue];
	//double t1 = [temperatureT1Field doubleValue];
	//double t2;
	
	double p1 = self.temperatureTabP1Value;
	double p2 = self.temperatureTabP2Value;
	double v1 = self.temperatureTabV1Value;
	double v2 = self.temperatureTabV2Value;
	double t1 = self.temperatureTabT1Value;
	double t2;
		
	p1 = [CBCalculator convert:p1 fromScale:self.temperatureTabP1Scale];
	v1 = [CBCalculator convert:v1 fromScale:self.temperatureTabV1Scale];
	t1 = [CBCalculator convert:t1 fromScale:self.temperatureTabT1Scale];
	
	p2 = [CBCalculator convert:p2 fromScale:self.temperatureTabP2Scale];
	v2 = [CBCalculator convert:v2 fromScale:self.temperatureTabV2Scale];
		
	/* finish up with the calculation itself */
	t2 = (p2 * v2 * t1) / (p1 * v1);
	t2 = [CBCalculator convert:t2 toScale:self.temperatureTabT2Scale];
 
	self.temperatureTabT2Value = t2;
	//[temperatureT2Field setDoubleValue:t2];
}

- (void)setNilValueForKey:(NSString *)key {
	[self setValue:[NSNumber numberWithDouble:0] forKey:key];
}

@end
