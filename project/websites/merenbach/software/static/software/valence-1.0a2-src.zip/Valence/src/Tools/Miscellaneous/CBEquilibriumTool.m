#import "CBEquilibriumTool.h"
#import "CBEquilibriumToolEntry.h"
#import "CBCalculator.h"
#import "AMTableView.h"
#import "AMDragAndDropArrayController.h"


NSString *CBEquilibriumToolSubstanceNameKey = @"substanceName";
NSString *CBEquilibriumToolConcentrationValueKey = @"concentrationValue";
NSString *CBEquilibriumToolCoefficientValueKey = @"coefficientValue";

#define CB_FAVORED_SUBSTANCE_DEFAULT @"Reaction is at equilibrium."
#define CB_FAVORED_SUBSTANCE_REACTANTS @"Reactants are favored."
#define CB_FAVORED_SUBSTANCE_PRODUCTS @"Products are favored."

@implementation CBEquilibriumTool

@synthesize reactantsTableView = m_reactantsTableView;
@synthesize productsTableView = m_productsTableView;
@synthesize reactantsArrayController = m_reactantsArrayController;
@synthesize productsArrayController = m_productsArrayController;
@synthesize reactantsArray = m_reactantsArray;
@synthesize productsArray = m_productsArray;
@synthesize equilibriumValue = m_equilibriumValue;
@synthesize favoredSubstance = m_favoredSubstance;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_reactantsArray = [[NSArray alloc] init];
		m_productsArray = [[NSArray alloc] init];
		m_equilibriumValue = 0;
		m_favoredSubstance = [[NSString alloc] initWithString:NSLocalizedString(CB_FAVORED_SUBSTANCE_DEFAULT, CB_FAVORED_SUBSTANCE_DEFAULT)];
	}
	return self;
}

- (void)dealloc {
	[m_reactantsArray release];
	[m_productsArray release];
	
	m_reactantsArray = nil;
	m_productsArray = nil;
	
	[super dealloc];
}

- (void)awakeFromNib {
	NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:CBEquilibriumToolSubstanceNameKey ascending:YES];
	NSArray *sortDescriptorArray = [NSArray arrayWithObject:sortDescriptor];
	[sortDescriptor release];
	
	[self.reactantsTableView setSortDescriptors:sortDescriptorArray];
	[self.productsTableView setSortDescriptors:sortDescriptorArray];
	
	self.reactantsTableView.spaceKeyAdds = YES;
	self.reactantsTableView.enterKeyAdds = YES;
	self.reactantsTableView.deleteKeyRemoves = YES;
	
	self.productsTableView.spaceKeyAdds = YES;
	self.productsTableView.enterKeyAdds = YES;
	self.productsTableView.deleteKeyRemoves = YES;
	
	self.reactantsArrayController.isDraggingEnabled = YES;
	self.reactantsArrayController.isDraggingEnabledWithCopy = YES;
	self.productsArrayController.isDraggingEnabled = YES;
	self.productsArrayController.isDraggingEnabledWithCopy = YES;
}

- (IBAction)calculate:(id)sender
{
	NSArray *reactantArrObjs = [self.reactantsArrayController arrangedObjects];
	NSArray *productArrObjs = [self.productsArrayController arrangedObjects];
	
	double numerator = 1.0;
	double denominator = 1.0;
	
	double concentration;
	unsigned coefficient;
	
	NSEnumerator *e;
	id node;
	
	e = [reactantArrObjs objectEnumerator];
	while (node = [e nextObject]) {
		concentration = [[node valueForKey:CBEquilibriumToolConcentrationValueKey] doubleValue];
		coefficient = [[node valueForKey:CBEquilibriumToolCoefficientValueKey] unsignedIntValue];
		
		denominator *= pow(concentration, coefficient);
	}
	
	e = [productArrObjs objectEnumerator];
	while (node = [e nextObject]) {
		concentration = [[node valueForKey:CBEquilibriumToolConcentrationValueKey] doubleValue];
		coefficient = [[node valueForKey:CBEquilibriumToolCoefficientValueKey] unsignedIntValue];

		numerator *= pow(concentration, coefficient);
	}
	
	double kEq = numerator / denominator;
	
	self.equilibriumValue = kEq;
	
	
	NSString *favoredSubstanceTemp = nil;
	if (kEq == 1) {
		favoredSubstanceTemp = NSLocalizedString(CB_FAVORED_SUBSTANCE_DEFAULT, CB_FAVORED_SUBSTANCE_DEFAULT);
	} else if (kEq < 1) {
		favoredSubstanceTemp = NSLocalizedString(CB_FAVORED_SUBSTANCE_REACTANTS, CB_FAVORED_SUBSTANCE_REACTANTS);
	} else if (kEq > 1) {
		favoredSubstanceTemp = NSLocalizedString(CB_FAVORED_SUBSTANCE_PRODUCTS, CB_FAVORED_SUBSTANCE_PRODUCTS);
	} else {
		// sanity-check
		favoredSubstanceTemp = NSLocalizedString(CB_FAVORED_SUBSTANCE_DEFAULT, CB_FAVORED_SUBSTANCE_DEFAULT);
	}
	self.favoredSubstance = favoredSubstanceTemp;
}

@end