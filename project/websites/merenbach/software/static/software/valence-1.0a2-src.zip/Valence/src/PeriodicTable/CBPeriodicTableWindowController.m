//
//  CBPeriodicTableWindowController.m
//  Elemental
//
//  Created by Andrew Merenbach on 15/10/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableWindowController.h"
#import "CBPeriodicTableElement.h"

#import "CBPeriodicTableInspectorWindowController.h"
#import "CBPeriodicTableValueTransformers.h"

#import "CBPeriodicTableLegendCell.h"
#import "CBPeriodicTableButtonCell.h"

#import "CBPeriodicTableMatrix.h"
#import "CBPeriodicTableLegendRecord.h"

//#import "CBRecentItemsArrayController.h"

#define CB_MINIMUM_WIDTH_FOR_LEGEND_TABLE 200
#define CB_MINIMUM_WIDTH_FOR_PERIODIC_TABLE 640

static NSNumber *sNumberRoundedToPlaceValue(CGFloat number, NSInteger placeValue)
{
	return [NSNumber numberWithFloat:roundf(number * placeValue) / placeValue];
}


@implementation CBPeriodicTableWindowController

@synthesize periodicTableData = m_periodicTableData;
@synthesize elementsArrayController = m_elementsArrayController;
@synthesize elementsArray = m_elementsArray;
@synthesize elementsSplitView = m_elementsSplitView;
@synthesize cachedDividerPosition = m_cachedDividerPosition;

@synthesize periodicTableMatrix = m_periodicTableMatrix;
@synthesize legendsDictionary = m_legendsDictionary;
@synthesize currentLegendTerms = m_currentLegendTerms;
@synthesize inspectorWindowController = m_inspectorWindowController;
@synthesize periodicTableColors = m_periodicTableColors;
@synthesize periodicTableKeys = m_periodicTableKeys;

- (id)init {
	self = [super initWithWindowNibName:@"PeriodicTableWindow"];
	if (self != nil) {
		NSString *tablePath = [[NSBundle mainBundle] pathForResource:@"PeriodicTables" ofType:@"plist"];
		NSArray *tablesArray = [[NSArray alloc] initWithContentsOfFile:tablePath];
		m_periodicTableData = [tablesArray copy];
		
		// configure keys
		NSMutableArray *tempKeys = [NSMutableArray array];
		for (NSDictionary *dict in tablesArray) {
			NSString *identifier = [dict objectForKey:@"identifier"];
			[tempKeys addObject:identifier];
		}
		m_periodicTableKeys = [tempKeys copy];
		// end keys
		
		// configure colors
		NSMutableDictionary *tmpCol = [NSMutableDictionary dictionary];
		for (NSDictionary *dict in tablesArray) {
			//NSString *parentIdentifier = [dict objectForKey:@"identifier"];
			NSArray *children = [dict objectForKey:@"children"];
			
			for (NSDictionary *child in children) {
				NSString *childIdentifier = [child objectForKey:@"identifier"];
				NSArray *colorValuesArray = [child objectForKey:@"color"];

				NSInteger vRed = [[colorValuesArray objectAtIndex:0] integerValue];
				NSInteger vGreen = [[colorValuesArray objectAtIndex:1] integerValue];
				NSInteger vBlue = [[colorValuesArray objectAtIndex:2] integerValue];
				
				NSColor *color = [NSColor colorWithCalibratedRed:(CGFloat)vRed/(CGFloat)100.0
														   green:(CGFloat)vGreen/(CGFloat)100.0
															blue:(CGFloat)vBlue/(CGFloat)100.0
														   alpha:1.0];
			
				[tmpCol setObject:color forKey:childIdentifier];
			}
		}

		m_periodicTableColors = [tmpCol copy];
		// end colors
		
		// configure the legend
		NSMutableDictionary *legendsDictionaryTemp = [NSMutableDictionary dictionary];
		for (NSDictionary *dict in tablesArray) {
			NSString *parentIdentifier = [dict objectForKey:@"identifier"];
			
			NSMutableArray *newArray = [NSMutableArray array];
			NSArray *children = [dict objectForKey:@"children"];
			for (NSDictionary *child in children) {
				NSString *childIdentifier = [child objectForKey:@"identifier"];

				CBPeriodicTableLegendRecord *record = [CBPeriodicTableLegendRecord record];
				record.title = childIdentifier;
				record.color = [self.periodicTableColors objectForKey:childIdentifier];
				[newArray addObject:record];
			}
			[legendsDictionaryTemp setObject:newArray forKey:parentIdentifier];
		}
		m_legendsDictionary = [legendsDictionaryTemp copy];
		// end configuring legend
		
		
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Elements" ofType:@"plist"];
		NSArray *elementsArrayFromFile = [[NSArray alloc] initWithContentsOfFile:path];
		
		NSMutableArray *elementsArrayTemp = [NSMutableArray array];
		
		for (NSDictionary *dict in elementsArrayFromFile) {
			CBPeriodicTableElement *element = [CBPeriodicTableElement element];
			element.elementName = [dict objectForKey:@"elementName"];
			element.elementSymbol = [dict objectForKey:@"elementSymbol"];
			element.elementNumber = [dict objectForKey:@"elementNumber"];
			element.groupName = [dict objectForKey:@"groupName"];
			element.groupNumber = [[dict objectForKey:@"groupNumber"] integerValue];
			element.atomicMass = [dict objectForKey:@"mass"];
			element.tableData = [dict objectForKey:@"tableData"];
			
			[elementsArrayTemp addObject:element];
		}
		
		m_elementsArray = [elementsArrayTemp copy];
		
		/*NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"title" ascending:YES];
		[legendArrayController setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
		[sortDescriptor release];*/
		
		m_cachedDividerPosition = 0;
		
		m_inspectorWindowController = [[CBPeriodicTableInspectorWindowController alloc] init];
	}
	return self;
}


- (void)finalize {
	[self.elementsArrayController removeObserver:self forKeyPath:@"filterPredicate"];
	
	[super finalize];
}

- (void)dealloc {
	[self.elementsArrayController removeObserver:self forKeyPath:@"filterPredicate"];
	
	[m_periodicTableData release];
	m_periodicTableData = nil;
	
	[m_elementsArray release];
	m_elementsArray = nil;
	
	[m_legendsDictionary release];
	m_legendsDictionary = nil;
		
	[elementInformationArrayController release];
	elementInformationArrayController = nil;
	
	[m_inspectorWindowController release];
	m_inspectorWindowController = nil;
	
	[m_periodicTableColors release];
	m_periodicTableColors = nil;
	
	[m_periodicTableKeys release];
	m_periodicTableKeys = nil;
	
	[super dealloc];
}

/*- (void)windowDidResize:(NSNotification *)notification {
// [kludge][am][2008-07-10] only because matrix cell-autosizing seems to be malfunctioning...

    NSInteger numCols = 19;
	NSInteger numRows = 11;
	
	NSSize frameSize = [periodicTableMatrix frame].size;
	//[self setIntercellSpacing:NSMakeSize(-1.0, -1.0)];
	
	CGFloat rowHeight = frameSize.height / (CGFloat)numRows;
	CGFloat rowWidth = frameSize.width / (CGFloat)numCols;
	
	[periodicTableMatrix setCellSize:NSMakeSize(rowWidth, rowHeight)];
    
    
    [periodicTableMatrix recalculateConnectorPaths];
}*/


- (void)windowDidLoad {
	[self.periodicTableMatrix prepareElementColorMapFromTableData:self.periodicTableData];
    
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matrixFrameDidChange:) name:NSViewFrameDidChangeNotification object:self.periodicTableMatrix];

	[self.periodicTableMatrix setAction:@selector(showInspectorWindow:)];
	[self.periodicTableMatrix setTarget:self];
    
	// configure table column
	NSTableColumn *tableColumn = [legendTableView tableColumnWithIdentifier:@"legendColors"];
	CBPeriodicTableLegendCell *dataCell = [[[CBPeriodicTableLegendCell alloc] initTextCell:@""] autorelease];
	[tableColumn setDataCell:dataCell];
	
	[self.periodicTableMatrix prepareCells:self.elementsArray];
    [self.periodicTableMatrix handleResize];
	
	NSString *key = [[NSBundle mainBundle] localizedStringForKey:@"ELMDefaultPeriodicTable" value:@"ELMDefaultPeriodicTable" table:@"PeriodicTable"];
	[self.periodicTableMatrix changeCurrentColorSchemeWithKey:key];
	
	[self switchTable:self];
    
	[self.elementsArrayController addObserver:self forKeyPath:@"filterPredicate" options:0 context:NULL];
}


- (void)matrixFrameDidChange:(NSNotification *)notification {
    [[notification object] handleResize];
}


- (IBAction)switchTable:(id)sender {
	[self.periodicTableMatrix changeCurrentColorSchemeWithKey:[[periodicTablesArrayController selectedObjects] lastObject]];
	
	[self.periodicTableMatrix reloadCellColors];
	
	NSString *currentPeriodicTableKey = [self currentPeriodicTableKey];
	
	NSArray *newLegend = [self.legendsDictionary objectForKey:currentPeriodicTableKey];
	self.currentLegendTerms = newLegend;
}


- (id)currentPeriodicTableKey {
	return [[periodicTablesArrayController selectedObjects] lastObject];
}

- (IBAction)showInspectorWindow:(id)sender {
	[self prepareInspectorWindowData:sender];
	//NSWindow *window = [self.inspectorWindowController window];
	//[self.window addChildWindow:window ordered:NSWindowAbove];
	//[window orderFront:sender];
	[self.inspectorWindowController showWindow:sender];

	//[self.inspectorWindowController showWindow:sender];

	
	//NSView *view = [self.inspectorViewController view];
	//[self.periodicTableMatrix addSubview:view];
	
	
	/*CBPeriodicTableButtonCell *selectedCell = [self.periodicTableMatrix selectedCell];
	
	NSInteger row = 0;
	NSInteger col = 0;
	BOOL b = [self.periodicTableMatrix getRow:&row column:&col ofCell:selectedCell];
	
	if (b) {
		NSRect cellFrame = [self.periodicTableMatrix cellFrameAtRow:row column:col];
		cellFrame = [self.periodicTableMatrix convertRect:cellFrame toView:nil];
		
		//cellFrame = [self.periodicTableMatrix convertRectFromBase:cellFrame];
		NSPoint origin = cellFrame.origin;
		
		//origin = [self.periodicTableMatrix convertPointFromBase:origin];
		
		NSWindow *window = self.inspectorWindowController.window;
		[window setFrameOrigin:origin];
		[self.inspectorWindowController showWindow:sender];
	}*/
	
	//NSWindow *window = [self.inspectorWindowController window];
	//[self.window addChildWindow:window ordered:NSWindowAbove];
}

/*- (void)showInformationWindow:(id)sender {
	[informationWindowController showWindow:sender];
}*/

- (void)prepareInspectorWindowData:(id)sender {
	id cell = [self.periodicTableMatrix selectedCell];
	int tag = [cell tag] - 1;

	if (tag >= 0 && tag < [self.elementsArray count]) {
		NSBundle *mainBundle = [NSBundle mainBundle];
		CBPeriodicTableElement *element = [self.elementsArray objectAtIndex:tag];
		NSMutableString *composedDesc = [NSMutableString string];
		
		NSString *elementName = element.elementName;
		NSString *elementNumber = element.elementNumber;
		NSString *elementSymbol = element.elementSymbol;
		
		NSString *massValue = element.atomicMass;
		CGFloat mass = [massValue floatValue];
		//NSString *block = [dict objectForKey]
		
		[composedDesc appendFormat:@"name: %@\n", elementName];
		[composedDesc appendFormat:@"symbol: %@\n", elementSymbol];
		[composedDesc appendFormat:@"number: %@\n", elementNumber];
		[composedDesc appendString:@"\n"];
		[composedDesc appendFormat:@"mass: %@\n", sNumberRoundedToPlaceValue(mass, 10000)];
		
		{
			NSDictionary *tableData = element.tableData;
			NSString *crystalStructure = [tableData objectForKey:@"ELMCrystalStructuresPeriodicTable"];
			NSString *electronBlock = [tableData objectForKey:@"ELMElectronBlocksPeriodicTable"];
			NSString *radioactivity = [tableData objectForKey:@"ELMRadioactivityPeriodicTable"];
			NSString *stateOfMatter = [tableData objectForKey:@"ELMStatesOfMatterPeriodicTable"];
			
			crystalStructure = [mainBundle localizedStringForKey:crystalStructure value:crystalStructure table:@"PeriodicTable"];
			electronBlock = [mainBundle localizedStringForKey:electronBlock value:electronBlock table:@"PeriodicTable"];
			radioactivity = [mainBundle localizedStringForKey:radioactivity value:radioactivity table:@"PeriodicTable"];
			stateOfMatter = [mainBundle localizedStringForKey:stateOfMatter value:stateOfMatter table:@"PeriodicTable"];
				
			[composedDesc appendFormat:@"crystal structure: %@\n", crystalStructure];
			[composedDesc appendFormat:@"electron block: %@\n", electronBlock];
			[composedDesc appendFormat:@"radioactivity: %@\n", radioactivity];
			[composedDesc appendFormat:@"state of matter (at STP): %@\n", stateOfMatter];
		}

		self.inspectorWindowController.elementDescription = composedDesc;
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([keyPath isEqualToString:@"filterPredicate"] && object == self.elementsArrayController) {
		[self performSelectorOnMainThread:@selector(searchFilterPredicateChanged) withObject:nil waitUntilDone:YES];
	} else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)searchFilterPredicateChanged {
	NSPredicate *search = [self.elementsArrayController filterPredicate];
	BOOL isBlank = (search == nil);
	
	// clear prior results
	for (CBPeriodicTableElement *element in self.elementsArray) {
		element.isSearchResult = NO;
	}
	
	NSArray *array = nil;
	if (search != nil) {
		array = [self.elementsArray filteredArrayUsingPredicate:search];
	} else {
		array = self.elementsArray;	
	}
	
	for (CBPeriodicTableElement *element in array) {
		element.isSearchResult = YES;
	}
	
	[self.periodicTableMatrix searchElements:isBlank];
	
//	[self.periodicTableMatrix searchElements:];
	/*NSString *string = [sender stringValue];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(elementName contains[cd] %@) or (elementSymbol contains[cd] %@) or (elementNumber contains[cd] %@)", string, string, string];
	[searchArrayController setFilterPredicate:predicate];*/
	//[recentSearchesArrayController addObject:[sender stringValue]];	
}

/*- (void)tableView:(NSTableView *)aTableView willDisplayCell:(id)aCell forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex {
	if (aTableColumn == [[legendTableView tableColumns] objectAtIndex:0]) {
		[aCell setBackgroundColor:[aCell objectValue]];
	}
}*/

/*- (IBAction)toggleLegend:(id)sender {
	if (![self.elementsSplitView isSubviewCollapsed:legendTableView]) {
		NSRect rect = [legendTableView frame];
		CGFloat width = NSWidth(rect);
		self.cachedDividerPosition = width;
		[self.elementsSplitView setPosition:0 ofDividerAtIndex:0];
	} else {
		[self.elementsSplitView setPosition:self.cachedDividerPosition ofDividerAtIndex:0];
	}
}*/

- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(NSInteger)rowIndex {
	return NO;
}

@end

@implementation CBPeriodicTableWindowController (SplitViewDelegateMethods)


/*- (BOOL)splitView:(NSSplitView *)splitView shouldCollapseSubview:(NSView *)subview forDoubleClickOnDividerAtIndex:(NSInteger)dividerIndex {
	BOOL flag = NO;
	if (splitView == self.elementsSplitView) {
		if (subview == legendTableView) {
			flag = YES;
		}
	}
	return flag;
}

- (BOOL)splitView:(NSSplitView *)splitView canCollapseSubview:(NSView *)subview {
	BOOL flag = NO;
	if (splitView == self.elementsSplitView) {
		if (subview == legendTableView) {
			flag = YES;
		}
	}
	return flag;
}

- (CGFloat)splitView:(NSSplitView *)splitView constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)dividerIndex {
	if (splitView == self.elementsSplitView) {
	}
	return 0;
}*/

- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
	CGFloat newPosition = proposedPosition;
	if (proposedPosition < CB_MINIMUM_WIDTH_FOR_LEGEND_TABLE) {
		newPosition = CB_MINIMUM_WIDTH_FOR_LEGEND_TABLE;
		//newPosition = 0;
	} else if (proposedPosition > NSWidth([sender frame]) - CB_MINIMUM_WIDTH_FOR_PERIODIC_TABLE) {
		newPosition = NSWidth([sender frame]) - CB_MINIMUM_WIDTH_FOR_PERIODIC_TABLE;
		//newPosition = NSWidth([sender frame]);
	}
	return newPosition;
}

/*  During live resize of the window, lock the left side, the collection
 side, and resize the tableside
 The frames have to be set to add up to the total size minus the divider
 thickness */
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize {
    //detect if it's a window resize
    if ([sender inLiveResize]) {
		CGFloat dt = [sender dividerThickness];
		
        //info needed
        NSRect tmpRect = [sender bounds];
        NSArray *subviews =  [sender subviews];
        NSView *collectionsSide = [subviews objectAtIndex:0];
        NSView *tableSide = [subviews objectAtIndex:1];
        CGFloat collectionWidth = [collectionsSide bounds].size.width;
		
        //tableside frame: full size minus collection width and divider
        // My divider thickness is hard coded here as 1
        tmpRect.size.width = tmpRect.size.width - collectionWidth - dt;
        tmpRect.origin.x = tmpRect.origin.x + collectionWidth + dt;
        [tableSide setFrame:tmpRect];
		
        //collection frame stays the same
        tmpRect.size.width = collectionWidth;
        tmpRect.origin.x = 0;
        [collectionsSide setFrame:tmpRect];
    }
    /*else
	 [sender adjustSubviews];*/
}

- (void)windowDidResize:(NSNotification *)notification {
	NSWindow *window = [notification object];
	if (window == self.window) {
		NSSplitView *sv = self.elementsSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat w = NSWidth(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (w < (CB_MINIMUM_WIDTH_FOR_PERIODIC_TABLE - dt)) {
			w = CB_MINIMUM_WIDTH_FOR_PERIODIC_TABLE - dt;
			
			// get the differential between the width we want and the width of the bottom rectangle
			CGFloat diff = w - NSWidth(rect);
			
			// resize the top view to the new width and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.width -= diff;
			topRect.origin.x += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}
	}
}

/*- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize
 {
 NSRect newFrame = [sender frame];
 CGFloat dt = [sender dividerThickness];
 
 //NSView *leftView = self.splitViewBottomView;
 //NSView *rightView = self.splitViewTopView;
 NSView *leftView = self.splitViewTopView;
 NSView *rightView = self.splitViewBottomView;
 
 // this is the fixed view (right)
 // on top on being fixed it is also collapsible
 NSRect rightFrame = [self.splitViewBottomView frame];
 // this is the flexible view (left)
 NSRect leftFrame = [self.splitViewTopView frame];
 
 rightFrame.size.height = newFrame.size.height;
 leftFrame.size.height = newFrame.size.height;
 
 if (![self.recordsSplitView isSubviewCollapsed:rightView]) {
 NSLog(@"not collapsed");
 rightFrame.origin.x = newFrame.size.width - rightFrame.size.width;
 rightFrame.origin.y = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - rightFrame.size.width - dt;
 } else {
 NSLog(@"collapsed");
 rightFrame.origin.x = newFrame.size.width;
 rightFrame.origin.y = 0;
 rightFrame.size.width = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - dt;
 }
 [leftView setFrame: leftFrame];
 [rightView setFrame:rightFrame];
 }*/

@end
