/**
 *	filename: CBExpressionEvaluator.m
 *	created : Wed May  3 15:13:25 2000
 *	LastEditDate Was "Mon Apr  2 17:36:08 2001"
 *
 */

/*
	Copyright (c) 1997-2001 Apple Computer, Inc.
	All rights reserved.

		IMPORTANT: This Apple software is supplied to you by Apple Computer,
		Inc. ("Apple") in consideration of your agreement to the following terms,
		and your use, installation, modification or redistribution of this Apple
		software constitutes acceptance of these terms.  If you do not agree with
		these terms, please do not use, install, modify or redistribute this Apple
		software.

		In consideration of your agreement to abide by the following terms, and
		subject to these terms, Apple grants you a personal, non-exclusive
		license, under Apple's copyrights in this original Apple software (the
		"Apple Software"), to use, reproduce, modify and redistribute the Apple
		Software, with or without modifications, in source and/or binary forms;
		provided that if you redistribute the Apple Software in its entirety and
		without modifications, you must retain this notice and the following text
		and disclaimers in all such redistributions of the Apple Software.
		Neither the name, trademarks, service marks or logos of Apple Computer,
		Inc. may be used to endorse or promote products derived from the Apple
		Software without specific prior written permission from Apple. Except as
		expressly stated in this notice, no other rights or licenses, express or
		implied, are granted by Apple herein, including but not limited to any
		patent rights that may be infringed by your derivative works or by other
		works in which the Apple Software may be incorporated.

		The Apple Software is provided by Apple on an "AS IS" basis.  APPLE MAKES
		NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
		IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A
		PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND OPERATION
		ALONE OR IN COMBINATION WITH YOUR PRODUCTS.

		IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
		CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
		SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
		INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION,
		MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED AND
		WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT
		LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE POSSIBILITY
		OF SUCH DAMAGE.
*/

#import "CBExpressionEvaluator.h"

//static NSCharacterSet *self.numbersCharSet    = nil; /* 0 to 9 */
//static NSCharacterSet *self.mathOperations    = nil; /* + - * / ( ) */
//static NSCharacterSet *self.whiteSpaceCharSet = nil; /* space tab return */

@interface CBExpressionEvaluator (Private)
- (BOOL)am_isValidNumber:(NSString *)value;
- (NSString *)am_nextToken;
- (void)am_tokenizeExpression;
- (BOOL)am_nextArgIsEqual:(NSString *)string;
- (BOOL)am_noMoreArgs;
- (NSDecimalNumber *)am_evaluate;
- (NSDecimalNumber *)am_evaluate1;
- (NSDecimalNumber *)am_evaluate2;
- (NSDecimalNumber *)am_evaluate3;
@end

@implementation CBExpressionEvaluator

@synthesize expression = m_expression;
@synthesize tokenPosition = m_tokenPosition;
@synthesize length = m_length;
@synthesize arg = m_arg;
@synthesize numbersCharSet = m_numbersCharSet;
@synthesize mathOperations = m_mathOperations;
@synthesize whiteSpaceCharSet = m_whiteSpaceCharSet;

+ (NSDecimalNumber *)evaluateExpression:(NSString *)expression
{
	CBExpressionEvaluator *eval;

	eval = [[[self class] alloc] initWithExpression:expression];
		/* Make sure to call autorelease on the object
		 * before calling evaluate, if there is a parse error
		 * evaluate raises and exception
		 */
	[eval autorelease];
	return [eval evaluate];
}

- (id)initWithExpression:(NSString *)expression
{
	self = [super init];
	if (self != nil) {
		m_expression    = [expression copy];
		m_tokenPosition = 0;
		m_length        = [m_expression length];	// Danger, Will Robinson?! We're dealing with a Unicode string...
		
		m_numbersCharSet    = [[NSCharacterSet characterSetWithCharactersInString:@"01234567890.,"] retain];
		m_mathOperations    = [[NSCharacterSet characterSetWithCharactersInString:@"+-*^/()[]"] retain];
		m_whiteSpaceCharSet = [[NSCharacterSet whitespaceCharacterSet] retain];
	}

	return self;
}

- (void)dealloc
{
	[m_numbersCharSet release];
	[m_mathOperations release];
	[m_whiteSpaceCharSet release];
	
	[m_expression release];
	m_expression = nil;
	
	[tokensArray release];
	tokensArray = nil;
	
	[super dealloc];
}

- (NSDecimalNumber *)evaluate
{
	NSDecimalNumber *value = nil;
	
	[self am_tokenizeExpression];
	if (self.tokenPosition < self.length) {
		
		NSString *reason = [NSString stringWithFormat:@"parse error after %@",
			[tokensArray lastObject]];

		NSException *e = [NSException exceptionWithName:NSInvalidArgumentException
			reason:reason
			userInfo:nil];
		
		@throw e;
		
	}
		/* Okay so far there are no bogus characters in the stream so it's okay */
	value = [self am_evaluate];
	return value;
}

@end

@implementation CBExpressionEvaluator (Private)

- (BOOL)am_isValidNumber:(NSString *)value
{
	NSCharacterSet *valueCharacterSet = [NSCharacterSet characterSetWithCharactersInString:value];
	return [self.numbersCharSet isSupersetOfSet:valueCharacterSet];

	/*BOOL isValidNumber = YES;

	NSUInteger length;
	NSUInteger i;

	length = [value length];
	for(i = 0; i < length; ++i) {
		if (![self.numbersCharSet characterIsMember:[value characterAtIndex:i]]) {
			isValidNumber = NO;
			break;
		}
	}
	
	return isValidNumber;*/
}

- (NSString *)am_nextToken;
{
	NSString	*token = nil;
	unichar		character;
	unichar		*buffer;
	NSInteger	i;

	if (self.tokenPosition < self.length) {
		character  = [self.expression characterAtIndex:self.tokenPosition];
		
		while(self.tokenPosition < self.length) {
			if ([self.whiteSpaceCharSet characterIsMember:character]) {
				++self.tokenPosition; /* Skip white space */
				character = [self.expression characterAtIndex:self.tokenPosition];
			} else {
				break;		/* If it's not a space, break out of here */
			}
		}

			/* If it's an operation character then return it */
		if ([self.mathOperations characterIsMember:character]) {
			++self.tokenPosition;
			token = [NSString stringWithCharacters:&character length:1];
		} else {

			buffer = (unichar *)NSZoneCalloc([self zone], self.length + 1, sizeof(unichar));
			if (buffer) {
				i = 0;
				
				while([self.numbersCharSet characterIsMember:character]) {
					buffer[i++] = character;
					++self.tokenPosition;
					if (self.tokenPosition >= self.length) {
						break;
					}
					character = [self.expression characterAtIndex:self.tokenPosition];
				}

				token = (i ? [NSString stringWithCharacters:buffer length:i] : nil);
				NSZoneFree([self zone], buffer);
			}
		}
	}
	return token;
}

- (void)am_tokenizeExpression
{
	NSString          *token;
	NSAutoreleasePool *pool;

	if (!tokensArray) {
		pool    = [[NSAutoreleasePool allocWithZone:[self zone]] init];
		token   = [self am_nextToken];
		tokensArray = [[NSMutableArray allocWithZone:[self zone]] init];
		
		while(token) {
			[tokensArray addObject:token];
			token = [self am_nextToken];
		}
		[pool release];
	}
}

- (BOOL)am_nextArgIsEqual:(NSString *)string
{
	BOOL nextArgIsEqual = NO;

	if (![self am_noMoreArgs]) {
		if ([[tokensArray objectAtIndex:self.arg] isEqualToString:string]) {
			nextArgIsEqual = YES;
		}
	}
	
	return nextArgIsEqual;
}

- (BOOL)am_noMoreArgs
{
	BOOL noMoreArgs = NO;

		/* If self.arg is the same as the number of things in tokensArray
		 * then we have hit the end of the array
		 */
	if (self.arg == [tokensArray count]) {
		noMoreArgs = YES;
	}

	return noMoreArgs;
}

- (NSDecimalNumber *)am_evaluate
{
	NSDecimalNumber	*lvalue;
	NSDecimalNumber	*rvalue;
	char			fxn;

	lvalue = [self am_evaluate1];

	while(1) {
		if ([self am_nextArgIsEqual:@"+"]) {
			fxn = '+';
		} else if ([self am_nextArgIsEqual:@"-"]) {
			fxn = '-';
		} else {
			break;
		}
		++self.arg; /* Move to the next argument */
		rvalue = [self am_evaluate1];

		switch(fxn) {
			case '+':
				lvalue = [lvalue decimalNumberByAdding:rvalue];
				break;

			case '-':
				lvalue = [lvalue decimalNumberBySubtracting:rvalue];
				break;
		}
	}

	return lvalue;
}

/* Handle *, / */
- (NSDecimalNumber *)am_evaluate1
{
	NSDecimalNumber	*lvalue;
	NSDecimalNumber	*rvalue;
	char			fxn;

	lvalue = [self am_evaluate2];

	while(1) {
		if ([self am_nextArgIsEqual:@"*"]) {
			fxn = '*';
		} else if ([self am_nextArgIsEqual:@"/"]) {
			fxn = '/';
		} else {
			break;
		}
		
		++self.arg; /* Move to the next argument */
		rvalue = [self am_evaluate2];

		switch(fxn) {
			case '*':
				lvalue = [lvalue decimalNumberByMultiplyingBy:rvalue];
				break;
				
			case '/':
				lvalue = [lvalue decimalNumberByDividingBy:rvalue];
				break;
		}
	}

	return lvalue;
}

- (NSDecimalNumber *)am_evaluate2
{
	NSDecimalNumber *lvalue;
	NSDecimalNumber *rvalue;
	char             fxn;

	lvalue = [self am_evaluate3];

	while(1) {
		if ([self am_nextArgIsEqual:@"^"]) {
			fxn = '^';
		} else {
			break;
		}
		
		++self.arg; /* Move to the next argument */
		rvalue = [self am_evaluate3];

		BOOL negatePower = NO;

		switch(fxn) {
			case '^':
				if ([rvalue integerValue] < 0) {
					negatePower = YES;
				}
				
				if (negatePower) {
					rvalue = [rvalue decimalNumberByMultiplyingBy:[NSDecimalNumber decimalNumberWithString:@"-1"]];
				}
				
				lvalue = [lvalue decimalNumberByRaisingToPower:[rvalue unsignedIntegerValue]];
				
				if (negatePower) {
					lvalue = [[NSDecimalNumber one] decimalNumberByDividingBy:lvalue];
				}
				break;
		}
	}

	return lvalue;
}

- (NSDecimalNumber *)am_evaluate3
{
	NSDecimalNumber	*value;
	BOOL			negate;
	
	if (self.length > 0) {
		negate = NO;
		if ([self am_noMoreArgs]) {
			
			NSString *reason = [NSString stringWithFormat:@"parse error at '%@' missing arguments",
				[tokensArray objectAtIndex:self.arg-1]];
			
			NSException *e = [NSException exceptionWithName:NSInvalidArgumentException
				reason:reason
				userInfo:nil];
			
			@throw e;
		}

		if ([self am_nextArgIsEqual:@"("]) {
			++self.arg; /* Move to the next argument */
			value = [self am_evaluate];
			if (![self am_nextArgIsEqual:@")"]) {
				
				NSString *reason = [NSString stringWithFormat:@"parse error missing ) after '%@'",
					[tokensArray objectAtIndex:self.arg-1]];
				
				NSException *e = [NSException exceptionWithName:NSInvalidArgumentException
					reason:reason
					userInfo:nil];
				
				@throw e;
			}
			++self.arg;
			return value;
		}
		
		if ([self am_nextArgIsEqual:@"["]) {
			++self.arg; /* Move to the next argument */
			value = [self am_evaluate];
			if (![self am_nextArgIsEqual:@"]"]) {
				
				NSString *reason = [NSString stringWithFormat:@"parse error missing ] after '%@'",
					[tokensArray objectAtIndex:self.arg-1]];
				
				NSException *e = [NSException exceptionWithName:NSInvalidArgumentException
					reason:reason
					userInfo:nil];
				
				@throw e;
			}
			++self.arg;
			return value;
		}

			/* Handle signed numbers here
			 */
		if ([self am_nextArgIsEqual:@"+"]) {
			++self.arg;
			negate = NO;
		}
		if ([self am_nextArgIsEqual:@"-"]) {
			++self.arg;
			negate = YES;
		}

		if (![self am_isValidNumber:[tokensArray objectAtIndex:self.arg]]) {
			
			NSString *reason = [NSString stringWithFormat:@"parse error at '%@' is not a valid number",
				[tokensArray objectAtIndex:self.arg]];
				
			NSException *e = [NSException exceptionWithName:NSInvalidArgumentException
				reason:reason
				userInfo:nil];
			
			@throw e;
		}
			/* Check if value is infact a number */
		value = [NSDecimalNumber decimalNumberWithString:[tokensArray objectAtIndex:self.arg]];
		if (negate) {
			value = [value decimalNumberByMultiplyingBy:[NSDecimalNumber decimalNumberWithString:@"-1"]];
		}
		++self.arg;
	} else {
		/* for an empty value */
		value = [NSDecimalNumber zero];
	}
	return value;
}

@end
