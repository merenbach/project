//
//  CBToolViewController.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on Thu Feb 27 2003.
//  Copyright (c) 2003 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CBScalePopUpButton;


@interface CBToolViewController : NSViewController {
    // property ivars
	NSString *m_title;
	//NSAttributedString *m_summary;
}

@property (copy, readwrite) NSString *title;
//@property (copy, readwrite) NSAttributedString *summary;

- (id)initWithNibName:(NSString *)nibName;

@end
