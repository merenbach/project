#import "CBMoleFractionsTool.h"
#import "CBCalculator.h"

#import "CBMoleFractionsToolRecord.h"
#import "CBMoleFractionsToolEntry.h"
#import "CBMoleFractionsToolResult.h"

#import "CBMoleFractionsToolEntry.h"

#import "CBScalePopUpButton.h"
#import "AMTableView.h"

NSString *CBMoleFractionsToolSoluteNameKey = @"soluteName";
NSString *CBMoleFractionsToolSoluteQuantityKey = @"soluteQuantity";
NSString *CBMoleFractionsToolSoluteScaleKey = @"soluteScale";
NSString *CBMoleFractionsToolMolarMassKey = @"molarMass";
NSString *CBMoleFractionsToolFractionalPartKey = @"fractionalPart";


@implementation CBMoleFractionsTool

@synthesize entriesArray = m_entriesArray;
@synthesize resultsArray = m_resultsArray;
@synthesize entriesTableView = m_entriesTableView;
@synthesize resultsTableView = m_resultsTableView;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_entriesArray = [[NSArray alloc] init];
		m_resultsArray = [[NSArray alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_entriesArray release];
	[m_resultsArray release];
	
	m_entriesArray = nil;
	m_resultsArray = nil;
	
	[super dealloc];
}

- (void)awakeFromNib {
	NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:CBMoleFractionsToolSoluteNameKey ascending:YES];
	NSArray *sortDescriptorArray = [NSArray arrayWithObject:sortDescriptor];
	[sortDescriptor release];
	
	[self.entriesTableView setSortDescriptors:sortDescriptorArray];
	[self.resultsTableView setSortDescriptors:sortDescriptorArray];
	
	self.entriesTableView.spaceKeyAdds = YES;
	self.entriesTableView.enterKeyAdds = YES;
	self.entriesTableView.deleteKeyRemoves = YES;
}

- (IBAction)calculate:(id)sender
{
	//id arrObjs = self.entriesArray;
	//NSEnumerator *e;
	
	//e = [arrObjs objectEnumerator];
	//id record;

	double m;
	double mm;
	double totalMoles = 0;
	CBMeasurementScale *scale;
	//unsigned scaleIdx;
	double quantity;
	
	//while (record = [e nextObject]) {
		//mm = [[record valueForKey:CBMoleFractionsToolMolarMassKey] doubleValue];
		//scaleIdx = [[record valueForKey:CBMoleFractionsToolSoluteScaleKey] unsignedIntValue];
		//scale = [CBCalculator scaleAtIndex:scaleIdx inCategory:CBScaleMassMolesKey];
		//m = [CBCalculator convert:[[record valueForKey:CBMoleFractionsToolSoluteQuantityKey] doubleValue] fromScale:scale category:CBScaleMassMolesKey molarMass:mm];
		//totalMoles += m;
	//}
	
	for (CBMoleFractionsToolEntry *entry in self.entriesArray) {
		mm = entry.molarMass;
		scale = entry.soluteScale;
		quantity = entry.soluteQuantity;
		m = [CBCalculator convert:quantity fromScale:scale molarMass:mm];
		totalMoles += m;
	}
	
	NSMutableArray *array = [NSMutableArray array];
	double f;
	
	//e = [arrObjs objectEnumerator];
	//while (record = [e nextObject])
	for (CBMoleFractionsToolEntry *entry in self.entriesArray) {
		/*scaleIdx = [[record valueForKey:CBMoleFractionsToolSoluteScaleKey] unsignedIntValue];
		scale = [CBCalculator scaleAtIndex:scaleIdx inCategory:CBScaleMassMolesKey];
		m = [CBCalculator convert:[[record valueForKey:CBMoleFractionsToolSoluteQuantityKey] doubleValue] fromScale:scale category:CBScaleMassMolesKey molarMass:mm];
		
		f = m / totalMoles * 100.0;
		
		NSMutableDictionary *result = [NSMutableDictionary dictionary];
		[result setObject:[record valueForKey:CBMoleFractionsToolSoluteNameKey] forKey:CBMoleFractionsToolSoluteNameKey];
		[result setObject:[NSNumber numberWithDouble:f] forKey:CBMoleFractionsToolFractionalPartKey];
		[array addObject:result];*/
		quantity = entry.soluteQuantity;
		m = [CBCalculator convert:quantity fromScale:scale molarMass:mm];
		
		f = m / totalMoles * 100.0;
		
		// create a result
		CBMoleFractionsToolResult *result = [CBMoleFractionsToolResult record];
		result.soluteName = entry.soluteName;
		result.fractionalPart = f;
		[array addObject:result];
		//NSMutableDictionary *result = [NSMutableDictionary dictionary];
		//[result setObject:[record valueForKey:CBMoleFractionsToolSoluteNameKey] forKey:CBMoleFractionsToolSoluteNameKey];
		//[result setObject:[NSNumber numberWithDouble:f] forKey:CBMoleFractionsToolFractionalPartKey];
		//[array addObject:result];
	}
	
	self.resultsArray = array;
}

@end