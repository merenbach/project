//
//  CBToolPopUpButton.m
//  Valence
//
//  Created by Andrew Merenbach on 4/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBToolPopUpButton.h"
#import "CBScaleMenu.h"


@implementation CBToolPopUpButton

- (id)initWithFrame:(NSRect)frameRect pullsDown:(BOOL)flag {
	self = [super initWithFrame:frameRect pullsDown:flag];
	if (self != nil) {
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
	}
	return self;
}

@end

@implementation CBToolPopUpButtonCell

- (id)initTextCell:(NSString *)aString pullsDown:(BOOL)flag {
	self = [super initTextCell:aString pullsDown:flag];
	if (self != nil) {
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		CBScaleMenu *menu = [[CBScaleMenu alloc] init];
		[self setMenu:menu];
	}
	return self;
}

@end
