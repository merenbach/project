//
//  CBCalculator.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on Mon Dec 30 2002.
//  Copyright (c) 2002 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CBMeasurementScale.h"

@class CBScalePopUpButton;
@class CBMeasurementScale;


@interface CBCalculator : NSObject {
    
}

+ (double)convert:(double)input fromScale:(NSString *)scale category:(NSString *)category;
+ (double)convert:(double)input toScale:(NSString *)scale category:(NSString *)category;

+ (double)convert:(double)input fromScale:(NSString *)scale category:(NSString *)category molarMass:(double)mm hasMolarScale:(BOOL)scaleIsMolarFlag;
+ (double)convert:(double)input toScale:(NSString *)scale category:(NSString *)category molarMass:(double)mm hasMolarScale:(BOOL)scaleIsMolarFlag;

+ (double)convert:(double)input fromScale:(CBMeasurementScale *)scale;
+ (double)convert:(double)input toScale:(CBMeasurementScale *)scale;
+ (double)convert:(double)input fromScale:(CBMeasurementScale *)scale molarMass:(double)mm;
+ (double)convert:(double)input toScale:(CBMeasurementScale *)scale molarMass:(double)mm; 
@end
