//
//  CBMainWindowController.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CBToolsOutlineView;
@class CBToolViewController;


@interface CBMainWindowController : NSWindowController {
	CBToolsOutlineView *m_toolsOutlineView;
	NSTreeController *m_toolsTreeController;
	NSTextView *m_toolInformationTextView;

	NSScrollView *m_toolScrollView;
	NSSplitView *m_toolsSplitView;
	
	BOOL m_isMainInterfaceLoaded;
	NSView *m_parentView;

	//NSView *blankView;	// a placeholder, used while swapping the main window's content view
	
	//NSAttributedString *m_toolSummary;
	
	
	NSViewController *m_currentToolViewController;

	NSViewController *m_mainViewController;
}

@property (assign) IBOutlet CBToolsOutlineView *toolsOutlineView;
@property (assign) IBOutlet NSTreeController *toolsTreeController;
@property (assign) IBOutlet NSTextView *toolInformationTextView;

@property (assign) IBOutlet NSScrollView *toolScrollView;
@property (assign) IBOutlet NSSplitView *toolsSplitView;

@property (assign, readwrite) BOOL isMainInterfaceLoaded;
@property (assign) IBOutlet NSView *parentView;

//@property (copy, readwrite) NSAttributedString *toolSummary;
@property (retain, readwrite) NSViewController *currentToolViewController;
@property (retain, readwrite) NSViewController *mainViewController;


- (IBAction)loadSelectedTool:(id)sender;
- (void)showMainView:(id)sender;
- (void)showTool:(CBToolViewController *)tool;
- (void)replaceOldView:(NSView *)oldView withNewView:(NSView *)newView;

@end


@interface CBMainWindowController (OutlineView)

- (BOOL)outlineView:(NSOutlineView *)outlineView isGroupItem:(id)item;
	
@end

@interface CBMainWindowController (SplitViewDelegateMethods)
//- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset;
//- (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset;
- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset;
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize;
- (void)windowDidResize:(NSNotification *)notification;
@end
