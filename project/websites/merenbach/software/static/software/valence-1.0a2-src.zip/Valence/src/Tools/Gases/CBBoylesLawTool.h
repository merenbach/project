#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBBoylesLawTool : CBToolViewController
{
	double m_pressureTabP1Value;
	double m_pressureTabP2Value;
	double m_pressureTabV1Value;
	double m_pressureTabV2Value;
	
	double m_volumeTabP1Value;
	double m_volumeTabP2Value;
	double m_volumeTabV1Value;
	double m_volumeTabV2Value;
	
	CBMeasurementScale *m_pressureTabP1Scale;
	CBMeasurementScale *m_pressureTabP2Scale;
	CBMeasurementScale *m_pressureTabV1Scale;
	CBMeasurementScale *m_pressureTabV2Scale;
	
	CBMeasurementScale *m_volumeTabP1Scale;
	CBMeasurementScale *m_volumeTabP2Scale;
	CBMeasurementScale *m_volumeTabV1Scale;
	CBMeasurementScale *m_volumeTabV2Scale;
}

@property (assign, readwrite) double pressureTabP1Value;
@property (assign, readwrite) double pressureTabP2Value;
@property (assign, readwrite) double pressureTabV1Value;
@property (assign, readwrite) double pressureTabV2Value;

@property (assign, readwrite) double volumeTabP1Value;
@property (assign, readwrite) double volumeTabP2Value;
@property (assign, readwrite) double volumeTabV1Value;
@property (assign, readwrite) double volumeTabV2Value;

@property (retain, readwrite) CBMeasurementScale *pressureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabV2Scale;

@property (retain, readwrite) CBMeasurementScale *volumeTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV2Scale;

- (IBAction)calculatePressure:(id)sender;
- (IBAction)calculateVolume:(id)sender;

@end
