//
//  ValenceAppDelegate.h
//  Valence
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CBMainWindowController;
@class CBPreferencesWindowController;
@class CBPeriodicTableWindowController;
@class CBMolarMassWindowController;


@interface ValenceAppDelegate : NSObject {
	CBMainWindowController *m_mainWindowController;
	CBPreferencesWindowController *m_preferencesWindowController;
	CBPeriodicTableWindowController *m_periodicTableWindowController;
	CBMolarMassWindowController *m_molarMassWindowController;
}

@property (readonly) CBMainWindowController *mainWindowController;
@property (readonly) CBPreferencesWindowController *preferencesWindowController;
@property (readonly) CBPeriodicTableWindowController *periodicTableWindowController;
@property (readonly) CBMolarMassWindowController *molarMassWindowController;

@end

@interface ValenceAppDelegate (WindowMethods)
- (IBAction)showMainWindow:(id)sender;
- (IBAction)showPreferencesWindow:(id)sender;
- (IBAction)showPeriodicTable:(id)sender;
- (IBAction)showMolarMassCalculator:(id)sender;
@end