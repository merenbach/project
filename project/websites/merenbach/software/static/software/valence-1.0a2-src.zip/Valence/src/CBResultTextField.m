//
//  CBResultTextField.m
//  Valence
//
//  Created by Andrew Merenbach on 4/12/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBResultTextField.h"


@implementation CBResultTextField

- (id)initWithFrame:(NSRect)frameRect {
	self = [super initWithFrame:frameRect];
	if (self != nil) {
		[self setEditable:NO];
		[self setSelectable:YES];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		[self setEditable:NO];
		[self setSelectable:YES];
	}
	return self;
}

@end

@implementation CBResultTextFieldCell

- (id)initTextCell:(NSString *)aString {
	self = [super initTextCell:aString];
	if (self != nil) {
		[self setEditable:NO];
		[self setSelectable:YES];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		[self setEditable:NO];
		[self setSelectable:YES];
	}
	return self;
}

@end
