#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;

@interface CBIdealGasLawTool : CBToolViewController
{    
	double m_pressureTabPressureValue;
	double m_pressureTabVolumeValue;
	double m_pressureTabTemperatureValue;
	double m_pressureTabQuantityValue;
	
	double m_volumeTabPressureValue;
	double m_volumeTabVolumeValue;
	double m_volumeTabTemperatureValue;
	double m_volumeTabQuantityValue;

	double m_quantityTabPressureValue;
	double m_quantityTabVolumeValue;
	double m_quantityTabTemperatureValue;
	double m_quantityTabQuantityValue;
	
	double m_temperatureTabPressureValue;
	double m_temperatureTabVolumeValue;
	double m_temperatureTabTemperatureValue;
	double m_temperatureTabQuantityValue;
	
	CBMeasurementScale *m_pressureTabPressureScale;
	CBMeasurementScale *m_pressureTabVolumeScale;
	CBMeasurementScale *m_pressureTabTemperatureScale;
	CBMeasurementScale *m_pressureTabQuantityScale;
	
	CBMeasurementScale *m_volumeTabPressureScale;
	CBMeasurementScale *m_volumeTabVolumeScale;
	CBMeasurementScale *m_volumeTabTemperatureScale;
	CBMeasurementScale *m_volumeTabQuantityScale;

	CBMeasurementScale *m_quantityTabPressureScale;
	CBMeasurementScale *m_quantityTabVolumeScale;
	CBMeasurementScale *m_quantityTabTemperatureScale;
	CBMeasurementScale *m_quantityTabQuantityScale;
	
	CBMeasurementScale *m_temperatureTabPressureScale;
	CBMeasurementScale *m_temperatureTabVolumeScale;
	CBMeasurementScale *m_temperatureTabTemperatureScale;
	CBMeasurementScale *m_temperatureTabQuantityScale;
}

@property (assign, readwrite) double pressureTabPressureValue;
@property (assign, readwrite) double pressureTabVolumeValue;
@property (assign, readwrite) double pressureTabTemperatureValue;
@property (assign, readwrite) double pressureTabQuantityValue;

@property (assign, readwrite) double volumeTabPressureValue;
@property (assign, readwrite) double volumeTabVolumeValue;
@property (assign, readwrite) double volumeTabTemperatureValue;
@property (assign, readwrite) double volumeTabQuantityValue;

@property (assign, readwrite) double quantityTabPressureValue;
@property (assign, readwrite) double quantityTabVolumeValue;
@property (assign, readwrite) double quantityTabTemperatureValue;
@property (assign, readwrite) double quantityTabQuantityValue;

@property (assign, readwrite) double temperatureTabPressureValue;
@property (assign, readwrite) double temperatureTabVolumeValue;
@property (assign, readwrite) double temperatureTabTemperatureValue;
@property (assign, readwrite) double temperatureTabQuantityValue;

@property (retain, readwrite) CBMeasurementScale *pressureTabPressureScale;
@property (retain, readwrite) CBMeasurementScale *pressureTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *pressureTabTemperatureScale;
@property (retain, readwrite) CBMeasurementScale *pressureTabQuantityScale;

@property (retain, readwrite) CBMeasurementScale *volumeTabPressureScale;
@property (retain, readwrite) CBMeasurementScale *volumeTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *volumeTabTemperatureScale;
@property (retain, readwrite) CBMeasurementScale *volumeTabQuantityScale;

@property (retain, readwrite) CBMeasurementScale *quantityTabPressureScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabTemperatureScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabQuantityScale;

@property (retain, readwrite) CBMeasurementScale *temperatureTabPressureScale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabTemperatureScale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabQuantityScale;

- (IBAction)calculatePressure:(id)sender;
- (IBAction)calculateVolume:(id)sender;
- (IBAction)calculateQuantity:(id)sender;
- (IBAction)calculateTemperature:(id)sender;

@end
