//
//  CBDaltonsLawToolEntry.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBDaltonsLawToolEntry.h"
#import "CBCalculator.h"
#import "CBScalePopUpButton.h"


@implementation CBDaltonsLawToolEntry

@synthesize gasName = m_gasName;
@synthesize pressureValue = m_pressureValue;
@synthesize gasScale = m_gasScale;


+ (NSArray *)copyKeys {
	static NSArray *array = nil;
	if (!array) {
		array = [[NSArray alloc] initWithObjects:
			@"gasName",
			@"pressureValue",
			@"gasScale",
			nil];
	}
	return array;
}

- (id)init {
	self = [super init];
	if (self != nil) {
		m_gasName = [[NSString alloc] initWithString:@"Untitled"];
		m_pressureValue = 0;
		m_gasScale = [[CBMeasurementScale initialPressureScale] retain];
	}
	return self;
}

- (void)dealloc {
	[m_gasName release];
	m_gasName = nil;
	
	//[m_pressureValue release];
	//m_pressureValue = nil;
	
	[m_gasScale release];
	m_gasScale = nil;
	
	[super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
	CBDaltonsLawToolEntry *copy = [[[self class] allocWithZone:zone] init];
	
	copy.gasName = self.gasName;
	copy.pressureValue = self.pressureValue;
	copy.gasScale = self.gasScale;
	
	return copy;
}

- (NSDictionary *)dictionaryRepresentation {
	return [self dictionaryWithValuesForKeys:[[self class] copyKeys]];
}

@end