//
//  CBTool\.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on Thu Feb 27 2003.
//  Copyright (c) 2003 Andrew Merenbach. All rights reserved.
//

#import "CBToolViewController.h"
#import "CBCalculator.h"


@implementation CBToolViewController

@synthesize title = m_title;
//@synthesize summary = m_summary;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName bundle:nil];
	/*if (self != nil) {
		NSBundle *bundle = [NSBundle mainBundle];
		String *path;
		path = [bundle pathForResource:nibName ofType:@"rtf"];
		if (!path) path = [bundle pathForResource:nibName ofType:@"rtfd"];
		if (!path) path = @"";
		
		NSAttributedString *newSummary = [[NSAttributedString alloc] initWithPath:path documentAttributes:NULL];
		if (!newSummary) newSummary = [[NSAttributedString alloc] initWithString:@""];
		self.summary = newSummary;
	}*/
	return self;
}

@end
