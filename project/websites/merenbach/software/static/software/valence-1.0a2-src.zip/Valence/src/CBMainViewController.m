//
//  CBMainViewController.m
//  Valence
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMainViewController.h"


@implementation CBMainViewController

- (id)init {
	self = [super initWithNibName:@"MainView" bundle:nil];
	return self;
}

//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  //  self = [super initWithNibName:@"MainView" bundle:nil];
    /*if (self != nil) {
        
    }*/
    //return self;
//}

@end
