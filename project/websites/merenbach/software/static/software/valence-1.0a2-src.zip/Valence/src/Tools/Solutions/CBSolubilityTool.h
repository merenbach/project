#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBSolubilityTool : CBToolViewController
{
	/*IBOutlet NSTextField *solubilityP1Field;
	IBOutlet NSTextField *solubilityP2Field;
	IBOutlet NSTextField *solubilityS1Field;
	IBOutlet NSTextField *solubilityS2Field;
	
	IBOutlet CBScalePopUpButton *solubilityP1Menu;
	IBOutlet CBScalePopUpButton *solubilityP2Menu;
	
	IBOutlet NSTextField *pressureP1Field;
	IBOutlet NSTextField *pressureP2Field;
	IBOutlet NSTextField *pressureS1Field;
	IBOutlet NSTextField *pressureS2Field;
	
	IBOutlet CBScalePopUpButton *pressureP1Menu;
	IBOutlet CBScalePopUpButton *pressureP2Menu;*/
	
	double m_solubilityTabP1Value;
	double m_solubilityTabP2Value;
	double m_solubilityTabS1Value;
	double m_solubilityTabS2Value;
	
	double m_pressureTabP1Value;
	double m_pressureTabP2Value;
	double m_pressureTabS1Value;
	double m_pressureTabS2Value;
	
	CBMeasurementScale *m_solubilityTabP1Scale;
	CBMeasurementScale *m_solubilityTabP2Scale;
	CBMeasurementScale *m_pressureTabP1Scale;
	CBMeasurementScale *m_pressureTabP2Scale;	
}

@property (assign, readwrite) double solubilityTabP1Value;
@property (assign, readwrite) double solubilityTabP2Value;
@property (assign, readwrite) double solubilityTabS1Value;
@property (assign, readwrite) double solubilityTabS2Value;
@property (assign, readwrite) double pressureTabP1Value;
@property (assign, readwrite) double pressureTabP2Value;
@property (assign, readwrite) double pressureTabS1Value;
@property (assign, readwrite) double pressureTabS2Value;
@property (retain, readwrite) CBMeasurementScale *solubilityTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *solubilityTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabP2Scale;

- (IBAction)calculateSolubility:(id)sender;
- (IBAction)calculatePressure:(id)sender;

@end
