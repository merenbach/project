//
//  CBMaximumRecentItemsController.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 8/4/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBMaximumRecentItemsController : NSObject {
	unsigned AM_maxNumberOfRecentItems;
}

+ (CBMaximumRecentItemsController *)sharedInstance;

- (unsigned)maxNumberOfRecentItems;
- (void)setMaxNumberOfRecentItems:(unsigned)anInt;

@end
