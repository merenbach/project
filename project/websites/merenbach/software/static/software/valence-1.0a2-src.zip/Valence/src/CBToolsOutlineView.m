//
//  CBToolsOutlineView.m
//  Valence
//
//  Created by Andrew Merenbach on 4/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBToolsOutlineView.h"


@implementation CBToolsOutlineView

- (NSRect)frameOfOutlineCellAtRow:(NSInteger)row {
	return NSZeroRect;
}


@end
