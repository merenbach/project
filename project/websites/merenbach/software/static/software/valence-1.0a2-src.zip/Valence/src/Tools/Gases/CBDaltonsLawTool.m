#import "CBDaltonsLawTool.h"
#import "CBDaltonsLawToolEntry.h"

#import "CBCalculator.h"
#import "CBScalePopUpButton.h"

#import "AMTableView.h"
#import "AMDragAndDropArrayController.h"

NSString *CBDaltonsLawToolGasNameKey = @"gasName";
NSString *CBDaltonsLawToolPressureValueKey = @"pressureValue";
NSString *CBDaltonsLawToolScaleValueKey = @"scaleValue";


@implementation CBDaltonsLawTool

@synthesize pressureTableView = m_pressureTableView;
@synthesize pressureArrayController = m_pressureArrayController;
@synthesize pressureRecords = m_pressureRecords;
@synthesize totalPressureValue = m_totalPressureValue;
@synthesize totalPressureScale = m_totalPressureScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_pressureRecords = [[NSArray alloc] init];
		m_totalPressureValue = 0;
		m_totalPressureScale = [[CBMeasurementScale initialPressureScale] retain];
	}
	return self;
}

- (void)dealloc {
	[m_pressureRecords release];
	m_pressureRecords = nil;
	
	[m_totalPressureScale release];
	m_totalPressureScale = nil;
	
	[super dealloc];
}

- (void)awakeFromNib {
	NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:CBDaltonsLawToolGasNameKey ascending:YES];
	NSArray *sortDescriptorArray = [NSArray arrayWithObject:sortDescriptor];
	[sortDescriptor release];
	
	[self.pressureTableView setSortDescriptors:sortDescriptorArray];
	
	self.pressureTableView.spaceKeyAdds = YES;
	self.pressureTableView.enterKeyAdds = YES;
	self.pressureTableView.deleteKeyRemoves = YES;
	
	self.pressureArrayController.isDraggingEnabled = YES;
	self.pressureArrayController.isDraggingEnabledWithCopy = YES;
}

- (IBAction)calculate:(id)sender
{
	NSArray *records = self.pressureRecords;

	double p = 0;

	for (CBDaltonsLawToolEntry *record in records) {
		//NSUInteger scaleIdx = [[record valueForKey:CBDaltonsLawToolScaleValueKey] unsignedIntValue];
		//NSString *scale = [CBCalculator scaleAtIndex:scaleIdx inCategory:CBScalePressureKey];
		//p += [CBCalculator convert:[[record valueForKey:CBDaltonsLawToolPressureValueKey] doubleValue] fromScale:scale category:CBScalePressureKey];
		p += [CBCalculator convert:record.pressureValue fromScale:record.gasScale];
	}

	//p = [CBCalculator convert:p toScaleMenu:pressureMenu];
	//[resultField setDoubleValue:p];
	p = [CBCalculator convert:p toScale:self.totalPressureScale];
	self.totalPressureValue = p;
}

@end