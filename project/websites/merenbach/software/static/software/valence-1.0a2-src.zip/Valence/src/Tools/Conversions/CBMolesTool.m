#import "CBMolesTool.h"
#import "CBCalculator.h"

@implementation CBMolesTool

@synthesize molesTabSampleMassValue = m_molesTabSampleMassValue;
@synthesize molesTabQuantityValue = m_molesTabQuantityValue;
@synthesize massTabSampleMassValue = m_massTabSampleMassValue;
@synthesize massTabQuantityValue = m_massTabQuantityValue;
@synthesize molesTabMolarMassValue = m_molesTabMolarMassValue;
@synthesize massTabMolarMassValue = m_massTabMolarMassValue;
@synthesize molesTabSampleMassScale = m_molesTabSampleMassScale;
@synthesize molesTabQuantityScale = m_molesTabQuantityScale;
@synthesize massTabSampleMassScale = m_massTabSampleMassScale;
@synthesize massTabQuantityScale = m_massTabQuantityScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_molesTabSampleMassValue = 0;
		m_molesTabQuantityValue = 0;
		m_massTabSampleMassValue = 0;
		m_massTabQuantityValue = 0;
		m_molesTabMolarMassValue = 0;
		m_massTabMolarMassValue = 0;
		
		m_molesTabSampleMassScale = [[CBMeasurementScale initialMassScale] retain];
		m_molesTabQuantityScale = [[CBMeasurementScale initialMolesScale] retain];
		m_massTabSampleMassScale = [[CBMeasurementScale initialMassScale] retain];
		m_massTabQuantityScale = [[CBMeasurementScale initialMolesScale] retain];
	}
	return self;
}

- (void)dealloc {
	[m_molesTabSampleMassScale release];
	m_molesTabSampleMassScale = nil;
	
	[m_molesTabQuantityScale release];
	m_molesTabQuantityScale = nil;
	
	[m_massTabSampleMassScale release];
	m_massTabSampleMassScale = nil;
	
	[m_massTabQuantityScale release];
	m_massTabQuantityScale = nil;
	
	[super dealloc];
}

- (IBAction)calculateMoles:(id)sender
{
    double sampleMass = self.molesTabSampleMassValue;
    double molarMass = self.molesTabMolarMassValue;
    double quantity;
    
    sampleMass = [CBCalculator convert:sampleMass fromScale:self.molesTabSampleMassScale];

    /* finish up with the calculation itself */
    quantity = sampleMass / molarMass;
    quantity = [CBCalculator convert:quantity toScale:self.molesTabQuantityScale];

    self.molesTabQuantityValue = quantity;
}

- (IBAction)calculateMass:(id)sender
{
    double sampleMass;
    double molarMass = self.massTabMolarMassValue;
    double quantity = self.massTabQuantityValue;

    quantity = [CBCalculator convert:quantity fromScale:self.massTabQuantityScale];
    sampleMass = quantity * molarMass;
    sampleMass = [CBCalculator convert:sampleMass toScale:self.massTabSampleMassScale];

    self.massTabSampleMassValue = sampleMass;
}

@end
