//
//  CBMoleFractionsToolEntry.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CBMoleFractionsToolRecord.h"

@class CBMeasurementScale;


@interface CBMoleFractionsToolEntry : CBMoleFractionsToolRecord <NSCopying> {
	double m_soluteQuantity;
	double m_molarMass;
	CBMeasurementScale *m_soluteScale;
}

@property (assign, readwrite) double soluteQuantity;
@property (assign, readwrite) double molarMass;
@property (retain, readwrite) CBMeasurementScale *soluteScale;

+ (NSArray *)copyKeys;
- (id)init;
- (void)dealloc;
- (id)copyWithZone:(NSZone *)zone;
- (NSDictionary *)dictionaryRepresentation;

@end