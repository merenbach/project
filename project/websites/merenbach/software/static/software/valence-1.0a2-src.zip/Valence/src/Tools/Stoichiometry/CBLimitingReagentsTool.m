#import "CBLimitingReagentsTool.h"
#import "CBCalculator.h"
#import "CBFormulaEvaluator.h"
#import "CBScalePopUpButton.h"

#define CB_LR_UNIT_TYPE_TAG_DEFAULT 1	/* default tag on matrix of radio buttons */


@implementation CBLimitingReagentsTool

@synthesize reactant1QuantityRadioButtons = m_reactant1QuantityRadioButtons;
@synthesize reactant2QuantityRadioButtons = m_reactant2QuantityRadioButtons;

@synthesize reactant1UnitTypeTag = m_reactant1UnitTypeTag;
@synthesize reactant2UnitTypeTag = m_reactant2UnitTypeTag;
@synthesize reactant1UsesMoles = m_reactant1UsesMoles;
@synthesize reactant1UsesMass = m_reactant1UsesMass;
@synthesize reactant2UsesMoles = m_reactant2UsesMoles;
@synthesize reactant2UsesMass = m_reactant2UsesMass;

@synthesize reactant1Name = m_reactant1Name;
@synthesize reactant2Name = m_reactant2Name;
@synthesize reactant1MolesValue = m_reactant1MolesValue;
@synthesize reactant1MassValue = m_reactant1MassValue;
@synthesize reactant2MolesValue = m_reactant2MolesValue;
@synthesize reactant2MassValue = m_reactant2MassValue;
@synthesize reactant1MolarMass = m_reactant1MolarMass;
@synthesize reactant2MolarMass = m_reactant2MolarMass;
@synthesize productMolarMass = m_productMolarMass;
@synthesize reactant1Coefficient = m_reactant1Coefficient;
@synthesize reactant2Coefficient = m_reactant2Coefficient;
@synthesize productCoefficient = m_productCoefficient;

@synthesize limitingReagentName = m_limitingReagentName;
@synthesize excessReagentName = m_excessReagentName;
@synthesize productMolesValue = m_productMolesValue;
@synthesize productMassValue = m_productMassValue;
@synthesize limitingReagentMolesUsedValue = m_limitingReagentMolesUsedValue;
@synthesize limitingReagentMassUsedValue = m_limitingReagentMassUsedValue;
@synthesize excessReagentMolesUsedValue = m_excessReagentMolesUsedValue;
@synthesize excessReagentMassUsedValue = m_excessReagentMassUsedValue;
@synthesize excessReagentMolesLeftValue = m_excessReagentMolesLeftValue;
@synthesize excessReagentMassLeftValue = m_excessReagentMassLeftValue;

@synthesize reactant1MolesScale = m_reactant1MolesScale;
@synthesize reactant1MassScale = m_reactant1MassScale;
@synthesize reactant2MolesScale = m_reactant2MolesScale;
@synthesize reactant2MassScale = m_reactant2MassScale;	
@synthesize productMolesScale = m_productMolesScale;
@synthesize productMassScale = m_productMassScale;
@synthesize limitingReagentMolesUsedScale = m_limitingReagentMolesUsedScale;
@synthesize limitingReagentMassUsedScale = m_limitingReagentMassUsedScale;
@synthesize excessReagentMolesUsedScale = m_excessReagentMolesUsedScale;
@synthesize excessReagentMassUsedScale = m_excessReagentMassUsedScale;
@synthesize excessReagentMolesLeftScale = m_excessReagentMolesLeftScale;
@synthesize excessReagentMassLeftScale = m_excessReagentMassLeftScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_reactant1UnitTypeTag = CB_LR_UNIT_TYPE_TAG_DEFAULT;
		m_reactant2UnitTypeTag = CB_LR_UNIT_TYPE_TAG_DEFAULT;
		m_reactant1UsesMoles = NO;
		m_reactant1UsesMass = NO;
		m_reactant2UsesMoles = NO;
		m_reactant2UsesMass = NO;
		
		m_reactant1Name = [[NSString alloc] initWithString:NSLocalizedString(@"Reactant 1", @"Reactant 1")];
		m_reactant2Name = [[NSString alloc] initWithString:NSLocalizedString(@"Reactant 2", @"Reactant 2")];
		m_reactant1MolesValue = 0;
		m_reactant1MassValue = 0;
		m_reactant2MolesValue = 0;
		m_reactant2MassValue = 0;
		m_reactant1MolarMass = 0;
		m_reactant2MolarMass = 0;
		m_productMolarMass = 0;
		m_reactant1Coefficient = 0;
		m_reactant2Coefficient = 0;
		m_productCoefficient = 0;
		
		m_limitingReagentName = [[NSString alloc] initWithString:@""];
		m_excessReagentName = [[NSString alloc] initWithString:@""];
		m_productMolesValue = 0;
		m_productMassValue = 0;
		m_limitingReagentMolesUsedValue = 0;
		m_limitingReagentMassUsedValue = 0;
		m_excessReagentMolesUsedValue = 0;
		m_excessReagentMassUsedValue = 0;
		m_excessReagentMolesLeftValue = 0;
		m_excessReagentMassLeftValue = 0;

		m_reactant1MolesScale = [[CBMeasurementScale initialMolesScale] retain];
		m_reactant1MassScale = [[CBMeasurementScale initialMassScale] retain];
		m_reactant2MolesScale = [[CBMeasurementScale initialMolesScale] retain];
		m_reactant2MassScale = [[CBMeasurementScale initialMassScale] retain];
		m_productMolesScale = [[CBMeasurementScale initialMolesScale] retain];
		m_productMassScale = [[CBMeasurementScale initialMassScale] retain];
		m_limitingReagentMolesUsedScale = [[CBMeasurementScale initialMolesScale] retain];
		m_limitingReagentMassUsedScale = [[CBMeasurementScale initialMassScale] retain];
		m_excessReagentMolesUsedScale = [[CBMeasurementScale initialMolesScale] retain];
		m_excessReagentMassUsedScale = [[CBMeasurementScale initialMassScale] retain];
		m_excessReagentMolesLeftScale = [[CBMeasurementScale initialMolesScale] retain];
		m_excessReagentMassLeftScale = [[CBMeasurementScale initialMassScale] retain];
		
		[self addObserver:self forKeyPath:@"reactant1UnitTypeTag" options:0 context:NULL];
		[self addObserver:self forKeyPath:@"reactant2UnitTypeTag" options:0 context:NULL];
		
		[self updateInputFieldAvailability:nil];
	}
	return self;
}

- (void)finalize {
	[self removeObserver:self forKeyPath:@"reactant1UnitTypeTag"];
	[self removeObserver:self forKeyPath:@"reactant2UnitTypeTag"];

	[super finalize];
}

- (void)dealloc {
	[self removeObserver:self forKeyPath:@"reactant1UnitTypeTag"];
	[self removeObserver:self forKeyPath:@"reactant2UnitTypeTag"];
	
	[m_reactant1MolesScale release];
	[m_reactant1MassScale release];
	[m_reactant2MolesScale release];
	[m_reactant2MassScale release];
	[m_productMolesScale release];
	[m_productMassScale release];
	[m_limitingReagentMolesUsedScale release];
	[m_limitingReagentMassUsedScale release];
	[m_excessReagentMolesUsedScale release];
	[m_excessReagentMassUsedScale release];
	[m_excessReagentMolesLeftScale release];
	[m_excessReagentMassLeftScale release];

	m_reactant1MolesScale = nil;
	m_reactant1MassScale = nil;
	m_reactant2MolesScale = nil;
	m_reactant2MassScale = nil;
	m_productMolesScale = nil;
	m_productMassScale = nil;
	m_limitingReagentMolesUsedScale = nil;
	m_limitingReagentMassUsedScale = nil;
	m_excessReagentMolesUsedScale = nil;
	m_excessReagentMassUsedScale = nil;
	m_excessReagentMolesLeftScale = nil;
	m_excessReagentMassLeftScale = nil;
	
	[super dealloc];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([keyPath isEqualToString:@"reactant1UnitTypeTag"] || [keyPath isEqualToString:@"reactant2UnitTypeTag"]) {
		[self performSelectorOnMainThread:@selector(updateInputFieldAvailability:) withObject:nil waitUntilDone:YES];
	} else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)updateInputFieldAvailability:(id)sender {
	self.reactant1UsesMoles = (self.reactant1UnitTypeTag == CBLimitingReagentsQuantityIsMoles);
	self.reactant1UsesMass = (self.reactant1UnitTypeTag == CBLimitingReagentsQuantityIsMass);
	self.reactant2UsesMoles = (self.reactant2UnitTypeTag == CBLimitingReagentsQuantityIsMoles);
	self.reactant2UsesMass = (self.reactant2UnitTypeTag == CBLimitingReagentsQuantityIsMass);
}


/*float arbprec(float number, int precision)
{
// More complete way 
float temp1;
int temp2;
float temp3;
temp1=number*pow(10, precision-1);
temp2=floor(temp1);
temp3=temp2/pow(10,precision-1)
return temp3;
}
*/
/*float savvy_arbprec(float number, int precision)
{
// Savvy way 
return floor(number*pow(10, precision-1))/pow(10,precision-1);
}

#define setBoolDefault(name) \
  {if ([[defaultValues() objectForKey:name] isEqual:[dict objectForKey:name]]) [defaults removeObjectForKey:name]; else [defaults setBool:[[dict objectForKey:name] boolValue] forKey:name];}

#define getArbPrecision(number,precision) \
  (floor(number*pow(10, precision-1))/pow(10,precision-1));*/

- (IBAction)calculate:(id)sender
{
	/*CBFormulaEvaluator *evaluator = [[CBFormulaEvaluator alloc] init];
	[evaluator setFormula:[reactant1TextField stringValue];
	[evaluator setFormula:[reactant2TextField stringValue];
	[evaluator setFormula:[productTextField stringValue];*/


	double molarMassOfX = self.reactant1MolarMass;
	double molarMassOfY = self.reactant2MolarMass;
	double molarMassOfProduct = self.productMolarMass;

	double molesOfX;
	double molesOfY;

	if (self.reactant1UnitTypeTag == CBLimitingReagentsQuantityIsMoles) {
		molesOfX = self.reactant1MolesValue;
		molesOfX = [CBCalculator convert:molesOfX fromScale:self.reactant1MolesScale];

	} else if (self.reactant1UnitTypeTag == CBLimitingReagentsQuantityIsMass) {
		double massOfX = self.reactant1MassValue;		
		massOfX = [CBCalculator convert:massOfX fromScale:self.reactant1MassScale];
		
		if (molarMassOfX != 0) {
			molesOfX = massOfX / molarMassOfX;
		} else {
			molesOfX = 0;
		}
	}
	
	if (self.reactant2UnitTypeTag == CBLimitingReagentsQuantityIsMoles) {
		molesOfY = self.reactant2MolesValue;
		molesOfY = [CBCalculator convert:molesOfY fromScale:self.reactant2MolesScale];
		
	} else if (self.reactant2UnitTypeTag == CBLimitingReagentsQuantityIsMass) {
		double massOfY = self.reactant2MassValue;
		massOfY = [CBCalculator convert:massOfY fromScale:self.reactant2MassScale];
				
		if (molarMassOfY != 0) {
			molesOfY = massOfY / molarMassOfY;
		} else {
			molesOfY = 0;
		}
	}

	double massOfProduct;

	NSInteger coefficientOfX = self.reactant1Coefficient;
	NSInteger coefficientOfY = self.reactant2Coefficient;
	NSInteger coefficientOfProduct = self.productCoefficient;

	double molesOfProduct;
	
	double usedMolesOfX;
	double usedMolesOfY;
	double usedMolesOfLimitingReagent;
	double usedMolesOfExcessReagent;
	
	double usedMassOfLimitingReagent;
	double usedMassOfExcessReagent;
	
	double scaledUsedMolesOfLimitingReagent;
	double scaledUsedMolesOfExcessReagent;
	double scaledUsedMassOfLimitingReagent;
	double scaledUsedMassOfExcessReagent;
	
	double portionOfX;
	double portionOfY;
	
	//double remainingLimitedReagentMoles;
	//double remainingLimitedReagentMass;
	double remainingExcessReagentMoles;
	double remainingExcessReagentMass;

	//double scaledRemainingMolesOfLimitingReagent;
	//double scaledRemainingMassOfLimitingReagent;
	double scaledRemainingMolesOfExcessReagent;
	double scaledRemainingMassOfExcessReagent;

	NSInteger coefficientOfLimitingReagent;

	
	if (coefficientOfX == 0) coefficientOfX = 1;
	if (coefficientOfY == 0) coefficientOfY = 1;
	
	portionOfX = molesOfX / (double)coefficientOfX;
	portionOfY = molesOfY / (double)coefficientOfY;
	
	//BOOL limitingReagentIsX;
	//BOOL limitingReagentIsY;
	
	NSString *limitingReagentLabel;
	NSString *excessReagentLabel;
	
	if (portionOfX == portionOfY) {
		/* both reagents are equal */
		usedMolesOfX = molesOfX;	// = potentialReactingFractionOfY
		usedMolesOfY = molesOfY;	// = potentialReactingFractionOfX
		
		usedMolesOfLimitingReagent = usedMolesOfX;
		usedMolesOfExcessReagent = usedMolesOfY;
		
		usedMassOfLimitingReagent = usedMolesOfLimitingReagent * molarMassOfX;
		usedMassOfExcessReagent = usedMolesOfExcessReagent * molarMassOfY;

		//remainingLimitedReagentMoles = 0;	// [TODO] is this correct?
		remainingExcessReagentMoles = 0;	// [TODO] is this correct?
		
		//remainingLimitedReagentMass = 0;
		remainingExcessReagentMass = 0;

		coefficientOfLimitingReagent = 1;

		limitingReagentLabel = @"None";	// [TODO] localize
		excessReagentLabel = @"None";	// [TODO] localize

	} else if (portionOfX < portionOfY) {
		/* limiting reagent is x */
		usedMolesOfX = molesOfX;
		usedMolesOfY = portionOfX * (double)coefficientOfY;
		
		usedMolesOfLimitingReagent = usedMolesOfX;
		usedMolesOfExcessReagent = usedMolesOfY;
		
		usedMassOfLimitingReagent = usedMolesOfLimitingReagent * molarMassOfX;
		usedMassOfExcessReagent = usedMolesOfExcessReagent * molarMassOfY;

		//remainingLimitedReagentMoles = molesOfX - usedMolesOfLimitingReagent;
		remainingExcessReagentMoles = molesOfY - usedMolesOfExcessReagent;

		//remainingLimitedReagentMass = remainingLimitedReagentMoles * molarMassOfX;
		remainingExcessReagentMass = remainingExcessReagentMoles * molarMassOfY;

		coefficientOfLimitingReagent = coefficientOfX;

		limitingReagentLabel = self.reactant1Name;
		excessReagentLabel = self.reactant2Name;
	
	} else if (portionOfX > portionOfY) {
		/* limiting reagent is y */
		usedMolesOfX = portionOfY * (double)coefficientOfX;
		usedMolesOfY = molesOfY;
		
		usedMolesOfLimitingReagent = usedMolesOfY;
		usedMolesOfExcessReagent = usedMolesOfX;
		
		usedMassOfLimitingReagent = usedMolesOfLimitingReagent * molarMassOfY;
		usedMassOfExcessReagent = usedMolesOfExcessReagent * molarMassOfX;
		
		//remainingLimitedReagentMoles = molesOfY - usedMolesOfLimitingReagent;
		remainingExcessReagentMoles = molesOfX - usedMolesOfExcessReagent;
		
		//remainingLimitedReagentMass = remainingLimitedReagentMoles * molarMassOfY;
		remainingExcessReagentMass = remainingExcessReagentMoles * molarMassOfX;

		coefficientOfLimitingReagent = coefficientOfY;

		limitingReagentLabel = self.reactant2Name;
		excessReagentLabel = self.reactant1Name;
	}
	
	// the scaled moles of the limiting and excess reagents
	scaledUsedMolesOfLimitingReagent = [CBCalculator convert:usedMolesOfLimitingReagent toScale:self.limitingReagentMolesUsedScale];
	scaledUsedMolesOfExcessReagent = [CBCalculator convert:usedMolesOfExcessReagent toScale:self.excessReagentMolesUsedScale];
		
	self.limitingReagentMolesUsedValue = scaledUsedMolesOfLimitingReagent;
	self.excessReagentMolesUsedValue = scaledUsedMolesOfExcessReagent;

	// get the scaled masses of the limiting and excess reagents
	scaledUsedMassOfLimitingReagent = [CBCalculator convert:usedMassOfLimitingReagent toScale:self.limitingReagentMassUsedScale];
	scaledUsedMassOfExcessReagent = [CBCalculator convert:usedMassOfExcessReagent toScale:self.excessReagentMassUsedScale];

	self.limitingReagentMassUsedValue = scaledUsedMassOfLimitingReagent;
	self.excessReagentMassUsedValue = scaledUsedMassOfExcessReagent;
	
	/* remaining moles of limiting and excess reagents */
	//scaledRemainingMolesOfLimitingReagent = [CBCalculator convert:remainingLimitedReagentMoles toScaleMenu:limitingReagentMolesLeftScaleMenu];
	//scaledRemainingMassOfLimitingReagent = [CBCalculator convert:remainingLimitedReagentMass toScaleMenu:limitingReagentMassLeftScaleMenu];

	scaledRemainingMolesOfExcessReagent = [CBCalculator convert:remainingExcessReagentMoles toScale:self.excessReagentMolesLeftScale];
	scaledRemainingMassOfExcessReagent = [CBCalculator convert:remainingExcessReagentMass toScale:self.excessReagentMassLeftScale];

	//[limitingReagentRemainingMolesTextField setDoubleValue:scaledRemainingMolesOfLimitingReagent];
	//[limitingReagentRemainingMassTextField setDoubleValue:scaledRemainingMassOfLimitingReagent];

	self.excessReagentMolesLeftValue = scaledRemainingMolesOfExcessReagent;
	self.excessReagentMassLeftValue = scaledRemainingMassOfExcessReagent;
	
	//double potentialReactingFractionOfX = molesOfX * coefficientOfY / coefficientOfX;	// portionOfX * coefficientOfY
	//double potentialReactingFractionOfY = molesOfY * coefficientOfX / coefficientOfY;	// portionOfY * coefficientOfX

	// calculate the moles of product; [TODO] can we simply add another molesOfProduct, with its own coefficient?
	molesOfProduct = usedMolesOfLimitingReagent * (double)coefficientOfProduct / (double)coefficientOfLimitingReagent;	/*(usedMolesOfX + usedMolesOfY)/2;*/
	
	// get the scaled moles of product
	molesOfProduct = [CBCalculator convert:molesOfProduct toScale:self.productMolesScale];
	self.productMolesValue = molesOfProduct;
	
	// get the scaled mass of product
	massOfProduct = molesOfProduct * molarMassOfProduct;
	massOfProduct = [CBCalculator convert:massOfProduct toScale:self.productMassScale];
	self.productMassValue = massOfProduct;
	
	// fill in labels
	self.limitingReagentName = limitingReagentLabel;
	self.excessReagentName = excessReagentLabel;
}

/*
mol2x = mx/mmx;
mol2y = my/mmy;

//rx = mol2x * (cy/cx);
//ry = mol2y * (cx/cy);

//tx = (mol2x < ry);	// test if Reagent 1 is the limiting reagent
//ty = (mol2y < rx);	// test if Reagent 2 is the limiting reagent

//-> tx = (mol2x < mol2y * cx/cy)
//-> ty = (mol2y < mol2x * cy/cx)

//t1 = (mol2x * cy < mol2y * cx)
//t2 = (mol2y * cx < mol2x * cy)

//if mol2x * cy < mol2y * cx
//    mol1x = mol2x
//    mol1y = mol2x * cy/cx

//if mol2y * cx < mol2x * cy
//    mol1x = mol2y * cx/cy
//    mol1y = mol2y    
            
mol1x = (mol2x * cy < mol2y * cx) ? mol2x : mol2y * cx/cy;
mol1y = (mol2y * cx < mol2x * cy) ? mol2x * cy/cx : mol2y;


//mol1x = tx * mol2x + ty * ry;
//mol1y = ty * mol2y + tx * rx;

mol1z = mol1x/cx
mol2z = mol1y/cy

molz = cz * (mol1z + mol2z)/2;
*/

@end

/*@interface CBLRQuantityTypeValueTransformer : NSValueTransformer {
}

@end

@implementation CBLRQuantityTypeValueTransformer

+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
    return (value == nil) ? nil : NSStringFromClass([value class]);
}

@end*/
