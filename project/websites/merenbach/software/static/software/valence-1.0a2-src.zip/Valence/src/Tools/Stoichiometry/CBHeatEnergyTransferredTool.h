#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBHeatEnergyTransferredTool : CBToolViewController
{    
	double m_qTabMValue;
	double m_qTabCValue;
	double m_qTabT1Value;
	double m_qTabT2Value;
	double m_qTabQValue;
	CBMeasurementScale *m_qTabMScale;
	CBMeasurementScale *m_qTabCScale;
	CBMeasurementScale *m_qTabT1Scale;
	CBMeasurementScale *m_qTabT2Scale;
	CBMeasurementScale *m_qTabQScale;
	NSString *m_qTabEquilibriumString;

	double m_mTabMValue;
	double m_mTabCValue;
	double m_mTabT1Value;
	double m_mTabT2Value;
	double m_mTabQValue;
	CBMeasurementScale *m_mTabMScale;
	CBMeasurementScale *m_mTabCScale;
	CBMeasurementScale *m_mTabT1Scale;
	CBMeasurementScale *m_mTabT2Scale;
	CBMeasurementScale *m_mTabQScale;
	NSString *m_mTabEquilibriumString;

	double m_cTabMValue;
	double m_cTabCValue;
	double m_cTabT1Value;
	double m_cTabT2Value;
	double m_cTabQValue;
	CBMeasurementScale *m_cTabMScale;
	CBMeasurementScale *m_cTabCScale;
	CBMeasurementScale *m_cTabT1Scale;
	CBMeasurementScale *m_cTabT2Scale;
	CBMeasurementScale *m_cTabQScale;
	NSString *m_cTabEquilibriumString;
	
	double m_tTabMValue;
	double m_tTabCValue;
	double m_tTabTValue;
	double m_tTabQValue;
	CBMeasurementScale *m_tTabMScale;
	CBMeasurementScale *m_tTabCScale;
	CBMeasurementScale *m_tTabTScale;
	CBMeasurementScale *m_tTabQScale;
	NSString *m_tTabEquilibriumString;
	
	//NSAttributedString *m_tInitialString;
	//NSAttributedString *m_FinalString;
}

@property (assign, readwrite) double qTabMValue;
@property (assign, readwrite) double qTabCValue;
@property (assign, readwrite) double qTabT1Value;
@property (assign, readwrite) double qTabT2Value;
@property (assign, readwrite) double qTabQValue;
@property (retain, readwrite) CBMeasurementScale *qTabMScale;
@property (retain, readwrite) CBMeasurementScale *qTabCScale;
@property (retain, readwrite) CBMeasurementScale *qTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *qTabT2Scale;
@property (retain, readwrite) CBMeasurementScale *qTabQScale;
@property (copy, readwrite) NSString *qTabEquilibriumString;

@property (assign, readwrite) double mTabMValue;
@property (assign, readwrite) double mTabCValue;
@property (assign, readwrite) double mTabT1Value;
@property (assign, readwrite) double mTabT2Value;
@property (assign, readwrite) double mTabQValue;
@property (retain, readwrite) CBMeasurementScale *mTabMScale;
@property (retain, readwrite) CBMeasurementScale *mTabCScale;
@property (retain, readwrite) CBMeasurementScale *mTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *mTabT2Scale;
@property (retain, readwrite) CBMeasurementScale *mTabQScale;
@property (copy, readwrite) NSString *mTabEquilibriumString;

@property (assign, readwrite) double cTabMValue;
@property (assign, readwrite) double cTabCValue;
@property (assign, readwrite) double cTabT1Value;
@property (assign, readwrite) double cTabT2Value;
@property (assign, readwrite) double cTabQValue;
@property (retain, readwrite) CBMeasurementScale *cTabMScale;
@property (retain, readwrite) CBMeasurementScale *cTabCScale;
@property (retain, readwrite) CBMeasurementScale *cTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *cTabT2Scale;
@property (retain, readwrite) CBMeasurementScale *cTabQScale;
@property (copy, readwrite) NSString *cTabEquilibriumString;

@property (assign, readwrite) double tTabMValue;
@property (assign, readwrite) double tTabCValue;
@property (assign, readwrite) double tTabTValue;
@property (assign, readwrite) double tTabQValue;
@property (retain, readwrite) CBMeasurementScale *tTabMScale;
@property (retain, readwrite) CBMeasurementScale *tTabCScale;
@property (retain, readwrite) CBMeasurementScale *tTabTScale;
@property (retain, readwrite) CBMeasurementScale *tTabQScale;
@property (copy, readwrite) NSString *tTabEquilibriumString;

//@property (copy, readonly) NSAttributedString *tInitialString;
//@property (copy, readonly) NSAttributedString *tFinalString;

- (IBAction)calculateQ:(id)sender;
- (IBAction)calculateM:(id)sender;
- (IBAction)calculateC:(id)sender;
- (IBAction)calculateT:(id)sender;

- (NSString *)equilibriumStringForDeltaT:(double)deltat;

@end
