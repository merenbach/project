//
//  CBPeriodicTableButtonCell.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 03/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableButtonCell.h"
#import "CBPeriodicTableMatrix.h"
#import "CBPeriodicTableElement.h"

static CGFloat CBPeriodicTableFamilyFontSize = 11.0;
static CGFloat CBPeriodicTableSymbolFontSize = 11.0;
static CGFloat CBPeriodicTableNumberFontSize = 9.0;

const CGFloat CBPTElementCellAlpha = 0.25;
const CGFloat CBPTDisabledElementCellAlphaPercentage = 0.25;

const CGFloat CBPeriodicTableFocusLineWidth = 4.0;
const CGFloat CBPeriodicTableFocusInset = 2.0;

@implementation CBPeriodicTableButtonCell

@synthesize shouldDrawFocus = m_shouldDrawFocus;
@synthesize isGroupCell = m_isGroupCell;
@synthesize isPeriodCell = m_isPeriodCell;

- (id)initTextCell:(NSString *)aString {
	self = [super initTextCell:aString];
	if (self != nil) {
		//[self setBezelStyle:NSShadowlessSquareBezelStyle];
		[self setBezelStyle:NSSmallSquareBezelStyle];
		[self setButtonType:NSMomentaryPushInButton];
		[self setTag:0];
		[self setImagePosition:NSNoImage];
		[self setEnabled:YES];	// [TODO] should this be in button's own init method?
		[self setState:NSOffState];
		[self setShouldDrawFocus:NO];
		[self setBordered:YES];
		
		self.backgroundColor = [NSColor grayColor];
		m_shouldDrawFocus = NO;
		
		m_isGroupCell = NO;
		m_isPeriodCell = NO;
	}
	return self;
}

+ (CGFloat)disabledCellAlphaComponent {
	return CBPTDisabledElementCellAlphaPercentage;
}

+ (CGFloat)defaultBackgroundAlphaValue {
	return CBPTElementCellAlpha;
}


/*- (void)activateNormalCellProfile {
	[self setEnabled:YES];
	[self setShouldDrawFocus:NO];
}

- (void)activateFocusedCellProfile {
	[self setEnabled:YES];
	[self setShouldDrawFocus:YES];
}

- (void)activateExcludedCellProfile {
	[self setEnabled:NO];
	[self setShouldDrawFocus:NO];
}*/


// set any paragraph attributes for the button cells here
+ (NSParagraphStyle *)cellParagraphStyle {
	NSMutableParagraphStyle *newParagraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
	[newParagraphStyle setAlignment:NSCenterTextAlignment];
	return [newParagraphStyle autorelease];
}

+ (NSDictionary *)symbolAttributes {
	return [NSDictionary dictionaryWithObjectsAndKeys:
		[NSFont systemFontOfSize:CBPeriodicTableSymbolFontSize], NSFontAttributeName,
		[NSColor controlTextColor], NSForegroundColorAttributeName,
		[self cellParagraphStyle], NSParagraphStyleAttributeName,
		nil];
}

+ (NSDictionary *)numberAttributes {
	return [NSDictionary dictionaryWithObjectsAndKeys:
		[NSFont systemFontOfSize:CBPeriodicTableNumberFontSize], NSFontAttributeName,
		[NSColor darkGrayColor], NSForegroundColorAttributeName,
		[self cellParagraphStyle], NSParagraphStyleAttributeName,
		nil];
}

+ (NSDictionary *)familyAttributes {
	return [NSDictionary dictionaryWithObjectsAndKeys:
		[NSFont boldSystemFontOfSize:CBPeriodicTableFamilyFontSize], NSFontAttributeName,
		[NSColor blackColor], NSForegroundColorAttributeName,
		[self cellParagraphStyle], NSParagraphStyleAttributeName,
		nil];
}

+ (NSDictionary *)periodAttributes {
	return [NSDictionary dictionaryWithObjectsAndKeys:
		[NSFont boldSystemFontOfSize:CBPeriodicTableFamilyFontSize], NSFontAttributeName,
		[NSColor blackColor], NSForegroundColorAttributeName,
		[self cellParagraphStyle], NSParagraphStyleAttributeName,
		nil];
}

/*- (void)dealloc {
    [AM_backgroundColor release];
	AM_backgroundColor = nil;
		    
    [super dealloc];
}*/

/*- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView {
	if (!self.isGroupCell && !self.isPeriodCell) {
		[super drawWithFrame:cellFrame inView:controlView];
	}
}*/

- (void)drawInteriorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView {
	NSRect drawingRect = [self drawingRectForBounds:cellFrame];
	
	if (!self.isGroupCell && !self.isPeriodCell) {
		[super drawInteriorWithFrame:cellFrame inView:controlView];

		CGFloat alphaComponentToSet = [[self class] defaultBackgroundAlphaValue];
		if (!self.isEnabled) {
			alphaComponentToSet *= [[self class] disabledCellAlphaComponent];
		}
		
		if (self.shouldDrawFocus) {
			[[[NSColor blackColor] colorWithAlphaComponent:alphaComponentToSet] set];
			NSFrameRectWithWidthUsingOperation(drawingRect, CBPeriodicTableFocusLineWidth, NSCompositeSourceOver);
			//[NSBezierPath setDefaultLineWidth:CBPeriodicTableFocusLineWidth];
			//[NSBezierPath strokeRect:NSInsetRect(drawingRect, CBPeriodicTableFocusInset, CBPeriodicTableFocusInset)];
		}
		
		if (!self.isGroupCell && !self.isPeriodCell) {
			NSColor *color = [self.backgroundColor colorWithAlphaComponent:alphaComponentToSet];
			[color setFill];
			NSRectFillUsingOperation(drawingRect, NSCompositeSourceOver);
		} else if (self.isGroupCell) {
			NSColor *color = [[NSColor grayColor] colorWithAlphaComponent:0.25];
			[color setFill];
			NSRectFillUsingOperation(drawingRect, NSCompositeSourceOver);
		} else if (self.isPeriodCell) {
			NSColor *color = [[NSColor grayColor] colorWithAlphaComponent:0.25];
			[color setFill];
			NSRectFillUsingOperation(drawingRect, NSCompositeSourceOver);
		}
	} else {
		NSSize cellSize = drawingRect.size;
		NSPoint cellOrigin = drawingRect.origin;
		NSPoint drawPoint = NSMakePoint(0.5 * cellSize.width + cellOrigin.x, 0.5 * cellSize.height + cellOrigin.y);
		
		NSAttributedString *periodString = [self attributedTitle];
		//periodStringSize = [periodString sizeWithAttributes:attributes];
		NSSize periodStringSize = [periodString size];
		drawPoint.x -= periodStringSize.width / 2.0;
		drawPoint.y -= periodStringSize.height / 2.0;
		
		[periodString drawAtPoint:drawPoint];
	}
}

- (void)takeColorFromColorMap:(NSDictionary *)colorMap {
    /* the color map is a dictionary that contains a "name" key that corresponds to the table type
        (i.e., electron blocks, states of matter, etc.); the color map also contains each type of
        cell that will be highlighted (e.g., "ELMGroupNobleGas") and its corresponding color
    */
    CBPeriodicTableElement *theElement = self.representedObject;
    NSString *colorMapTableTypeTitle = [colorMap objectForKey:@"name"];
	NSString *key = [theElement.tableData objectForKey:colorMapTableTypeTitle];
	self.backgroundColor = [colorMap objectForKey:key];
}

@end
