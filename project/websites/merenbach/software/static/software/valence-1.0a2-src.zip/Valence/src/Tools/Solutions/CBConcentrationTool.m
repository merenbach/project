#import "CBConcentrationTool.h"
#import "CBCalculator.h"

@implementation CBConcentrationTool

@synthesize solventMassTabSoluteMass = m_solventMassTabSoluteMass;
@synthesize solventMassTabSoluteSolubility = m_solventMassTabSoluteSolubility;
@synthesize solventMassTabSolventMass = m_solventMassTabSolventMass;

@synthesize soluteMassTabSoluteMass = m_soluteMassTabSoluteMass;
@synthesize soluteMassTabSoluteSolubility = m_soluteMassTabSoluteSolubility;
@synthesize soluteMassTabSolventMass = m_soluteMassTabSolventMass;

@synthesize soluteSolubilityTabSoluteMass = m_soluteSolubilityTabSoluteMass;
@synthesize soluteSolubilityTabSoluteSolubility = m_soluteSolubilityTabSoluteSolubility;
@synthesize soluteSolubilityTabSolventMass = m_soluteSolubilityTabSolventMass;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_solventMassTabSoluteMass = 0;
		m_solventMassTabSoluteSolubility = 0;
		m_solventMassTabSolventMass = 0;
		
		m_soluteMassTabSoluteMass = 0;
		m_soluteMassTabSoluteSolubility = 0;
		m_soluteMassTabSolventMass = 0;
		
		m_soluteSolubilityTabSoluteMass = 0;
		m_soluteSolubilityTabSoluteSolubility = 0;
		m_soluteSolubilityTabSolventMass = 0;
	}
	return self;
}

- (IBAction)calculateSolventMass:(id)sender
{
    double soluteMass = self.solventMassTabSoluteMass;
    double soluteSolubility = self.solventMassTabSoluteSolubility;
    double solventMass;
    
    solventMass = 100.0f * soluteMass / soluteSolubility;
    
    self.solventMassTabSolventMass = solventMass;
}

- (IBAction)calculateSoluteMass:(id)sender
{
    double soluteMass;
    double soluteSolubility = self.soluteMassTabSoluteSolubility;
    double solventMass = self.soluteMassTabSolventMass;
        
    soluteMass = solventMass / (100.0f * soluteSolubility);
    
    self.soluteMassTabSoluteMass = soluteMass;
}

- (IBAction)calculateSoluteSolubility:(id)sender
{
    double soluteMass = self.soluteSolubilityTabSoluteMass;
    double soluteSolubility;
    double solventMass = self.soluteSolubilityTabSolventMass;
        
    soluteSolubility = 100.0f * soluteMass / solventMass;

    self.soluteSolubilityTabSoluteSolubility = soluteSolubility;
}

@end
