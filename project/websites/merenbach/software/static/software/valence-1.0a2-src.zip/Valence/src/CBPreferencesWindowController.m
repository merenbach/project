//
//  CBPreferencesWindowController.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "CBPreferencesWindowController.h"
#import "CBExpressionFormatter.h"

#import "CBExpressionFormatter.h"
#import "CBMaximumRecentItemsController.h"

NSString *CBPreferencesDecimalPrecisionKey = @"decimalPrecision";
NSString *CBPreferencesNumberOfRecentItemsKey = @"numberOfRecentItems";

NSString *CBPrefsRecentsUpdatedNotificationName = @"CBPrefencesNubmerOfRecentItemsUpdated";



@implementation CBPreferencesWindowController

@synthesize precisionTextField = m_precisionTextField;
@synthesize precisionStepper = m_precisionStepper;
@synthesize decimalPrecision = m_decimalPrecision;
@synthesize decimalPrecisionMin = m_decimalPrecisionMin;
@synthesize decimalPrecisionMax = m_decimalPrecisionMax;

+ (void)initialize {
	NSDictionary *initialValues;
	
	initialValues = [[NSDictionary alloc] initWithObjectsAndKeys:
		//[NSNumber numberWithBool:YES], SUCheckAtStartupKey,	/* check automatically for updates */
		[NSNumber numberWithInt:4], CBPreferencesDecimalPrecisionKey,
		[NSNumber numberWithInt:8], CBPreferencesNumberOfRecentItemsKey,
		nil];
	[[NSUserDefaultsController sharedUserDefaultsController] setInitialValues:initialValues];
	[initialValues release];

	/*initialValues = [[NSDictionary alloc] initWithObjectsAndKeys:
		nil];
	
	[[NSUserDefaults standardUserDefaults] registerDefaults:initialValues];
	[initialValues release];*/
}

- (id)init {
	self = [super initWithWindowNibName:@"Preferences"];
	if (self != nil) {
		m_decimalPrecision = 0;
		m_decimalPrecisionMin = CBExpressionFormatterMinimumLength;
		m_decimalPrecisionMax = CBExpressionFormatterMaximumLength;
	}
	return self;
}

- (void)finalize {
	[self removeObserver:self forKeyPath:@"decimalPrecision"];
	[super finalize];
}

- (void)dealloc {
	[self removeObserver:self forKeyPath:@"decimalPrecision"];
	[super dealloc];	
}


- (void)windowDidLoad {
	[self.window setDelegate:self];   // see -windowWillClose: at end of file for more on this
	[self loadValuesFromDefaults];
	
	[self addObserver:self forKeyPath:@"decimalPrecision" options:0 context:NULL];
}

- (void)loadValuesFromDefaults {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

	self.decimalPrecision = [userDefaults integerForKey:@"decimalPrecision"];
	[self modifyDecimalPrecision:nil];
}

- (void)saveValuesToDefaults {
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];

	[userDefaults setInteger:self.decimalPrecision forKey:@"decimalPrecision"];
}

//- (void)awakeFromNib {
	//int precision = [[[[NSUserDefaultsController sharedUserDefaultsController] values] valueForKey:CBPreferencesDecimalPrecisionKey] intValue];
	//[[CBExpressionFormatter sharedInstance] updateFormat:precision];
//}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([keyPath isEqualToString:@"decimalPrecision"]) {
		[self performSelectorOnMainThread:@selector(modifyDecimalPrecision:) withObject:nil waitUntilDone:YES];
	} else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)setNilValueForKey:(NSString *)key {
	if ([key isEqualToString:@"decimalPrecision"]) {
		[self setValue:[NSNumber numberWithInteger:0] forKey:key];
	} else {
		[super setNilValueForKey:key];
	}
}

- (IBAction)modifyDecimalPrecision:(id)sender {
	NSInteger value = self.decimalPrecision;
	if (value < self.decimalPrecisionMin) {
		value = self.decimalPrecisionMin;
		self.decimalPrecision = value;
	}
	if (value > self.decimalPrecisionMax) {
		value = self.decimalPrecisionMax;
		self.decimalPrecision = value;
	}
	
	[self.precisionTextField setIntegerValue:value];	// prevent out-of-bounds values from persisting
	[self.precisionStepper setIntegerValue:value];		// prevent out-of-bounds values from persisting
	
	[self saveValuesToDefaults];


	[[CBExpressionFormatter sharedInstance] updateFormat:value];	// update all the text fields
}

/*- (IBAction)modifyNumberOfRecentItems:(id)sender {
	int value = [sender intValue];
	[recentsTextField setIntValue:value];
	[[CBMaximumRecentItemsController sharedInstance] setMaxNumberOfRecentItems:value];
	[[NSNotificationCenter defaultCenter] postNotificationName:CBPrefsRecentsUpdatedNotificationName object:[NSNumber numberWithInt:value]];
	
	[self saveValuesToDefaults];
}*/


// We do this to catch the case where the user enters a value into one of the text fields but closes the window without hitting enter or tab.

- (void)windowWillClose:(NSNotification *)notification {
	[self saveValuesToDefaults];
	NSWindow *window = [notification object];
	(void)[window makeFirstResponder:window];
}

@end
