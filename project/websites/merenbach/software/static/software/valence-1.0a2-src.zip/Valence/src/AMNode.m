//
//  AMNode.m
//  DiceX
//
//  Created by Andrew Merenbach on 24/11/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import "AMNode.h"


@implementation AMNode

@synthesize title = m_title;
@synthesize children = m_children;
@synthesize representedObject = m_representedObject;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_title = [[NSString alloc] initWithString:@""];
		m_children = [[NSArray alloc] init];
		m_representedObject = nil;
	}
	return self;
}

- (void)dealloc {
	[m_title release];
	m_title = nil;

	[m_children release];
	m_children = nil;

	[m_representedObject release];	
	m_representedObject = nil;	
	
	[super dealloc];
}

- (NSComparisonResult)localizedCompare:(AMNode *)otherNode {
	return [self.title localizedCompare:otherNode.title];
}

@end
