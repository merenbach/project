//
//  CBMaximumRecentItemsController.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 8/4/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBMaximumRecentItemsController.h"

const unsigned CBMaxRecentItemsMinimum = 1;
const unsigned CBMaxRecentItemsMaximum = 12;

static CBMaximumRecentItemsController *sharedInstance = nil;


@implementation CBMaximumRecentItemsController

+ (void)initialize {
	sharedInstance = [[[self class] alloc] init];
}

+ (CBMaximumRecentItemsController *)sharedInstance {
	return sharedInstance;
}

- (id)init {
	if (sharedInstance) {
		[self release];
	} else if (nil != (self = [super init])) {
		sharedInstance = self;
		
		AM_maxNumberOfRecentItems = 1;
	}
	return self;
}

- (void)dealloc {			
	if (sharedInstance != self) {
		[super dealloc];
	}
}

- (unsigned)maxNumberOfRecentItems {
	return AM_maxNumberOfRecentItems;
}

- (void)setMaxNumberOfRecentItems:(unsigned)anInt {	
	if (anInt < CBMaxRecentItemsMinimum) {
		anInt = CBMaxRecentItemsMinimum;
	} else if (anInt > CBMaxRecentItemsMaximum) {
		anInt = CBMaxRecentItemsMaximum;
	}

	AM_maxNumberOfRecentItems = anInt;
}

- (oneway void)release {
	if (sharedInstance != self) {
		[super release];
	}
}

- (id)autorelease {
	id result;

	if (sharedInstance != self) {
		result = [super autorelease];
	} else {
		result = self;
	}
	
	return result;
}

- (id)retain {
	id result;

	if (sharedInstance != self) {
		result = [super retain];
	} else {
		result = self;
	}
	
	return result;
}

@end
