//
//  CBRecentItemsArrayController.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/29/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBRecentItemsArrayController.h"
#import "CBPreferencesWindowController.h"

#import "CBMaximumRecentItemsController.h"


@implementation CBRecentItemsArrayController

- (id)initWithContent:(id)content {
	if (nil != (self = [super initWithContent:content])) {
		AM_maxNumberOfRecentItems = 1;
		
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateMaxNumberOfRecentItems:)
			name:CBPrefsRecentsUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	if (nil != (self = [super initWithCoder:aDecoder])) {
		AM_maxNumberOfRecentItems = 1;
		
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateMaxNumberOfRecentItems:)
			name:CBPrefsRecentsUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (id)init {
	if (nil != (self = [super init])) {
		AM_maxNumberOfRecentItems = 1;
		
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateMaxNumberOfRecentItems:)
			name:CBPrefsRecentsUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self
		name:CBPrefsRecentsUpdatedNotificationName
		object:nil];
		
	[super dealloc];
}

- (void)trimObjects {
	NSArray *objects = [self arrangedObjects];
	
	unsigned count = [objects count];
	unsigned max = [[CBMaximumRecentItemsController sharedInstance] maxNumberOfRecentItems];

	if (count > max) {
		unsigned idx = count - max;
		NSArray *array = [objects subarrayWithRange:NSMakeRange(0, idx)];
		[self removeObjects:array]; 
	}
}

- (void)updateMaxNumberOfRecentItems:(NSNotification *)aNotification {
	[self trimObjects];
}


- (void)addObject:(id)object {
	[super addObject:object];
	[self trimObjects];
}

- (void)addObjects:(NSArray *)objects {
	[super addObjects:objects];
	[self trimObjects];
}

- (unsigned)maxNumberOfRecentItems {
	return AM_maxNumberOfRecentItems;
}

- (void)setMaxNumberOfRecentItems:(unsigned)anInt {
	AM_maxNumberOfRecentItems = anInt;
}

@end
