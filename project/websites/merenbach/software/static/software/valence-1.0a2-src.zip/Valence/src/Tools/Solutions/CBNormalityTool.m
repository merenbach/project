#import "CBNormalityTool.h"
#import "CBCalculator.h"

@implementation CBNormalityTool

@synthesize normalityTabV1Value = m_normalityTabV1Value;
@synthesize normalityTabV2Value = m_normalityTabV2Value;
@synthesize normalityTabN1Value = m_normalityTabN1Value;
@synthesize normalityTabN2Value = m_normalityTabN2Value;
@synthesize volumeTabV1Value = m_volumeTabV1Value;
@synthesize volumeTabV2Value = m_volumeTabV2Value;
@synthesize volumeTabN1Value = m_volumeTabN1Value;
@synthesize volumeTabN2Value = m_volumeTabN2Value;
@synthesize normalityTabV1Scale = m_normalityTabV1Scale;
@synthesize normalityTabV2Scale = m_normalityTabV2Scale;
@synthesize volumeTabV1Scale = m_volumeTabV1Scale;
@synthesize volumeTabV2Scale = m_volumeTabV2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_normalityTabV1Value = 0;
		m_normalityTabV2Value = 0;
		m_normalityTabN1Value = 0;
		m_normalityTabN2Value = 0;
		
		m_volumeTabV1Value = 0;
		m_volumeTabV2Value = 0;
		m_volumeTabN1Value = 0;
		m_volumeTabN2Value = 0;
		
		m_normalityTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_normalityTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV2Scale = [CBMeasurementScale initialVolumeScale];
	}
	return self;
}

- (void)dealloc {
	[m_normalityTabV1Scale release];
	[m_normalityTabV1Scale release];
	[m_volumeTabV1Scale release];
	[m_volumeTabV2Scale release];
	
	m_normalityTabV1Scale = nil;
	m_normalityTabV1Scale = nil;
	m_volumeTabV1Scale = nil;
	m_volumeTabV2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculateNormality:(id)sender
{
    double n1 = self.normalityTabN1Value;
    double n2;
    double v1 = self.normalityTabV1Value;
    double v2 = self.normalityTabV2Value;
    
    v1 = [CBCalculator convert:v1 fromScale:self.normalityTabV1Scale];
    v2 = [CBCalculator convert:v2 fromScale:self.normalityTabV2Scale];

    /* finish up with the calculation itself */
    n2 = n1 * v1 / v2;
    
    self.normalityTabN2Value = n2;
}

- (IBAction)calculateVolume:(id)sender
{
    double n1 = self.volumeTabN1Value;
    double n2 = self.volumeTabN2Value;
    double v1 = self.volumeTabV1Value;
    double v2;
    
    v1 = [CBCalculator convert:v1 fromScale:self.volumeTabV1Scale];
        
    /* finish up with the calculation itself */
    v2 = v1 * n1 / n2;
    v2 = [CBCalculator convert:v2 toScale:self.volumeTabV2Scale];
    
    self.volumeTabV2Value = v2;
}

@end
