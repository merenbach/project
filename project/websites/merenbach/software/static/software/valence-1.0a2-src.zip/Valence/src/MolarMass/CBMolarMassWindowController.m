#import "CBMolarMassWindowController.h"
#import "CBExpressionEvaluator.h"
#import "CBFormulaEvaluator.h"
#import "CBMolarMassCalculation.h"
#import "CBRecentItemsArrayController.h"

#define defaultSavedColumnValue 0
#define defaultSortDescendingValue NO


NSString *CBMolarMassesRecentFormulaeKey = @"molarMassRecentItems";


@implementation CBMolarMassWindowController

@synthesize formulaComboBox = m_formulaComboBox;
@synthesize molarMassField = m_molarMassField;
@synthesize molarSubstanceField = m_molarSubstanceField;
@synthesize isEvaluating = m_isEvaluating;
@synthesize operationQueue = m_operationQueue;
@synthesize formulaOperation = m_formulaOperation;
@synthesize recentFormulae = m_recentFormulae;

- (id)init {
	self = [super initWithWindowNibName:@"MolarMassWindow"];
	if (self != nil) {
		m_isEvaluating = NO;
		m_operationQueue = nil;
		m_formulaOperation = nil;
		m_recentFormulae = [[NSArray alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_recentFormulae release];
	m_recentFormulae = nil;	
	
	[super dealloc];
}

/*- (void)dealloc
{
	//id recents = [recentFormulaeArrayController content];
	//[[[NSUserDefaultsController sharedUserDefaultsController] values] setValue:recents forKey:CBMolarMassesRecentFormulaeKey];
	
	[super dealloc];
}*/

- (void)toggleEvaluation:(id)sender 
{
	// If already running, cancel and exit
	if (self.isEvaluating) {
		[self.formulaOperation removeObserver:self forKeyPath:@"isFinished"];
		[self.operationQueue cancelAllOperations];
		self.operationQueue = nil;
		self.formulaOperation = nil;
		self.isEvaluating = NO;
		return;
	}
	
	// formula stuff
	NSString *formula = [self.formulaComboBox stringValue];
	if (formula == nil || [formula isEqualToString:@""]) {
		NSAlert *alert = [NSAlert alertWithMessageText:@"Parser Error"
										 defaultButton:@"Cancel"
									   alternateButton:nil
										   otherButton:nil
							 informativeTextWithFormat:@"There was a problem parsing the formula.  Please check your input and try again."];
		[alert setAlertStyle:NSInformationalAlertStyle];
		[self performSelectorOnMainThread:@selector(displayAlert:) withObject:alert waitUntilDone:YES];
		return;
	}
	
	// add formula to formulae
	[self appendFormulaToFormulae:formula];
	
	
	// If not running, start up the operation queue
	self.isEvaluating = YES;
	//self.oldResultsArray = self.resultsArray;
	//self.resultsArray = [NSArray array];
	
	// Configure parameters	
	CBMolarMassCalculation *operation = [[CBMolarMassCalculation alloc] init];
	operation.formula = formula;
	
	// check parameter counts	
	self.formulaOperation = operation;
	
	// Add operations to a operation queue
	self.operationQueue = [NSOperationQueue new];
	//[operationQueue setMaxConcurrentOperationCount:numberOfCores];
	[self.operationQueue addOperation:self.formulaOperation];
	
	// Observe the complete expression to see when it is done
	[self.formulaOperation addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
	if ([keyPath isEqualToString:@"isFinished"] && object == self.formulaOperation) {
		self.isEvaluating = NO;
		[self.formulaOperation removeObserver:self forKeyPath:@"isFinished"];
		[self performSelectorOnMainThread:@selector(finishEvaluation:)
							   withObject:object
							waitUntilDone:YES];
		
		self.operationQueue = nil;
		self.formulaOperation = nil;
	} else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)finishEvaluation:(CBMolarMassCalculation *)calculation {
	[self.molarMassField setDoubleValue:calculation.gramsPerMole];
	[self.molarSubstanceField setDoubleValue:calculation.molesPerGram];
}

- (void)displayAlert:(NSAlert *)alert {
	//NSBeep();

	[alert beginSheetModalForWindow:self.window
					  modalDelegate:nil
					 didEndSelector:NULL
						contextInfo:NULL];
}

- (void)appendFormulaToFormulae:(NSString *)formula {
	NSMutableArray *newFormulae = [[self.recentFormulae mutableCopy] autorelease];
	if ([newFormulae containsObject:formula]) {
		[newFormulae removeObject:formula];
	}
	[newFormulae addObject:formula];
	self.recentFormulae = newFormulae;	
}


/*- (void)copyRows:(id)sender
{
	NSNumber *theRow;	// theValue
	id theRecord;
	NSString *theString;
	NSMutableArray *theArray = [NSMutableArray array];

	NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];

	[pasteboard declareTypes:[NSArray arrayWithObject:NSStringPboardType] owner:nil];
	
	NSEnumerator *e = [nil selectedRowEnumerator];
	
	int n;
	NSArray *columns = [nil tableColumns];
	
	NSMutableArray *columnArray = [NSMutableArray array];
	for (n = 0; n < [columns count]; n++) {
		[columnArray addObject:[[columns objectAtIndex:n] identifier]];
	}
	
	while ( theRow = [e nextObject] ) {
		theRecord = [activeSet objectAtIndex:(sortDescending ? ([nil numberOfRows] - [theRow intValue] - 1) : [theRow intValue])];
		
		theString = [[theRecord objectsForKeys:columnArray notFoundMarker:nil] componentsJoinedByString:@"\t"];
			
		//theString = [[theRecord objectsForKeys:[NSArray arrayWithObjects:@"atomicNumber",@"atomicSymbol",@"elementalName",@"molarMass",nil] notFoundMarker:nil] componentsJoinedByString:@"\t"];
		[theArray addObject:theString];
	}

	[pasteboard setString:[theArray componentsJoinedByString:@"\n"] forType:NSStringPboardType];
	
//    NSString *contents = // from somewhere
//    NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
//    [pasteboard declareTypes:[NSArray arrayWithObject:NSStringPboardType] owner:nil];
//    [pasteboard setString:contents forType:NSStringPboardType];
	
//    [myPB setString:@"hello" forType:NSStringPboardType];
}*/

/*- (void)awakeFromNib
{
	[[self window] setExcludedFromWindowsMenu:YES];
}*/

@end
