//
//  CBEquilibriumToolEntry.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBEquilibriumToolEntry.h"


#define CB_EQUILIBRIUM_TOOL_ENTRY_DEFAULT_NAME @"Untitled"

@implementation CBEquilibriumToolEntry

@synthesize substanceName = m_substanceName;
@synthesize concentrationValue = m_concentrationValue;
@synthesize coefficientValue = m_coefficientValue;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_substanceName = [[NSString alloc] initWithString:CB_EQUILIBRIUM_TOOL_ENTRY_DEFAULT_NAME];
		m_concentrationValue = 0;
		m_coefficientValue = 0;
	}
	return self;
}


- (void)dealloc {
	[m_substanceName release];
	m_substanceName = nil;
	
	[super dealloc];
}

+ (NSArray *)copyKeys {
	static NSArray *array = nil;
	if (!array) {
		array = [[NSArray alloc] initWithObjects:
			@"substanceName",
			@"concentrationValue",
			@"coefficientValue",
			nil];
	}
	return array;
}

- (id)copyWithZone:(NSZone *)zone {
	CBEquilibriumToolEntry *copy = [[[self class] allocWithZone:zone] init];
	
	copy.substanceName = self.substanceName;
	copy.concentrationValue = self.concentrationValue;
	copy.coefficientValue = self.coefficientValue;
	
	return copy;
}

- (NSDictionary *)dictionaryRepresentation {
	return [self dictionaryWithValuesForKeys:[[self class] copyKeys]];
}

@end