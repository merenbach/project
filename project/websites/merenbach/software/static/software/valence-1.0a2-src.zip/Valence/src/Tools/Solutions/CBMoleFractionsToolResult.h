//
//  CBMoleFractionsToolResult.h
//  Valence
//
//  Created by Andrew Merenbach on 4/6/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CBMoleFractionsToolRecord.h"


@interface CBMoleFractionsToolResult : CBMoleFractionsToolRecord <NSCopying> {
	double m_fractionalPart;
}

@property (assign, readwrite) double fractionalPart;

@end
