//
//  CBPeriodicTableLegendRecord.h
//  Valence
//
//  Created by Andrew Merenbach on 4/11/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBPeriodicTableLegendRecord : NSObject {
	NSColor *m_color;
	NSString *m_title;
}

@property (copy, readwrite) NSColor *color;
@property (copy, readwrite) NSString *title;
@property (readonly) NSString *localizedTitle;

- (id)init;
+ (id)record;
- (void)dealloc;

@end
