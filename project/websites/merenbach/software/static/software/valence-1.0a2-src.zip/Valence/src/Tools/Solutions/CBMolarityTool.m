#import "CBMolarityTool.h"
#import "CBCalculator.h"
#import "CBScalePopUpButton.h"


@implementation CBMolarityTool

@synthesize molarityTabQuantityValue = m_molarityTabQuantityValue;
@synthesize molarityTabMolarMassValue = m_molarityTabMolarMassValue;
@synthesize molarityTabVolumeValue = m_molarityTabVolumeValue;
@synthesize molarityTabMolarityValue = m_molarityTabMolarityValue;

@synthesize volumeTabQuantityValue = m_volumeTabQuantityValue;
@synthesize volumeTabMolarMassValue = m_volumeTabMolarMassValue;
@synthesize volumeTabVolumeValue = m_volumeTabVolumeValue;
@synthesize volumeTabMolarityValue = m_volumeTabMolarityValue;

@synthesize quantityTabQuantityValue = m_quantityTabQuantityValue;
@synthesize quantityTabMolarMassValue = m_quantityTabMolarMassValue;
@synthesize quantityTabVolumeValue = m_quantityTabVolumeValue;
@synthesize quantityTabMolarityValue = m_quantityTabMolarityValue;

@synthesize molarityTabQuantityScale = m_molarityTabQuantityScale;
@synthesize molarityTabVolumeScale = m_molarityTabVolumeScale;
@synthesize volumeTabQuantityScale = m_volumeTabQuantityScale;
@synthesize volumeTabVolumeScale = m_volumeTabVolumeScale;
@synthesize quantityTabQuantityScale = m_quantityTabQuantityScale;
@synthesize quantityTabVolumeScale = m_quantityTabVolumeScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_molarityTabQuantityValue = 0;
		m_molarityTabMolarMassValue = 0;
		m_molarityTabVolumeValue = 0;
		m_molarityTabMolarityValue = 0;

		m_volumeTabQuantityValue = 0;
		m_volumeTabMolarMassValue = 0;
		m_volumeTabVolumeValue = 0;
		m_volumeTabMolarityValue = 0;

		m_quantityTabQuantityValue = 0;
		m_quantityTabMolarMassValue = 0;
		m_quantityTabVolumeValue = 0;
		m_quantityTabMolarityValue = 0;
		
		m_molarityTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_molarityTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_volumeTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		m_quantityTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_quantityTabVolumeScale = [CBMeasurementScale initialVolumeScale];
	}
	return self;
}

- (void)dealloc {
	[m_molarityTabQuantityScale release];
	[m_molarityTabVolumeScale release];
	[m_volumeTabQuantityScale release];
	[m_volumeTabVolumeScale release];
	[m_quantityTabQuantityScale release];
	[m_quantityTabVolumeScale release];
	
	m_molarityTabQuantityScale = nil;
	m_molarityTabVolumeScale = nil;
	m_volumeTabQuantityScale = nil;
	m_volumeTabVolumeScale = nil;
	m_quantityTabQuantityScale = nil;
	m_quantityTabVolumeScale = nil;
	
	[super dealloc];
}

- (IBAction)calculateSolutionMolarity:(id)sender
{
	double q = self.molarityTabQuantityValue;
	double mm = self.molarityTabMolarMassValue;
	double v = self.molarityTabVolumeValue;
	double molarity = self.molarityTabMolarityValue;

	q = [CBCalculator convert:q fromScale:self.molarityTabQuantityScale molarMass:mm];
	v = [CBCalculator convert:v fromScale:self.molarityTabVolumeScale];
	
	// finish up with the calculation itself
	molarity = q / v;
	
	self.molarityTabMolarityValue = molarity;
}

- (IBAction)calculateSolutionVolume:(id)sender
{
	double q = self.volumeTabQuantityValue;
	double mm = self.volumeTabMolarMassValue;
	double v;
	double molarity = self.volumeTabMolarityValue;
	
	q = [CBCalculator convert:q fromScale:self.volumeTabQuantityScale molarMass:mm];
			
	// finish up with the calculation itself
	v = q / molarity;
	v = [CBCalculator convert:v toScale:self.volumeTabVolumeScale];

	self.volumeTabVolumeValue = v;
}

- (IBAction)calculateSoluteQuantity:(id)sender
{
	double q;
	double mm = self.quantityTabMolarMassValue;
	double v = self.quantityTabVolumeValue;
	double molarity = self.quantityTabMolarityValue;

	v = [CBCalculator convert:v fromScale:self.quantityTabVolumeScale];

	// finish up with the calculation itself
	q = v * molarity;
	q = [CBCalculator convert:q toScale:self.quantityTabQuantityScale molarMass:mm];
	
	self.quantityTabQuantityValue = q;
}

@end
