#import "CBCharlesLawTool.h"
#import "CBCalculator.h"

@implementation CBCharlesLawTool

@synthesize volumeTabV1Value = m_volumeTabV1Value;
@synthesize volumeTabV2Value = m_volumeTabV2Value;
@synthesize volumeTabT1Value = m_volumeTabT1Value;
@synthesize volumeTabT2Value = m_volumeTabT2Value;

@synthesize temperatureTabV1Value = m_temperatureTabV1Value;
@synthesize temperatureTabV2Value = m_temperatureTabV2Value;
@synthesize temperatureTabT1Value = m_temperatureTabT1Value;
@synthesize temperatureTabT2Value = m_temperatureTabT2Value;

@synthesize volumeTabV1Scale = m_volumeTabV1Scale;
@synthesize volumeTabV2Scale = m_volumeTabV2Scale;
@synthesize volumeTabT1Scale = m_volumeTabT1Scale;
@synthesize volumeTabT2Scale = m_volumeTabT2Scale;

@synthesize temperatureTabV1Scale = m_temperatureTabV1Scale;
@synthesize temperatureTabV2Scale = m_temperatureTabV2Scale;
@synthesize temperatureTabT1Scale = m_temperatureTabT1Scale;
@synthesize temperatureTabT2Scale = m_temperatureTabT2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_volumeTabV1Value = 0;
		m_volumeTabV2Value = 0;
		m_volumeTabT1Value = 0;
		m_volumeTabT2Value = 0;
		
		m_temperatureTabV1Value = 0;
		m_temperatureTabV2Value = 0;
		m_temperatureTabT1Value = 0;
		m_temperatureTabT2Value = 0;
		
		m_volumeTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_volumeTabT2Scale = [CBMeasurementScale initialTemperatureScale];
		
		m_temperatureTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_temperatureTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_temperatureTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_temperatureTabT2Scale = [CBMeasurementScale initialTemperatureScale];		
	}
	return self;
}

- (void)dealloc {	
	[m_volumeTabV1Scale release];
	[m_volumeTabV2Scale release];
	[m_volumeTabT1Scale release];
	[m_volumeTabT2Scale release];
	
	m_volumeTabV1Scale = nil;
	m_volumeTabV2Scale = nil;
	m_volumeTabT1Scale = nil;
	m_volumeTabT2Scale = nil;
	
	[m_temperatureTabV1Scale release];
	[m_temperatureTabV2Scale release];
	[m_temperatureTabT1Scale release];
	[m_temperatureTabT2Scale release];
	
	m_temperatureTabV1Scale = nil;
	m_temperatureTabV2Scale = nil;
	m_temperatureTabT1Scale = nil;
	m_temperatureTabT2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculateVolume:(id)sender
{
    double v1 = self.volumeTabV1Value;
    double v2;
    double t1 = self.volumeTabT1Value;
    double t2 = self.volumeTabT2Value;

    v1 = [CBCalculator convert:v1 fromScale:self.volumeTabV1Scale];
    t1 = [CBCalculator convert:t1 fromScale:self.volumeTabT1Scale];
    t2 = [CBCalculator convert:t2 fromScale:self.volumeTabT2Scale];
        
    /* finish up with the calculation itself */
    v2 = v1 * t2 / t1;
    v2 = [CBCalculator convert:v2 toScale:self.volumeTabV2Scale];
    
    self.volumeTabV2Value = v2;
}

- (IBAction)calculateTemperature:(id)sender
{
    double v1 = self.temperatureTabV1Value;
    double v2 = self.temperatureTabV2Value;
    double t1 = self.temperatureTabT1Value;
    double t2;
    
    v1 = [CBCalculator convert:v1 fromScale:self.temperatureTabV1Scale];
    t1 = [CBCalculator convert:t1 fromScale:self.temperatureTabT1Scale];
    v2 = [CBCalculator convert:v2 fromScale:self.temperatureTabV2Scale];
        
    /* finish up with the calculation itself */
    t2 = v2 * t1 / v1;
    t2 = [CBCalculator convert:t2 toScale:self.temperatureTabT2Scale];

    self.temperatureTabT2Value = t2;
}

@end
