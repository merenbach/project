#import "CBMassTool.h"
#import "CBCalculator.h"

@implementation CBMassTool

@synthesize fromValue = m_fromValue;
@synthesize toValue = m_toValue;
@synthesize fromScale = m_fromScale;
@synthesize toScale = m_toScale;
@synthesize resultScaleString = m_resultScaleString;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_fromValue = 0;
		m_toValue = 0;
		m_fromScale = [CBMeasurementScale initialMassScale];
		m_toScale = [CBMeasurementScale initialMassScale];
		m_resultScaleString = m_toScale.localizedTitle;
	}
	return self;
}

- (void)dealloc {
	[m_fromScale release];
	m_fromScale = nil;
	
	[m_toScale release];
	m_toScale = nil;
	
	[m_resultScaleString release];
	m_resultScaleString = nil;
	
	[super dealloc];
}

- (IBAction)calculate:(id)sender
{
    double input = self.fromValue;
    double output;
    
    output = [CBCalculator convert:input fromScale:self.fromScale];
    output = [CBCalculator convert:output toScale:self.toScale];
    
    self.toValue = output;
    self.resultScaleString = self.toScale.localizedTitle;
}

@end
