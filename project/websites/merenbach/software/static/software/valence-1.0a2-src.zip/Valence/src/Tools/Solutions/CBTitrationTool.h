#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBTitrationTool : CBToolViewController
{
	/*IBOutlet NSTextField *molarityV1Field;
	IBOutlet NSTextField *molarityV2Field;
	IBOutlet NSTextField *molarityM1Field;
	IBOutlet NSTextField *molarityM2Field;
	
	IBOutlet CBScalePopUpButton *molarityV1Menu;
	IBOutlet CBScalePopUpButton *molarityV2Menu;
	
	IBOutlet NSTextField *volumeV1Field;
	IBOutlet NSTextField *volumeV2Field;
	IBOutlet NSTextField *volumeM1Field;
	IBOutlet NSTextField *volumeM2Field;
	
	IBOutlet CBScalePopUpButton *volumeV1Menu;
	IBOutlet CBScalePopUpButton *volumeV2Menu;*/
	
	double m_molarityTabV1Value;
	double m_molarityTabV2Value;
	double m_molarityTabM1Value;
	double m_molarityTabM2Value;
	
	double m_volumeTabV1Value;
	double m_volumeTabV2Value;
	double m_volumeTabM1Value;
	double m_volumeTabM2Value;
	
	CBMeasurementScale *m_molarityTabV1Scale;
	CBMeasurementScale *m_molarityTabV2Scale;
	CBMeasurementScale *m_volumeTabV1Scale;
	CBMeasurementScale *m_volumeTabV2Scale;	
}

@property (assign, readwrite) double molarityTabV1Value;
@property (assign, readwrite) double molarityTabV2Value;
@property (assign, readwrite) double molarityTabM1Value;
@property (assign, readwrite) double molarityTabM2Value;
@property (assign, readwrite) double volumeTabV1Value;
@property (assign, readwrite) double volumeTabV2Value;
@property (assign, readwrite) double volumeTabM1Value;
@property (assign, readwrite) double volumeTabM2Value;
@property (retain, readwrite) CBMeasurementScale *molarityTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *molarityTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV2Scale;

- (IBAction)calculateMolarity:(id)sender;
- (IBAction)calculateVolume:(id)sender;

@end
