//
//  CBScalePopUpButtonCategories.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/25/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBScalePopUpButtonCategories.h"


@implementation CBHeatPopUpButton
- (NSString *)category { return CBScaleHeatKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForHeat"; }
@end

@implementation CBPressurePopUpButton
- (NSString *)category { return CBScalePressureKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForPressure"; }
@end

@implementation CBTemperaturePopUpButton
- (NSString *)category { return CBScaleTemperatureKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForTemperature"; }
@end

@implementation CBVolumePopUpButton
- (NSString *)category { return CBScaleVolumeKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForVolume"; }
@end

@implementation CBMassPopUpButton
- (NSString *)category { return CBScaleMassKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMass"; }
@end

@implementation CBMolesPopUpButton
- (NSString *)category { return CBScaleMolesKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMoles"; }
@end

@implementation CBMassMolesPopUpButton
- (NSString *)category { return CBScaleMassMolesKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMassMoles"; }
@end

#pragma mark -

@implementation CBHeatPopUpButtonCell
- (NSString *)category { return CBScaleHeatKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForHeat"; }
@end

@implementation CBPressurePopUpButtonCell
- (NSString *)category { return CBScalePressureKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForPressure"; }
@end

@implementation CBTemperaturePopUpButtonCell
- (NSString *)category { return CBScaleTemperatureKey; }
@end

@implementation CBVolumePopUpButtonCell
- (NSString *)category { return CBScaleVolumeKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForVolume"; }
@end

@implementation CBMassPopUpButtonCell
- (NSString *)category { return CBScaleMassKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMass"; }
@end

@implementation CBMolesPopUpButtonCell
- (NSString *)category { return CBScaleMolesKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMoles"; }
@end

@implementation CBMassMolesPopUpButtonCell
- (NSString *)category { return CBScaleMassMolesKey; }
- (NSString *)toolMenuBindingKey { return @"scalesForMassMoles"; }
@end
