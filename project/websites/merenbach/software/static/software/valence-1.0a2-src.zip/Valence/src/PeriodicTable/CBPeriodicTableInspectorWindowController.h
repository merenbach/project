//
//  CBPeriodicTableInspectorWindowController.h
//  Elemental
//
//  Created by Andrew Merenbach on 25/10/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBPeriodicTableInspectorWindowController : NSWindowController {
	NSString *m_elementDescription;
}

@property (copy, readwrite) NSString *elementDescription;

- (id)init;
- (void)dealloc;

@end
