/* Controller */

#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;

@interface CBMolalityTool : CBToolViewController
{    
	/*IBOutlet NSTextField *molalityQuantityField;
	IBOutlet NSTextField *molalityMolarMassField;
	IBOutlet NSTextField *molalityMassField;
	IBOutlet NSTextField *molalityMolalityField;
	
	IBOutlet CBScalePopUpButton *molalityQuantityMenu;
	IBOutlet CBScalePopUpButton *molalityMassMenu;
		
	IBOutlet NSTextField *massQuantityField;
	IBOutlet NSTextField *massMolarMassField;
	IBOutlet NSTextField *massMassField;
	IBOutlet NSTextField *massMolalityField;
	
	IBOutlet CBScalePopUpButton *massQuantityMenu;
	IBOutlet CBScalePopUpButton *massMassMenu;
	
	IBOutlet NSTextField *quantityQuantityField;
	IBOutlet NSTextField *quantityMolarMassField;
	IBOutlet NSTextField *quantityMassField;
	IBOutlet NSTextField *quantityMolalityField;
	
	IBOutlet CBScalePopUpButton *quantityQuantityMenu;
	IBOutlet CBScalePopUpButton *quantityMassMenu;*/
	
	double m_molalityTabQuantityValue;
	double m_molalityTabMolarMassValue;
	double m_molalityTabMassValue;
	double m_molalityTabMolalityValue;
	
	double m_massTabQuantityValue;
	double m_massTabMolarMassValue;
	double m_massTabMassValue;
	double m_massTabMolalityValue;
	
	double m_quantityTabQuantityValue;
	double m_quantityTabMolarMassValue;
	double m_quantityTabMassValue;
	double m_quantityTabMolalityValue;
	
	CBMeasurementScale *m_molalityTabQuantityScale;
	CBMeasurementScale *m_molalityTabMassScale;
	CBMeasurementScale *m_massTabQuantityScale;
	CBMeasurementScale *m_massTabMassScale;
	CBMeasurementScale *m_quantityTabQuantityScale;
	CBMeasurementScale *m_quantityTabMassScale;
}

@property (assign, readwrite) double molalityTabQuantityValue;
@property (assign, readwrite) double molalityTabMolarMassValue;
@property (assign, readwrite) double molalityTabMassValue;
@property (assign, readwrite) double molalityTabMolalityValue;
@property (assign, readwrite) double massTabQuantityValue;
@property (assign, readwrite) double massTabMolarMassValue;
@property (assign, readwrite) double massTabMassValue;
@property (assign, readwrite) double massTabMolalityValue;
@property (assign, readwrite) double quantityTabQuantityValue;
@property (assign, readwrite) double quantityTabMolarMassValue;
@property (assign, readwrite) double quantityTabMassValue;
@property (assign, readwrite) double quantityTabMolalityValue;
@property (retain, readwrite) CBMeasurementScale *molalityTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *molalityTabMassScale;
@property (retain, readwrite) CBMeasurementScale *massTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *massTabMassScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabMassScale;

- (IBAction)calculateSolventMolality:(id)sender;
- (IBAction)calculateSolventMass:(id)sender;
- (IBAction)calculateSoluteQuantity:(id)sender;

@end
