//
//  CBPeriodicTableValueTransformers.m
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 04/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableValueTransformers.h"

/* new, and possibly good */
@implementation ELMArrayLocalizationValueTransformer

@synthesize tableName = m_tableName;

- (id)initWithTableName:(NSString *)name {
	self = [super init];
    if (self) {
		self.tableName = name;
	}
	return self;
}

+ (Class)transformedValueClass { return [NSArray class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSArray *)transformedValue:(id)value {
	return (!value) ? nil : [[NSBundle mainBundle] localizedStringsForKeys:value values:value table:self.tableName];
}

@end

/*@implementation ELMPeriodicTableKeyToNameLocalizer

+ (Class)transformedValueClass { return [NSArray class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSArray *)transformedValue:(id)value {
	return (!value) ? nil : [[NSBundle bundleForClass:[self class]] localizedStringsForKeys:value values:value table:@"PeriodicTable"];
}

@end*/

/*
@implementation ELMLegendColorValueTransformer

- (id)init {
	if (self = [super init]) {
		appleColorList = [[NSColorList colorListNamed:@"Apple"] retain];
		
		NSString *path = [[NSBundle mainBundle] pathForResource:@"PeriodicTableColors" ofType:@"plist"];
		NSDictionary *colorsDictTemp = [[NSDictionary alloc] initWithContentsOfFile:path];
		
			NSMutableDictionary *tmpCol = [[NSMutableDictionary alloc] init];
			
			NSEnumerator *e = [[colorsDictTemp allValues] objectEnumerator];
			id dict;
			
			while (dict = [e nextObject]) {
				[tmpCol setValuesForKeysWithDictionary:dict];
			}
			
			colorsDict = [tmpCol copy];
			
			[tmpCol release];
		
		[colorsDictTemp release];
		
		//colorsDict = [[NSDictionary alloc] initWithContentsOfFile:path];
		
	}
	return self;
}

- (void)dealloc {
	AM_RELEASE(colorsDict);
	AM_RELEASE(appleColorList);

	[super dealloc];
}

+ (Class)transformedValueClass { return [NSColor class]; }
+ (BOOL)allowsReverseTransformation { return YES; }
- (NSColor *)transformedValue:(id)value {
	//NSString *description = [value valueForKey:@"description"];
	return [appleColorList colorWithKey:[colorsDict objectForKey:value]];
}


@end
*/

/*@implementation ELMLegendColorMapValueTransformer

- (id)init {
	if (self = [super init]) {
		NSBundle *bundle = [NSBundle mainBundle];
		NSString *path = [bundle pathForResource:@"PeriodicTableColors" ofType:@"plist"];
		AM_colorMaps = [[NSDictionary allocWithZone:[self zone]] initWithContentsOfFile:path];
	}
	return self;
}

- (void)dealloc {
	AM_RELEASE(AM_colorMaps);

	[super dealloc];
}

+ (Class)transformedValueClass { return [NSColor class]; }
+ (BOOL)allowsReverseTransformation { return YES; }
- (NSColor *)transformedValue:(id)value {
	NSString *description = [value valueForKey:@"description"];
	return [appleColorList colorWithKey:[colorsDict objectForKey:description]];
}

- (NSDictionary *)colorMaps {
	return AM_colorMaps;
}

@end*/



/*@implementation CBPTLocalizedStringTransformer

+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSString *)transformedValue:(id)value {
   //return (value == nil) ? nil : NSStringFromClass([value class]);
	//- (NSString *)localizedStringForKey:(NSString *)key value:(NSString *)value table:(NSString *)tableName
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	//@"No translation"
	NSString *localizedString = [thisBundle localizedStringForKey:value value:value table:@"PeriodicTable"];
	
	return localizedString;
}

@end*/


/*@implementation CBArrayLocalizationTransformer

- (id)initWithTableName:(NSString *)tableName {
	if (self = [super init]) {
		localizationTableName = [tableName copy];	// [tableName retain]?
	}
	return self;
}

- (void)dealloc {
	[localizationTableName release];
	localizationTableName = nil;
	[super dealloc];
}

+ (Class)transformedValueClass { return [NSArray class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSArray *)transformedValue:(id)value {
   //return (value == nil) ? nil : NSStringFromClass([value class]);
	//- (NSString *)localizedStringForKey:(NSString *)key value:(NSString *)value table:(NSString *)tableName
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	//NSString *localizedString = [thisBundle localizedStringForKey:value value:@"No translation" table:localizationTableName];
	
	return [thisBundle localizedStringsForKeys:value values:value table:localizationTableName];
}

@end*/


/*@implementation CBPTColorListLocalizationTransformer

+ (Class)transformedValueClass { return [NSArray class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (NSArray *)transformedValue:(id)value {
   //return (value == nil) ? nil : NSStringFromClass([value class]);
	//- (NSString *)localizedStringForKey:(NSString *)key value:(NSString *)value table:(NSString *)tableName
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	//NSString *localizedString = [thisBundle localizedStringForKey:value value:@"No translation" table:localizationTableName];
	NSArray *allKeys = [value valueForKey:@"allKeys"];
	NSString *name = [value valueForKey:@"name"];
	return [thisBundle localizedStringsForKeys:allKeys values:allKeys table:name];
}

@end*/


@implementation NSBundle (CBPTBundleAdditions)

/* a bit unsafe at the moment; how about some sanity-checks? [TODO] */
- (NSArray *)localizedStringsForKeys:(NSArray *)keys values:(NSArray *)values table:(NSString *)tableName {
	NSMutableArray *localizedStrings = [NSMutableArray array];
	NSEnumerator *keyEnumerator = [keys objectEnumerator];
	NSEnumerator *valueEnumerator = [values objectEnumerator];	// but what if we want no values? just key returns?
	NSString *key, *value;
	while ( (key = [keyEnumerator nextObject]) && (value = [valueEnumerator nextObject]) ) {
		NSString *string = [self localizedStringForKey:key value:value table:tableName];
		[localizedStrings addObject:string];
	}
	return (NSArray *)localizedStrings;
}

@end
