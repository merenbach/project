//
//  ValenceAppDelegate.m
//  Valence
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "ValenceAppDelegate.h"
#import "CBMainWindowController.h"
#import "CBPreferencesWindowController.h";
#import "CBPeriodicTableWindowController.h"
#import "CBMolarMassWindowController.h"


@implementation ValenceAppDelegate

@synthesize mainWindowController = m_mainWindowController;
@synthesize preferencesWindowController = m_preferencesWindowController;
@synthesize periodicTableWindowController = m_periodicTableWindowController;
@synthesize molarMassWindowController = m_molarMassWindowController;


- (id)init {
	self = [super init];
	if (self != nil) {
		m_mainWindowController = [[CBMainWindowController alloc] init];
		m_preferencesWindowController = [[CBPreferencesWindowController alloc] init];
		m_periodicTableWindowController = [[CBPeriodicTableWindowController alloc] init];
		m_molarMassWindowController = [[CBMolarMassWindowController alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_mainWindowController dealloc];
	m_mainWindowController = nil;
	
	[m_preferencesWindowController release];
	m_preferencesWindowController = nil;
	
	[m_periodicTableWindowController release];
	m_periodicTableWindowController = nil;
	
	[m_molarMassWindowController release];
	m_molarMassWindowController = nil;
	
	[super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	(void)self.mainWindowController.window;
	(void)self.preferencesWindowController.window;
	(void)self.periodicTableWindowController.window;
	(void)self.molarMassWindowController.window;
	
	[self.mainWindowController showWindow:nil];
}

@end

@implementation ValenceAppDelegate (WindowMethods)

- (IBAction)showMainWindow:(id)sender {
	[self.mainWindowController showWindow:sender];
}

- (IBAction)showPreferencesWindow:(id)sender {
	[self.preferencesWindowController showWindow:sender];
}

- (IBAction)showPeriodicTable:(id)sender {
	[self.periodicTableWindowController showWindow:sender];
}

- (IBAction)showMolarMassCalculator:(id)sender {
	[self.molarMassWindowController showWindow:sender];
}

@end
