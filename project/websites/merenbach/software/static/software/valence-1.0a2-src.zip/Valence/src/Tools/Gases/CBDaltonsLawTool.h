/* Controller */

#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class AMTableView;
@class AMDragAndDropArrayController;
@class CBScalePopUpButton;
@class CBMeasurementScale;


@interface CBDaltonsLawTool : CBToolViewController
{    
	AMTableView *m_pressureTableView;
	AMDragAndDropArrayController *m_pressureArrayController;
	
	NSArray *m_pressureRecords;
	double m_totalPressureValue;
	CBMeasurementScale *m_totalPressureScale;
}

@property (assign) IBOutlet AMTableView *pressureTableView;
@property (assign) IBOutlet AMDragAndDropArrayController *pressureArrayController;
@property (copy, readwrite) NSArray *pressureRecords;
@property (assign, readwrite) double totalPressureValue;
@property (retain, readwrite) CBMeasurementScale *totalPressureScale;

- (void)awakeFromNib;
- (IBAction)calculate:(id)sender;

@end