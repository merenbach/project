//
//  CBPeriodicTableValueTransformers.h
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 04/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ELMArrayLocalizationValueTransformer : NSValueTransformer {
	NSString *m_tableName;
}

@property (copy, readwrite) NSString *tableName;

- (id)initWithTableName:(NSString *)name;

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSArray *)transformedValue:(id)value;

@end


/*@interface ELMPeriodicTableKeyToNameLocalizer : NSValueTransformer {
}

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSArray *)transformedValue:(id)value;

@end*/


/*@interface ELMLegendColorValueTransformer : NSValueTransformer {
	NSColorList *appleColorList;
	NSDictionary *colorsDict;
}

- (id)init;
- (void)dealloc;
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSColor *)transformedValue:(id)value;

@end

*/
/*@interface ELMLegendColorMapValueTransformer : NSValueTransformer {
}

- (id)init;
- (void)dealloc;

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSColor *)transformedValue:(id)value;

- (NSDictionary *)colorMaps;

@end*/

/*@interface CBPTLocalizedStringTransformer : NSValueTransformer {
}

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSString *)transformedValue:(id)value;

@end*/


/*@interface CBArrayLocalizationTransformer : NSValueTransformer {
	NSString *localizationTableName;
}

- (id)initWithTableName:(NSString *)localizationTableName;
- (void)dealloc;
+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSArray *)transformedValue:(id)value;

@end*/

/*@interface CBPTColorListLocalizationTransformer : NSValueTransformer {
}

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (NSArray *)transformedValue:(id)value;

@end*/


@interface NSBundle (CBPTBundleAdditions)

/* a bit unsafe at the moment; how about some sanity-checks? [TODO] */
- (NSArray *)localizedStringsForKeys:(NSArray *)keys values:(NSArray *)values table:(NSString *)tableName;

@end