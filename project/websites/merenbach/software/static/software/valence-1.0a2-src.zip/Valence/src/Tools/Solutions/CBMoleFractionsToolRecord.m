//
//  CBMoleFractionsToolRecord.m
//  Valence
//
//  Created by Andrew Merenbach on 4/6/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMoleFractionsToolRecord.h"


@implementation CBMoleFractionsToolRecord

@synthesize soluteName = m_soluteName;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_soluteName = [[NSString alloc] initWithString:@"Untitled"];
	}
	return self;
}

+ (id)record {
	return [[[[self class] alloc] init] autorelease];
}

- (void)dealloc {
	[m_soluteName release];
	m_soluteName = nil;
	
	[super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
	CBMoleFractionsToolRecord *copy = [[[self class] allocWithZone:zone] init];
	copy.soluteName = self.soluteName;
	return copy;
}

@end
