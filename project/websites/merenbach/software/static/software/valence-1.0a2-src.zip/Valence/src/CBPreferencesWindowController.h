//
//  CBPreferencesWindowController.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 3/9/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *CBPreferencesDecimalPrecisionKey;
extern NSString *CBPreferencesNumberOfRecentItemsKey;

extern NSString *CBPrefsRecentsUpdatedNotificationName;


@interface CBPreferencesWindowController : NSWindowController {
	NSTextField *m_precisionTextField;
	NSStepper *m_precisionStepper;
	//IBOutlet NSTextField *recentsTextField;
	
	NSInteger m_decimalPrecision;
	NSInteger m_decimalPrecisionMin;
	NSInteger m_decimalPrecisionMax;
}

@property (assign) IBOutlet NSTextField *precisionTextField;
@property (assign) IBOutlet NSStepper *precisionStepper;
@property (assign, readwrite) NSInteger decimalPrecision;
@property (assign, readonly) NSInteger decimalPrecisionMin;
@property (assign, readonly) NSInteger decimalPrecisionMax;

+ (void)initialize;

- (id)init;
- (void)windowDidLoad;
- (void)loadValuesFromDefaults;
- (void)saveValuesToDefaults;	

- (IBAction)modifyDecimalPrecision:(id)sender;
//- (IBAction)modifyNumberOfRecentItems:(id)sender;

@end
