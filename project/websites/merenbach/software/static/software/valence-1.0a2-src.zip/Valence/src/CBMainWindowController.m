//
//  CBMainWindowController.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMainWindowController.h"
#import "CBMainViewController.h"
#import "CBToolsOutlineView.h"
#import "AMNode.h"
#import "CBToolViewController.h"

#import "CBCenteredClipView.h"

#define CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS 100


@implementation CBMainWindowController

@synthesize toolsOutlineView = m_toolsOutlineView;
@synthesize toolsTreeController = m_toolsTreeController;
@synthesize toolInformationTextView = m_toolInformationTextView;

@synthesize toolScrollView = m_toolScrollView;
@synthesize toolsSplitView = m_toolsSplitView;

@synthesize isMainInterfaceLoaded = m_isMainInterfaceLoaded;
@synthesize parentView = m_parentView;

//@synthesize toolSummary = m_toolSummary;

@synthesize currentToolViewController = m_currentToolViewController;
@synthesize mainViewController = m_mainViewController;

- (id)init {
	self = [super initWithWindowNibName:@"MainWindow"];
	if (self != nil) {
		m_isMainInterfaceLoaded	= NO;
		
		//blankView = [[NSView alloc] initWithFrame:NSZeroRect];
		
		//m_toolSummary = [[NSAttributedString alloc] initWithString:@""];
		
		m_currentToolViewController = nil;
		m_mainViewController = [[CBMainViewController alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_mainViewController release];
	m_mainViewController = nil;
	
	//[blankView release];
	//blankView = nil;
	
	//[m_toolSummary release];
	//m_toolSummary = nil;

	[super dealloc];
}

- (void)windowDidLoad {
	//[self.toolsOutlineView setAction:@selector(loadSelectedToolFromOutlineView:)];
	//[self.toolsOutlineView setDoubleAction:@selector(doubleClickedTools:)];
	//[self.toolsOutlineView setTarget:self];
	
	//self.toolsOutlineView.spaceKeySendsDoubleAction = YES;
	//self.toolsOutlineView.enterKeySendsDoubleAction = YES;
	NSClipView *clipView = [[[CBCenteredClipView alloc] init] autorelease];
	[self.toolScrollView setContentView:clipView];
	
	[self showMainView:nil];
	[NSThread detachNewThreadSelector:@selector(loadTools) toTarget:self withObject:nil];
}


- (void)loadTools {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	{
		NSMutableArray *tools = [[NSMutableArray alloc] init];
		NSString *path = [[NSBundle mainBundle] pathForResource:@"Tools" ofType:@"plist"];
		NSArray *toolsData = [[NSArray alloc] initWithContentsOfFile:path];
		
		for (id toolDatum in toolsData) {
			AMNode *categoryNode = [[AMNode alloc] init];
			NSString *categoryTitle = [toolDatum objectForKey:@"title"];
			NSString *localizedCategoryTitle = NSLocalizedStringFromTable(categoryTitle, @"Tools", @"");
			NSArray *children = [toolDatum objectForKey:@"children"];
			
			[categoryNode setTitle:localizedCategoryTitle];
			
			{
				NSMutableArray *nodeChildren = [[NSMutableArray alloc] init];
				for (id child in children) {
					NSString *toolClassString = [child objectForKey:@"class"];
					NSString *toolTitle = [child objectForKey:@"title"];
					NSString *toolNibName = [child objectForKey:@"nibName"];
					
					Class toolClass = NSClassFromString(toolClassString);
					NSString *localizedToolTitle = NSLocalizedStringFromTable(toolTitle, @"Tools", @"");
					
					CBToolViewController *newTool = [[toolClass alloc] initWithNibName:toolNibName];
					[newTool setTitle:localizedToolTitle];
					
					AMNode *newToolNode = [[AMNode alloc] init];
					[newToolNode setRepresentedObject:newTool];
					[newToolNode setTitle:[newTool title]];
					[nodeChildren addObject:newToolNode];
					[newToolNode release];
					[newTool release];
				}
				
				[nodeChildren sortUsingSelector:@selector(localizedCompare:)];
				
				[categoryNode setChildren:nodeChildren];
				[nodeChildren release];
			}
			
			[tools addObject:categoryNode];
			[categoryNode release];
		}
		
		[tools sortUsingSelector:@selector(localizedCompare:)];
		
		// add a home navigation category
		AMNode *navNode = [[AMNode alloc] init];
		[navNode setRepresentedObject:nil];
		[navNode setTitle:NSLocalizedStringFromTable(@"MainCategory", @"Tools", @"MainCategory")];
		
		AMNode *homeNode = [[AMNode alloc] init];
		[homeNode setRepresentedObject:self.mainViewController];
		[homeNode setTitle:NSLocalizedStringFromTable(@"Home", @"Tools", @"Home")];
		
		NSArray *navChildren = [NSArray arrayWithObject:homeNode];
		[navNode setChildren:navChildren];

		
		// insert it
		[tools insertObject:navNode atIndex:0];

		// end home/nav
		
		
		[self performSelectorOnMainThread:@selector(finishLoadingTools:) withObject:tools waitUntilDone:YES];
		
		[toolsData release];
		[tools release];
	}
	
	[pool release];
}

- (void)finishLoadingTools:(NSArray *)tools {
	[self.toolsTreeController setContent:tools];
	
	/*NSEnumerator *categoryEnumerator = [tools objectEnumerator];
	id node;
	
	*while (node = [categoryEnumerator nextObject]) {
		NSMenuItem *categoryMenuItem = [[NSMenuItem alloc] initWithTitle:[node title]
																  action:NULL
														   keyEquivalent:@""];
		
		{
			NSMenu *submenu = [[NSMenu alloc] initWithTitle:[node title]];
			
			NSEnumerator *toolEnumerator = [[node children] objectEnumerator];
			id tool;
			
			while (tool = [toolEnumerator nextObject]) {
				NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:[tool title]
															  action:@selector(loadToolFromMenu:)
													   keyEquivalent:@""];
				[item setRepresentedObject:[tool representedObject]];
				[submenu addItem:item];
				[item release];
			}
			
			[categoryMenuItem setSubmenu:submenu];
			[submenu release];
		}
		
		//[toolsMenu addItem:categoryMenuItem];
		[categoryMenuItem release];
	}*/
	
	
		// expand all the groups
		NSMutableArray *rowArray = [NSMutableArray array];
		
		NSInteger rows = [self.toolsOutlineView numberOfRows];
		for (NSInteger i = 0; i < rows; i++) {
			id item = [self.toolsOutlineView itemAtRow:i];
			if ([self.toolsOutlineView isExpandable:item]) {
				[rowArray addObject:item];
			}
		}
		for (id item in rowArray) {
			[self.toolsOutlineView expandItem:item];
		}
	
	
	
}


- (void)showMainView:(id)sender {
	
	self.isMainInterfaceLoaded = YES;

	NSView *view = [self.mainViewController view];
	
	NSView *oldView = [self.currentToolViewController view];

	[self replaceOldView:oldView withNewView:view];
	CBCenteredClipView *contentView = (CBCenteredClipView *)[self.toolScrollView contentView];
	[contentView centerDocument];
}

- (void)showTool:(CBToolViewController *)tool {
	if (tool != nil) {
		//[self setCurrentDescription:nil];
		
		NSView *oldView = nil;
		
		if (self.isMainInterfaceLoaded == YES) {
			oldView = [self.mainViewController view];
			self.isMainInterfaceLoaded = NO;
		} else {
			oldView = [self.currentToolViewController view];
		}
		
		self.currentToolViewController = tool;
		
		
		NSView *newView = [tool view];
		
		/*[self.window setContentView:blankView];
		[self.window setTitle:localizedProgramName];
		[self.window resizeToSize:[newView frame].size];
		[self.window setTitle:[tool title]];
		[self.window setContentView:newView];*/
		
		[self replaceOldView:oldView withNewView:newView];
		CBCenteredClipView *contentView = (CBCenteredClipView *)[self.toolScrollView contentView];
		[contentView centerDocument];
		//[self setMainInterfaceLoaded:NO];
		
		//NSAttributedString *summary = [tool summary];
		//self.toolSummary = summary;
		//[self setCurrentDescription:summary];
	}
}

- (void)replaceOldView:(NSView *)oldView withNewView:(NSView *)newView {
	NSView *parentView = self.parentView;
	
	NSRect mainRect = [parentView bounds];
	CGFloat w = NSWidth(mainRect);
	CGFloat h = NSHeight(mainRect);
	
	NSRect newRectBounds = [newView bounds];
	CGFloat nW = NSWidth(newRectBounds);
	CGFloat nH = NSHeight(newRectBounds);
	
	// offset the new origin so as to center the new view
	NSPoint newOrigin = NSZeroPoint;
	newOrigin.x = (CGFloat)floorf(w / 2.0 - nW / 2.0);	// avoid half-pixels
	newOrigin.y = (CGFloat)floorf(h / 2.0 - nH / 2.0);	// avoid half-pixels
	
	// this code works for the non-scrollview verson
	/*[oldView removeFromSuperview];
	[newView setFrameOrigin:newOrigin];
	[parentView addSubview:newView];*/
	
	
	/*NSClipView *superview = [oldView superview];
	[oldView removeFromSuperview];
	[newView setFrameOrigin:newOrigin];
	[superview addSubview:newView];*/
	
	[self.toolScrollView setDocumentView:newView];

	/*NSSize tableSize = [self.toolsOutlineView bounds].size;
	NSSize viewSize = [newView bounds].size;
	viewSize.width += tableSize.width;
	[self.window resizeToSize:viewSize];*/
}	

/*- (void)loadToolFromMenu:(id)sender {
	id repObj = [sender representedObject];
	if (repObj != self.mainViewController) {
		[self showTool:repObj];
	} else {
		[self showMainView:sender];
	}
}*/

- (IBAction)loadSelectedToolFromOutlineView:(id)sender {
	NSInteger selectedRow = [self.toolsOutlineView selectedRow];
	if (selectedRow != -1) {
		id rowItem = [self.toolsOutlineView itemAtRow:selectedRow];
		if ([self.toolsOutlineView isExpandable:rowItem]) {
			// do nothing
		} else {
			[self loadSelectedTool:sender];
		}
	}
}

/*- (IBAction)doubleClickedTools:(id)sender {
	int selectedRow = [self.toolsOutlineView selectedRow];
	if (selectedRow != -1) {
		id rowItem = [self.toolsOutlineView itemAtRow:selectedRow];
		if ([self.toolsOutlineView isExpandable:rowItem]) {
			if ([self.toolsOutlineView isItemExpanded:rowItem]) {
				[self.toolsOutlineView collapseItem:rowItem];
			} else {
				[self.toolsOutlineView expandItem:rowItem];
			}
		} else {
			// do nothing
		}
	}
}*/

- (IBAction)loadSelectedTool:(id)sender {
	NSArray *selectedObjects = [self.toolsTreeController selectedObjects];
	id node = [selectedObjects lastObject];
	id repObj = [node representedObject];
	if (repObj != self.mainViewController) {
		[self showTool:repObj];
	} else {
		[self showMainView:sender];
	}
}

- (BOOL)validateToolbarItem:(NSToolbarItem *)theItem {
	BOOL flag = YES;
	
	if ([theItem action] == @selector(showMainView:)) {
		flag = !self.isMainInterfaceLoaded;
	} else if ([theItem action] == @selector(loadSelectedTool:)) {
		// allow loading only of tool entries, and not categories
		unsigned row = [self.toolsOutlineView selectedRow];
		id rowItem = [self.toolsOutlineView itemAtRow:row];
		if (rowItem) {
			flag = (self.isMainInterfaceLoaded && ![self.toolsOutlineView isExpandable:rowItem]);
		} else {
			flag = NO;
		}
	}
	
	return flag;
}

- (BOOL)validateMenuItem:(NSMenuItem *)theItem {
	BOOL flag = YES;
	
	if ([theItem action] == @selector(showMainView:)) {
		flag = !self.isMainInterfaceLoaded;
	} else if ([theItem action] == @selector(loadSelectedTool:)) {
		// allow loading only of tool entries, and not categories
		unsigned row = [self.toolsOutlineView selectedRow];
		id rowItem = [self.toolsOutlineView itemAtRow:row];
		if (rowItem) {
			flag = (self.isMainInterfaceLoaded && ![self.toolsOutlineView isExpandable:rowItem]);
		} else {
			flag = NO;
		}
	}
	
	return flag;
}

@end

@implementation CBMainWindowController (OutlineView)

- (BOOL)outlineView:(NSOutlineView *)outlineView isGroupItem:(id)item {
	AMNode *node = [item representedObject];
	NSUInteger count = [[node children] count];
	return (count > 0);
//	return ([[item children] count] == 0);
}

- (BOOL)outlineView:(NSOutlineView *)outlineView shouldSelectItem:(id)item {
	return (![self outlineView:outlineView isGroupItem:item]);
}

/*- (NSIndexSet *)outlineView:(NSOutlineView *)outlineView selectionIndexesForProposedSelection:(NSIndexSet *)proposedSelectionIndexes {
	NSMutableIndexSet *newIndexSet = [NSMutableIndexSet indexSet];
	NSUInteger currentIndex = [proposedSelectionIndexes firstIndex];
	while (currentIndex != NSNotFound) {
		id item = [outlineView itemAtRow:currentIndex];
		if (![self outlineView:outlineView isGroupItem:item]) {
			[newIndexSet addIndex:currentIndex];
		}
		currentIndex = [proposedSelectionIndexes indexGreaterThanIndex:currentIndex];
	}
	return newIndexSet;
}*/

- (void)outlineViewSelectionDidChange:(NSNotification *)notification {
	NSOutlineView *outlineView = [notification object];
	if (outlineView == self.toolsOutlineView) {
		[self loadSelectedToolFromOutlineView:nil];
	}
}

//- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item;
//- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item;
//- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item;
//- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)tableColumn byItem:(id)item;

@end

@implementation CBMainWindowController (SplitViewDelegateMethods)

- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
	CGFloat newPosition = proposedPosition;
	if (proposedPosition < CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS) {
		newPosition = CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS;
		//newPosition = 0;
	} else if (proposedPosition > NSWidth([sender frame]) - CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS) {
		newPosition = NSWidth([sender frame]) - CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS;
		//newPosition = NSWidth([sender frame]);
	}
	return newPosition;
}

/*  During live resize of the window, lock the left side, the collection
 side, and resize the tableside
 The frames have to be set to add up to the total size minus the divider
 thickness */
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize {
    //detect if it's a window resize
    if ([sender inLiveResize]) {
		CGFloat dt = [sender dividerThickness];
		
        //info needed
        NSRect tmpRect = [sender bounds];
        NSArray *subviews =  [sender subviews];
        NSView *collectionsSide = [subviews objectAtIndex:0];
        NSView *tableSide = [subviews objectAtIndex:1];
        CGFloat collectionWidth = [collectionsSide bounds].size.width;
		
        //tableside frame: full size minus collection width and divider
        // My divider thickness is hard coded here as 1
        tmpRect.size.width = tmpRect.size.width - collectionWidth - dt;
        tmpRect.origin.x = tmpRect.origin.x + collectionWidth + dt;
        [tableSide setFrame:tmpRect];
		
        //collection frame stays the same
        tmpRect.size.width = collectionWidth;
        tmpRect.origin.x = 0;
        [collectionsSide setFrame:tmpRect];
    }
    /*else
	 [sender adjustSubviews];*/
}

- (void)windowDidResize:(NSNotification *)notification {
	NSWindow *window = [notification object];
	if (window == self.window) {
		NSSplitView *sv = self.toolsSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat w = NSWidth(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (w < (CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS - dt)) {
			w = CB_MINIMUM_WIDTH_FOR_TABLE_OR_MAIN_VIEWS - dt;
			
			// get the differential between the width we want and the width of the bottom rectangle
			CGFloat diff = w - NSWidth(rect);
			
			// resize the top view to the new width and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.width -= diff;
			topRect.origin.x += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}
	}
}

/*- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize
 {
 NSRect newFrame = [sender frame];
 CGFloat dt = [sender dividerThickness];
 
 //NSView *leftView = self.splitViewBottomView;
 //NSView *rightView = self.splitViewTopView;
 NSView *leftView = self.splitViewTopView;
 NSView *rightView = self.splitViewBottomView;
 
 // this is the fixed view (right)
 // on top on being fixed it is also collapsible
 NSRect rightFrame = [self.splitViewBottomView frame];
 // this is the flexible view (left)
 NSRect leftFrame = [self.splitViewTopView frame];
 
 rightFrame.size.height = newFrame.size.height;
 leftFrame.size.height = newFrame.size.height;
 
 if (![self.recordsSplitView isSubviewCollapsed:rightView]) {
 NSLog(@"not collapsed");
 rightFrame.origin.x = newFrame.size.width - rightFrame.size.width;
 rightFrame.origin.y = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - rightFrame.size.width - dt;
 } else {
 NSLog(@"collapsed");
 rightFrame.origin.x = newFrame.size.width;
 rightFrame.origin.y = 0;
 rightFrame.size.width = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - dt;
 }
 [leftView setFrame: leftFrame];
 [rightView setFrame:rightFrame];
 }*/

@end
