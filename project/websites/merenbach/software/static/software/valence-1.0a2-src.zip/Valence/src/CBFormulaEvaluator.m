//
//  CBFormulaEvaluator.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/22/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

/* [TODO] What about prefixes?!?! */

#import "CBFormulaEvaluator.h"

static NSDictionary *molarMassData = nil;

@interface NSString (CBFormulaEvaluation)
- (NSArray *)arrayByParsingFormula;
//- (NSArray *)constituentElements;
@end

@interface NSArray (CBFormulaEvaluation)
- (NSArray *)arrayByReplacingSymbols;
- (NSArray *)arrayByInsertingOperators;
@end


@implementation CBFormulaEvaluator

@synthesize formula = m_formula;

+ (void)initialize {
	NSString *path = [[NSBundle mainBundle] pathForResource:@"FormulaData" ofType:@"plist"];
	molarMassData = [[NSDictionary alloc] initWithContentsOfFile:path];
}

- (id)init {
	self = [super init];
	if (self != nil) {
		m_formula = [[NSString alloc] init];
	}
	return self;
}

- (id)initWithFormula:(NSString *)formula {
	self = [super init];
	if (self != nil) {
		m_formula = [formula copy];
	}
	return self;
}

- (void)dealloc {
	[m_formula release];
	m_formula = nil;
	
	//[molarMassData release];
	//molarMassData = nil;
	
	[super dealloc];
}

// use NSScanner to get nums
- (NSString *)evaluate {
	NSArray *tokens1;
	NSArray *tokens2;
	NSArray *tokens3;
	NSString *equation;
		
	NSString *formula = self.formula;
	
	tokens1 = [formula arrayByParsingFormula];	// [TODO] ensure that coefficient stuff is working
	tokens2 = [tokens1 arrayByInsertingOperators];
	tokens3 = [tokens2 arrayByReplacingSymbols];
	
	equation = [tokens3 componentsJoinedByString:@" "];
	//NSLog(@"formula = {%@}; tokens1 = {%@}; tokens2 = {%@}; tokens3 = {%@}; equation = {%@}",
	//	formula, tokens1, tokens2, tokens3, equation);
	return equation;
}

/*- (NSDecimalNumber *)massForSymbol:(NSString *)symbol {
	NSString *massString = [molarMassData objectForKey:symbol];
	NSDecimalNumber *massNumber = [NSDecimalNumber decimalNumberWithString:massString];
	return massNumber;
}

- (NSDecimalNumber *)numberOfAtomsForSymbol:(NSString *)symbol {
	NSDecimalNumber *number = [NSDecimalNumber zero];
	
	
	return number;
}*/

@end

@implementation NSString (CBFormulaEvaluation)

- (NSArray *)arrayByParsingFormula {
	NSMutableArray *array = [NSMutableArray array];
	NSString *formula = self;

	if (nil != formula) {
		BOOL success = YES;

		NSCharacterSet *uppercaseCharSet = [NSCharacterSet uppercaseLetterCharacterSet];
		NSCharacterSet *lowercaseCharSet = [NSCharacterSet lowercaseLetterCharacterSet];
		NSCharacterSet *openOpsCharSet = [NSCharacterSet characterSetWithCharactersInString:@"(["];
		NSCharacterSet *closeOpsCharSet = [NSCharacterSet characterSetWithCharactersInString:@"])"];
		NSCharacterSet *numbersCharSet = [NSCharacterSet decimalDigitCharacterSet];
		
		unsigned len = [formula length];

		unichar *c = (unichar *)NSZoneCalloc([self zone], len, sizeof(unichar));
		NSString *token;
		
		unsigned idx = 0;
		unsigned tokenLen;
		
		BOOL hasCoefficient = NO;
		{
			NSScanner *scanner = [[NSScanner alloc] initWithString:formula];
			int coefficient;
			
			if ([scanner scanInt:&coefficient]) {
				if (![scanner isAtEnd]) {
					hasCoefficient = YES;
					[array addObject:[NSString stringWithFormat:@"%i", coefficient]];
					[array addObject:@"*"];
					[array addObject:@"("];
				} else {
					hasCoefficient = NO;
				}
				idx = [scanner scanLocation];
			}
			
			[scanner release];
		}

		while (idx < len) {
			tokenLen = 0;
			c[0] = [formula characterAtIndex:idx];
			
			if ([numbersCharSet characterIsMember:c[0]]) {
				unsigned numIdx = 1;
				unichar nChar;
				while (len > idx + numIdx) {
					nChar = [formula characterAtIndex:idx + numIdx];
					if ([numbersCharSet characterIsMember:nChar]) {
						c[numIdx++] = nChar;
					} else {
						break;
					}
				}
				tokenLen = numIdx;
				
			} else if ([uppercaseCharSet characterIsMember:c[0]]) {
				tokenLen = 1;
				if (idx < (len - 1)) {
					c[1] = [formula characterAtIndex:idx + 1];
				} else {
					c[1] = '/';
				}

				if ([lowercaseCharSet characterIsMember:c[1]]) {
					tokenLen = 2;
				} else {
					tokenLen = 1;
				}
				
			} else if ([lowercaseCharSet characterIsMember:c[0]]) {
				success = NO;
				//NSLog(@"Input error! Misplaced lower-case character!");
				break;
			} else if ([openOpsCharSet characterIsMember:c[0]]) {
				if (len > idx + 1) {
					unichar nChar = [self characterAtIndex:(idx + 1)];
					
					if ([numbersCharSet characterIsMember:nChar]) {
						success = NO;
						break;
					} else {
						tokenLen = 1;
					}
				}
			} else if ([closeOpsCharSet characterIsMember:c[0]]) {
				tokenLen = 1;
			} else {
				success = NO;
				//NSLog(@"Input error!  Invalid character!");
				break;
			}
			
			if (tokenLen > 0) {
				token = [[NSString alloc] initWithCharacters:c length:tokenLen];
				[array addObject:token];
				[token release];
				
				idx += tokenLen;
			}
		}
		
		NSZoneFree([self zone], c);
		//[scanner release];
		
		if (hasCoefficient) {
			[array addObject:@")"];
		}

		if (!success) {
			[array removeAllObjects];	// clear parsed stuff
		}
	}
		
	return array;
}

/*- (NSArray *)constituentElements {
	NSCharacterSet *uppercaseCharSet = [NSCharacterSet uppercaseLetterCharacterSet];
	NSCharacterSet *lowercaseCharSet = [NSCharacterSet lowercaseLetterCharacterSet];

	NSArray *elementKeys = [molarMassData allKeys];

	NSMutableArray *array = [NSMutableArray array];
	
	unsigned idx = 0;
	unsigned len = [self length];
	
	unichar *c = (unichar *)NSZoneCalloc([self zone], len, sizeof(unichar));
	unsigned tokenLen;
	NSString *token;
	
	BOOL success = YES;
	
	while (idx < len) {
		tokenLen = 0;
		
		c[0] = [self characterAtIndex:idx];
		
		if (idx + 1 < len) {
			c[1] = [self characterAtIndex:(idx + 1)];
		} else {
			c[1] = '/';
		}
		
		if ([uppercaseCharSet characterIsMember:c[0]]) {
			if ([lowercaseCharSet characterIsMember:c[1]]) {
				tokenLen = 2;
			} else {
				tokenLen = 1;
			}
			
			token = [[NSString alloc] initWithCharacters:c length:tokenLen];
			if ([elementKeys containsObject:token]) {
				[array addObject:token];
			} else {
				success = NO;
				break;
			}
			[token release];
		} else {
			// do nothing
		}
		
		++idx;
	}
	
	NSZoneFree([self zone], c);
	
	if (!success) {
		[array removeAllObjects];
	}
	
	return array;
}*/

@end

@implementation NSArray (CBFormulaEvaluation)

- (NSArray *)arrayByReplacingSymbols {
	//NSCharacterSet *uppercaseCharCharacterSet = [NSCharacterSet uppercaseLetterCharacterSet];
	NSCharacterSet *digits = [NSCharacterSet decimalDigitCharacterSet];
	NSCharacterSet *ops = [NSCharacterSet characterSetWithCharactersInString:@"()[]*+"];

	NSMutableArray *array = [NSMutableArray array];
		
	NSEnumerator *e = [self objectEnumerator];
	id token;

	BOOL success = YES;

	while (token = [e nextObject]) {
		id replacementToken = [molarMassData objectForKey:token];
		if (nil != replacementToken) {
			[array addObject:replacementToken];
		} else {
			if ([token length] > 0) {
				unichar c = [token characterAtIndex:0];
				if ([digits characterIsMember:c]) {
					[array addObject:token];
				} else if ([ops characterIsMember:c]) {
					[array addObject:token];
				} else {
					success = NO;
					break;
				}
			}
		}
	}
	
	if (!success) {
		[array removeAllObjects];
	}
	
	return array;
}

- (NSArray *)arrayByInsertingOperators {
	NSCharacterSet *numbers = [NSCharacterSet decimalDigitCharacterSet];
	NSCharacterSet *openOps = [NSCharacterSet characterSetWithCharactersInString:@"(["];
	NSCharacterSet *closeOps = [NSCharacterSet characterSetWithCharactersInString:@"])"];
	NSCharacterSet *uppercaseCharSet = [NSCharacterSet uppercaseLetterCharacterSet];
	//NSCharacterSet *lowercaseCharSet = [NSCharacterSet lowercaseLetterCharacterSet];

	NSMutableArray *array = [NSMutableArray array];
	
	unsigned parenDepth = 0;
	
	NSEnumerator *e = [self objectEnumerator];
	id prevToken = [e nextObject];
	id token;
	unichar pc, c;
	
	while (token = [e nextObject]) {
		pc = [prevToken characterAtIndex:0];
		c = [token characterAtIndex:0];

		[array addObject:prevToken];
		
		if ([uppercaseCharSet characterIsMember:pc] && [uppercaseCharSet characterIsMember:c]) {
			[array addObject:@"+"];
		} else if ([uppercaseCharSet characterIsMember:pc] && [numbers characterIsMember:c]) {
			[array addObject:@"*"];
		} else if ([numbers characterIsMember:pc] && [uppercaseCharSet characterIsMember:c]) {
			[array addObject:@"+"];
		} else if ([numbers characterIsMember:pc] && [openOps characterIsMember:c]) {
			[array addObject:@"+"];
		} else if ([uppercaseCharSet characterIsMember:pc] && [openOps characterIsMember:c]) {		
			[array addObject:@"+"];
		} else if ([closeOps characterIsMember:pc] && [numbers characterIsMember:c]) {
			[array addObject:@"*"];
		} else if ([closeOps characterIsMember:pc] && [uppercaseCharSet characterIsMember:c]) {
			[array addObject:@"+"];
		}
	
		if ([openOps characterIsMember:pc]) {
			++parenDepth;
		} else if ([closeOps characterIsMember:pc]) {
			--parenDepth;
		}
		
		prevToken = token;
	}
	
	if (nil != prevToken) {
		[array addObject:prevToken];
		if ([closeOps characterIsMember:c]) {
			--parenDepth;
		}
			
		if (parenDepth != 0) {
			[array removeAllObjects];
		}
	}
	
	return array;
}

@end
