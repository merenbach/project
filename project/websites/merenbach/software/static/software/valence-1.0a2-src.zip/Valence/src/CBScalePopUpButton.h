//
//  CBPopUpButton.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on Fri Jan 10 2003.
//  Copyright (c) 2003 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//extern NSDictionary *menus();

@class CBMeasurementScale;

/*enum {
    defaultPressureIndex = 0,
    defaultTemperatureIndex = 1,
    defaultVolumeIndex = 0,
    defaultMolesIndex = 0,
    defaultMassIndex = 0,
    defaultHeatIndex = 0,
    defaultMassMolesIndex = 0,
};*/

extern NSString *CBScaleHeatKey;
extern NSString *CBScaleMassKey;
extern NSString *CBScaleMolesKey;
extern NSString *CBScalePressureKey;
extern NSString *CBScaleTemperatureKey;
extern NSString *CBScaleVolumeKey;
extern NSString *CBScaleMassMolesKey;

@interface NSPopUpButton (CBAdditions)

- (NSInteger)tagOfSelectedItem;
- (id)representedObjectOfSelectedItem;
- (id)itemWithRepresentedObject:(id)anObject;
- (void)selectItemWithRepresentedObject:(id)anObject;

@end

@interface NSPopUpButtonCell (CBAdditions)

- (NSInteger)tagOfSelectedItem;
- (id)representedObjectOfSelectedItem;
- (id)itemWithRepresentedObject:(id)anObject;
- (void)selectItemWithRepresentedObject:(id)anObject;

@end


@interface CBScalePopUpButton : NSPopUpButton {
    NSString *category;
	CBMeasurementScale *m_measurementScale;
	//CBMeasurementScale *m_initialScale;
}

@property (retain, readwrite) CBMeasurementScale *measurementScale;


- (NSString *)toolMenuBindingKey;

- (NSString *)category;
//- (NSString *)scale;

//- (BOOL)hasMolarScale;

@end

@interface CBScalePopUpButtonCell : NSPopUpButtonCell {
	CBMeasurementScale *m_measurementScale;
}

@property (retain, readwrite) CBMeasurementScale *measurementScale;

- (NSString *)toolMenuBindingKey;

- (NSString *)category;
//- (NSString *)scale;

//- (BOOL)hasMolarScale;

@end


/*
@interface CBPopUpButtonMolarScaleSelectedVT : NSValueTransformer {
}

+ (Class)transformedValueClass;
+ (BOOL)allowsReverseTransformation;
- (id)transformedValue:(id)value;

@end

*/