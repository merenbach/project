//
//  AMDragAndDropArrayController.m
//  A sorting, rearrangeable NSArrayController subclass
//
//  Created by Andrew Merenbach on 7/24/07.
//  Copyright 2007-2010 Andrew Merenbach. All rights reserved.
//

//  Many thanks to mmalc on Cocoa-Dev for the template used in this code!

#import "AMDragAndDropArrayController.h"

NSString *MovedRowsType = @"MOVED_ROWS_TYPE";
NSString *CopiedRowsType = @"COPIED_ROWS_TYPE";
NSString *ArchivedRowsType = @"ARCHIVED_ROWS_TYPE";


@implementation AMDragAndDropArrayController

@synthesize associatedTableView = m_associatedTableView;
@synthesize isDraggingEnabled = m_isDraggingEnabled;
@synthesize isDroppingEnabled = m_isDroppingEnabled;
@synthesize isDraggingEnabledWithCopy = m_isDraggingEnabledWithCopy;
@dynamic pasteboardTypesForDragging;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_isDraggingEnabled = YES;
		m_isDroppingEnabled = YES;
		m_isDraggingEnabledWithCopy = NO;
	}
	return self;
}

- (id)initWithContent:(id)content {
	self = [super initWithContent:content];
	if (self != nil) {
		m_isDraggingEnabled = YES;
		m_isDroppingEnabled = YES;
		m_isDraggingEnabledWithCopy = NO;
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		m_isDraggingEnabled = YES;
		m_isDroppingEnabled = YES;
		m_isDraggingEnabledWithCopy = NO;
	}
	return self;
}

- (void)awakeFromNib {
	// register for drag and drop
	[self.associatedTableView registerForDraggedTypes:self.pasteboardTypesForDragging];
	//[self.associatedTableView setAllowsMultipleSelection:YES];
}

// [am] my addition
- (NSArray *)pasteboardTypesForDragging {
	return [NSArray arrayWithObjects:CopiedRowsType, MovedRowsType, ArchivedRowsType, nil];
}

@end

@implementation AMDragAndDropArrayController (TableViewDataSource)

- (BOOL)tableView:(NSTableView *)tableView
	writeRowsWithIndexes:(NSIndexSet *)rowIndexes
	toPasteboard:(NSPasteboard*)pboard
{
	BOOL success = NO;
	
	if (self.isDraggingEnabled) {
		success = YES;
		
		// declare our own pasteboard types
		NSArray *typesArray = self.pasteboardTypesForDragging;
		(void)[pboard declareTypes:typesArray owner:self];
		
		// add row index set for local move
		NSData *archive = [NSKeyedArchiver archivedDataWithRootObject:rowIndexes];
		if (![pboard setData:archive forType:MovedRowsType]) {
			success = NO;
		}
		if (![pboard setData:archive forType:CopiedRowsType]) {
			success = NO;
		}
		/*if (![pboard setData:archive forType:ArchivedRowsType]) {
			success = NO;
		}*/
	}
	
	return success;
}

- (NSDragOperation)tableView:(NSTableView *)tableView
	validateDrop:(id <NSDraggingInfo>)info
	proposedRow:(NSInteger)row
	proposedDropOperation:(NSTableViewDropOperation)op
{
	NSDragOperation dragOp = NSDragOperationCopy;

	// if drag source is self, it's a move
	if ([info draggingSource] == self.associatedTableView) {
		NSEvent *currentEvent = [NSApp currentEvent];
		NSInteger optionKeyPressed = [currentEvent modifierFlags] & NSAlternateKeyMask;
		if (optionKeyPressed == 0) {
			dragOp = NSDragOperationMove;
		}
	}
	// we want to put the object at, not over,
	// the current row (contrast NSTableViewDropOn)
	[tableView setDropRow:row dropOperation:NSTableViewDropAbove];
	
	return dragOp;
}

- (BOOL)tableView:(NSTableView *)tableView
	acceptDrop:(id <NSDraggingInfo>)info
	row:(NSInteger)row
	dropOperation:(NSTableViewDropOperation)op
{
	BOOL success = NO;
	
	if (self.isDroppingEnabled) {
		success = NO;
		
		if (row < 0) {
			row = 0;
		}
		
		// if drag source is self, it's a move
		if ([info draggingSource] == self.associatedTableView) {
			NSEvent *currentEvent = [NSApp currentEvent];
			NSInteger optionKeyPressed = [currentEvent modifierFlags] & NSAlternateKeyMask;
			
			NSData *archive;
			NSIndexSet *indexSet;
			//NSInteger rowsAbove = 0;
			
			if (optionKeyPressed == 0) {
				archive = [[info draggingPasteboard] dataForType:MovedRowsType];
				indexSet = [NSKeyedUnarchiver unarchiveObjectWithData:archive];
				
				NSIndexSet *destinationIndexes = [self moveObjectsInArrangedObjectsFromIndexes:indexSet toIndex:row];
				[self setSelectionIndexes:destinationIndexes];
				// set selected rows to those that were just moved
				// Need to work out what moved where to determine proper selection...
				//rowsAbove = [self rowsAboveRow:row inIndexSet:indexSet];
				//NSRange range = NSMakeRange(row - rowsAbove, [indexSet count]);
				
				//indexSet = [NSIndexSet indexSetWithIndexesInRange:range];
				//[self setSelectionIndexes:indexSet];
				
				//rowsAbove = [self rowsAboveRow:row inIndexSet:indexSet];
				
				success = YES;
			
			} else if (self.isDraggingEnabledWithCopy) {
				archive = [[info draggingPasteboard] dataForType:CopiedRowsType];
				indexSet = [NSKeyedUnarchiver unarchiveObjectWithData:archive];
				
				// set selected rows to the results of the copy operation
				NSIndexSet *destinationIndexes = [self copyObjectsInArrangedObjectsFromIndexes:indexSet toIndex:row];
				[self setSelectionIndexes:destinationIndexes];
			
				success = YES;
			} else {
				success = NO;
			}
			
			/*if (success) {
				NSRange range = NSMakeRange(row - rowsAbove, [indexSet count]);
				indexSet = [NSIndexSet indexSetWithIndexesInRange:range];
				[self setSelectionIndexes:indexSet];
			}*/
		}
	}
	
	return success;
}



/*- (void)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet toIndex:(NSUInteger)insertIndex {
	NSArray			*objects = [self arrangedObjects];
	NSUInteger		index = [indexSet lastIndex];
	
	NSInteger		aboveInsertIndexCount = 0;
	id				object;
	NSInteger		removeIndex;
	NSDictionary	*attributes;
	
	while (NSNotFound != index) {
		if (index >= insertIndex) {
			removeIndex = index + aboveInsertIndexCount;
			aboveInsertIndexCount += 1;
		}
		else {
			removeIndex = index;
			insertIndex -= 1;
		}
		
		object = [objects objectAtIndex:removeIndex];
		attributes = [object dictionaryRepresentation];
		
		//[[[self managedObjectContext] undoManager] disableUndoRegistration];
		id newObject = [self newObject];
		[newObject setValuesForKeysWithDictionary:attributes];
		//[[[self managedObjectContext] undoManager] enableUndoRegistration];
		
		[self removeObjectAtArrangedObjectIndex:removeIndex];
		[self insertObject:newObject atArrangedObjectIndex:insertIndex];
		//[newObject release];
		
		index = [indexSet indexLessThanIndex:index];
	}
}*/

/*- (void)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet toIndex:(NSUInteger)insertIndex {
	NSArray			*objects = [self arrangedObjects];
	NSUInteger		index = [indexSet lastIndex];
	
	NSInteger		aboveInsertIndexCount = 0;
	id				object;
	NSInteger		removeIndex;
	NSDictionary	*attributes;
	
	//[[[self managedObjectContext] undoManager] beginUndoGrouping];
	
	while (NSNotFound != index) {
		if (index >= insertIndex) {
			removeIndex = index + aboveInsertIndexCount;
			aboveInsertIndexCount += 1;
		}
		else {
			removeIndex = index;
			insertIndex -= 1;
		}
		
		object = [objects objectAtIndex:removeIndex];
		attributes = [object dictionaryRepresentation];
		//NSLog(@"oldobject c = %@", attributes);
		//[[[self managedObjectContext] undoManager] disableUndoRegistration];

		id newObject = [self newObject];
		[newObject setValuesForKeysWithDictionary:attributes];
		//[[[self managedObjectContext] undoManager] enableUndoRegistration];

		//NSLog(@"newobject d = %@", [newObject dictionaryRepresentation]);
		[self removeObjectAtArrangedObjectIndex:removeIndex];
		[self insertObject:newObject atArrangedObjectIndex:insertIndex];
		//[newObject release];
		
		index = [indexSet indexLessThanIndex:index];
	}

	//[[[self managedObjectContext] undoManager] endUndoGrouping];

}*/

- (NSIndexSet *)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet*)fromIndexSet
												toIndex:(NSUInteger)insertIndex
{
	// If any of the removed objects come before the insertion index,
	// we need to decrement the index appropriately
	NSUInteger adjustedInsertIndex = insertIndex - [fromIndexSet countOfIndexesInRange:(NSRange){0, insertIndex}];
	NSRange destinationRange = NSMakeRange(adjustedInsertIndex, [fromIndexSet count]);
	NSIndexSet *destinationIndexes = [NSIndexSet indexSetWithIndexesInRange:destinationRange];
	
	NSArray *objectsToMove = [[self arrangedObjects] objectsAtIndexes:fromIndexSet];
	[self removeObjectsAtArrangedObjectIndexes:fromIndexSet];
	[self insertObjects:objectsToMove atArrangedObjectIndexes:destinationIndexes];
	
	return destinationIndexes;
}

- (NSIndexSet *)copyObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)fromIndexSet
												toIndex:(NSUInteger)insertIndex
{
	NSArray *objectsToCopy = [[self arrangedObjects] objectsAtIndexes:fromIndexSet];
	NSMutableArray *copies = [NSMutableArray arrayWithCapacity:[fromIndexSet count]];
							  
	for (id object in objectsToCopy) {
		id copy = [object copy];
		[copies addObject:copy];
		[copy release];
	}
	
	NSRange range = NSMakeRange(insertIndex, [fromIndexSet count]);
	NSIndexSet *destinationIndexes = [NSIndexSet indexSetWithIndexesInRange:range];
	[self insertObjects:copies atArrangedObjectIndexes:destinationIndexes];
	
	return destinationIndexes;
}

/*- (NSUInteger)rowsAboveRow:(NSUInteger)row inIndexSet:(NSIndexSet *)indexSet
{
	NSUInteger currentIndex = [indexSet firstIndex];
	NSUInteger i = 0;
	while (currentIndex != NSNotFound) {
		if (currentIndex < row) { i++; }
		currentIndex = [indexSet indexGreaterThanIndex:currentIndex];
	}
	return i;
}*/

- (NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView
{
	return 0;
}

/*- (NSIndexSet *)indexSetFromRows:(NSArray *)rows
{
    NSMutableIndexSet *indexSet = [NSMutableIndexSet indexSet];
    NSEnumerator *rowEnumerator = [rows objectEnumerator];
    NSNumber *idx;
    while (idx = [rowEnumerator nextObject])
    {
		[indexSet addIndex:[idx intValue]];
    }
    return indexSet;
}*/

- (id)tableView:(NSTableView *)aTableView
	objectValueForTableColumn:(NSTableColumn *)aTableColumn
	row:(NSInteger)rowIndex
{
	return nil;
}



/*- (void)moveObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet
												toIndex:(NSUInteger)insertIndex
 {
	NSArray		*objects = [self arrangedObjects];
	NSInteger	index = [indexSet lastIndex];
	
	NSInteger	aboveInsertIndexCount = 0;
	id			object;
	NSInteger	removeIndex;
	
	while (NSNotFound != index)
	{
		if (index >= insertIndex)
		{
			removeIndex = index + aboveInsertIndexCount;
			aboveInsertIndexCount += 1;
		}
		else
		{
			removeIndex = index;
			insertIndex -= 1;
		}
		
		// Get the object we're moving
		object = [objects objectAtIndex:removeIndex];
		
		// In case nobody else is retaining the object, we need to keep it alive while we move it 		
		[object retain];
		[self removeObjectAtArrangedObjectIndex:removeIndex];
		[self insertObject:object atArrangedObjectIndex:insertIndex];
		[object release];
		
		index = [indexSet indexLessThanIndex:index];
	}
}*/

/*- (void)copyObjectsInArrangedObjectsFromIndexes:(NSIndexSet *)indexSet toIndex:(NSUInteger)insertIndex {
	NSArray			*objects = [self arrangedObjects];
	NSUInteger		copyFromIndex = [indexSet lastIndex];
	
	NSInteger		aboveInsertIndexCount = 0;
	id				object;
	NSInteger		copyIndex;
	
	while (NSNotFound != copyFromIndex) {
		if (copyFromIndex >= insertIndex) {
			copyIndex = copyFromIndex + aboveInsertIndexCount;
			aboveInsertIndexCount += 1;
		}
		else {
			copyIndex = copyFromIndex;
			//insertIndex -= 1;
		}
		object = [objects objectAtIndex:copyIndex];
		[self insertObject:[[object copy] autorelease] atArrangedObjectIndex:insertIndex];
		
		copyFromIndex = [indexSet indexLessThanIndex:copyFromIndex];
	}
}
*/
	 
@end
