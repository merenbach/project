#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;

@interface CBCharlesLawTool : CBToolViewController
{	
	double m_volumeTabV1Value;
	double m_volumeTabV2Value;
	double m_volumeTabT1Value;
	double m_volumeTabT2Value;
	
	double m_temperatureTabV1Value;
	double m_temperatureTabV2Value;
	double m_temperatureTabT1Value;
	double m_temperatureTabT2Value;
	
	CBMeasurementScale *m_volumeTabV1Scale;
	CBMeasurementScale *m_volumeTabV2Scale;
	CBMeasurementScale *m_volumeTabT1Scale;
	CBMeasurementScale *m_volumeTabT2Scale;
	
	CBMeasurementScale *m_temperatureTabV1Scale;
	CBMeasurementScale *m_temperatureTabV2Scale;
	CBMeasurementScale *m_temperatureTabT1Scale;
	CBMeasurementScale *m_temperatureTabT2Scale;	
}

@property (assign, readwrite) double volumeTabV1Value;
@property (assign, readwrite) double volumeTabV2Value;
@property (assign, readwrite) double volumeTabT1Value;
@property (assign, readwrite) double volumeTabT2Value;

@property (assign, readwrite) double temperatureTabV1Value;
@property (assign, readwrite) double temperatureTabV2Value;
@property (assign, readwrite) double temperatureTabT1Value;
@property (assign, readwrite) double temperatureTabT2Value;

@property (retain, readwrite) CBMeasurementScale *volumeTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabT2Scale;

@property (retain, readwrite) CBMeasurementScale *temperatureTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT2Scale;

- (IBAction)calculateVolume:(id)sender;
- (IBAction)calculateTemperature:(id)sender;

@end
