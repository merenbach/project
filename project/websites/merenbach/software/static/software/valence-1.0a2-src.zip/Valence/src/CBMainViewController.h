//
//  CBMainViewController.h
//  Valence
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class AMOutlineView;


@interface CBMainViewController : NSViewController {
}

@end
