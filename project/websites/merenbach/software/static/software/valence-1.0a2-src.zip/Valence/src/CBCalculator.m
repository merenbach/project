//
//  CBCalculator.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on Mon Dec 30 2002.
//  Copyright (c) 2002 Andrew Merenbach. All rights reserved.
//

#import "CBCalculator.h"
#import "CBExpressionEvaluator.h"
#import "CBScalePopUpButton.h"


NSString *CBScaleMolesSuffix = @"moles";	// [TODO] kludge, kludge, kludge...

static NSDictionary *conversions = nil;
//static NSDictionary *scales = nil;


@implementation CBCalculator

+ (void)initialize {
	NSBundle *bundle = [NSBundle mainBundle];
	NSString *path;
	
	path = [bundle pathForResource:@"Conversions" ofType:@"plist"];
	conversions = [[NSDictionary alloc] initWithContentsOfFile:path];
}

+ (double)convert:(double)input fromScale:(NSString *)scale category:(NSString *)category {
	double output;

	NSString *inString = [NSString stringWithFormat:@"%lf", input];
	NSDecimalNumber *inNumber = [NSDecimalNumber decimalNumberWithString:inString];

	if (![inNumber isEqualToNumber:[NSDecimalNumber notANumber]]) {
		NSDictionary *dict = [conversions objectForKey:category];
		NSArray *conv = [dict objectForKey:scale];
		NSString *calculation = [NSString stringWithFormat:[conv objectAtIndex:0], input];
		NSDecimalNumber *result = [CBExpressionEvaluator evaluateExpression:calculation];
		output = [result doubleValue];
	} else {
		output = 0;
	}
		
	return output;
}

+ (double)convert:(double)input toScale:(NSString *)scale category:(NSString *)category {
	double output;

	NSString *inString = [NSString stringWithFormat:@"%lf", input];
	NSDecimalNumber *inNumber = [NSDecimalNumber decimalNumberWithString:inString];
	
	if (![inNumber isEqualToNumber:[NSDecimalNumber notANumber]]) {
		NSDictionary *dict = [conversions objectForKey:category];
		NSArray *conv = [dict objectForKey:scale];
		NSString *calculation = [NSString stringWithFormat:[conv objectAtIndex:1], input];
		NSDecimalNumber *result = [CBExpressionEvaluator evaluateExpression:calculation];
		output = [result doubleValue];
	} else {
		output = 0;
	}
	
	return output;
}


+ (double)convert:(double)input fromScale:(NSString *)scale category:(NSString *)category molarMass:(double)mm hasMolarScale:(BOOL)scaleIsMolarFlag {
	double output;

	NSString *inString = [NSString stringWithFormat:@"%lf", input];
	NSDecimalNumber *inNumber = [NSDecimalNumber decimalNumberWithString:inString];
	
	if (![inNumber isEqualToNumber:[NSDecimalNumber notANumber]]) {
		NSDictionary *dict = [conversions objectForKey:category];
		NSArray *conv = [dict objectForKey:scale];
		NSString *calculation = [NSString stringWithFormat:[conv objectAtIndex:0], input];
		NSDecimalNumber *result = [CBExpressionEvaluator evaluateExpression:calculation];
		
		output = [result doubleValue];
		if (!scaleIsMolarFlag) {
			if (mm != 0) {
				output /= mm;
			} else {
				output = 0;
			}
		}
	} else {
		output = 0;
	}
	
	return output;
}

+ (double)convert:(double)input toScale:(NSString *)scale category:(NSString *)category molarMass:(double)mm hasMolarScale:(BOOL)scaleIsMolarFlag {
	double output;

	NSString *inString = [NSString stringWithFormat:@"%lf", input];
	NSDecimalNumber *inNumber = [NSDecimalNumber decimalNumberWithString:inString];
	
	if (![inNumber isEqualToNumber:[NSDecimalNumber notANumber]]) {
		NSDictionary *dict = [conversions objectForKey:category];
		NSArray *conv = [dict objectForKey:scale];
		NSString *calculation = [NSString stringWithFormat:[conv objectAtIndex:1], input];
		NSDecimalNumber *result = [CBExpressionEvaluator evaluateExpression:calculation];

		output = [result doubleValue];
		if (!scaleIsMolarFlag) {
			if (mm != 0) {
				output *= mm;
			} else {
				output = 0;
			}
		}
	} else {
		output = 0;
	}
	
	return output;
}

+ (double)convert:(double)input fromScale:(CBMeasurementScale *)scale {
	NSString *scaleType = scale.scaleType;
	NSString *scaleCategory = scale.scaleCategory;
	return [self convert:input fromScale:scaleType category:scaleCategory];
}

+ (double)convert:(double)input toScale:(CBMeasurementScale *)scale {
	NSString *scaleType = scale.scaleType;
	NSString *scaleCategory = scale.scaleCategory;
	return [self convert:input toScale:scaleType category:scaleCategory];
}

+ (double)convert:(double)input fromScale:(CBMeasurementScale *)scale molarMass:(double)mm {
	NSString *scaleType = scale.scaleType;
	NSString *scaleCategory = scale.scaleCategory;
	BOOL molarFlag = scale.isMolarScale;
	return [self convert:input fromScale:scaleType category:scaleCategory molarMass:mm hasMolarScale:molarFlag];
}

+ (double)convert:(double)input toScale:(CBMeasurementScale *)scale molarMass:(double)mm {
	NSString *scaleType = scale.scaleType;
	NSString *scaleCategory = scale.scaleCategory;
	BOOL molarFlag = scale.isMolarScale;
	return [self convert:input toScale:scaleType category:scaleCategory molarMass:mm hasMolarScale:molarFlag];
}

@end
