#import <Cocoa/Cocoa.h>
//#import "TaskWrapper.h"
//#import "CBMainController.h"
@class AMTableView;
@class CBRecentItemsArrayController;
@class CBMolarMassCalculation;


@interface CBMolarMassWindowController : NSWindowController
{
    NSComboBox *m_formulaComboBox;
	NSTextField *m_molarMassField;
	NSTextField *m_molarSubstanceField;
		
	BOOL m_isEvaluating;
	NSOperationQueue *m_operationQueue;
	CBMolarMassCalculation *m_formulaOperation;
	
	NSArray *m_recentFormulae;
}

@property (assign) IBOutlet NSComboBox *formulaComboBox;		// (2010-04-10: used once?)
@property (assign) IBOutlet NSTextField *molarMassField;		// (2010-04-10: used once?)
@property (assign) IBOutlet NSTextField *molarSubstanceField;	// (2010-04-10: used once?)
@property (assign, readwrite) BOOL isEvaluating;
@property (retain, readwrite) NSOperationQueue *operationQueue;
@property (retain, readwrite) CBMolarMassCalculation *formulaOperation;
@property (copy, readwrite) NSArray *recentFormulae;

- (void)toggleEvaluation:(id)sender;
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
- (void)finishEvaluation:(CBMolarMassCalculation *)calculation;
- (void)displayAlert:(NSAlert *)alert;
- (void)appendFormulaToFormulae:(NSString *)formula;

//- (IBAction)exportData:(id)sender;

// CBTableDataSource...
//- (void)copyRows:(id)sender;

@end
