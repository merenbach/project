//
//  CBPeriodicTableMatrix.h
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 05/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


//@class CBPTArrowBox;
@class ELMFamilyLabelMatrix;
@class ELMPeriodLabelMatrix;;


@interface CBPeriodicTableMatrix : NSMatrix {
	NSDictionary *m_currentColorScheme;
	NSDictionary *m_elementColorMap;
	
	NSDictionary *m_colorsDict;

	NSAffineTransform *connectorTransform;
	NSBezierPath *connector1, *connector2;
			
	NSArray *elementCells;
}

@property (copy, readwrite) NSDictionary *colorsDict;

@property (copy, readwrite) NSDictionary *currentColorScheme;
@property (retain, readwrite) NSDictionary *elementColorMap;

//- (void)searchElements:(id)sender;
- (void)handleResize;
- (void)searchElements:(BOOL)blank;
- (void)prepareCells:(NSArray *)elements;

- (void)recalculateConnectorPaths;
- (void)drawConnectors:(NSRect)rect;

//- (void)drawFootnoteSeriesLabels:(NSRect)rect;

- (void)prepareElementColorMapFromTableData:(NSArray *)data;
- (void)changeCurrentColorSchemeWithKey:(NSString *)key;
- (void)reloadCellColors;

@end
