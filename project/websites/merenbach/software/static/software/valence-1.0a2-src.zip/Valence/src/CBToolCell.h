//
//  CBToolCell.h
//  Valence
//
//  Created by Andrew Merenbach on 4/3/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBToolCell : NSTextFieldCell {

}

- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView*)controlView;
//- (NSSize)cellSize;

@end
