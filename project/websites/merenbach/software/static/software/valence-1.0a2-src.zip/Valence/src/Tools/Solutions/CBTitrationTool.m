#import "CBTitrationTool.h"
#import "CBCalculator.h"

@implementation CBTitrationTool

@synthesize molarityTabV1Value = m_molarityTabV1Value;
@synthesize molarityTabV2Value = m_molarityTabV2Value;
@synthesize molarityTabM1Value = m_molarityTabM1Value;
@synthesize molarityTabM2Value = m_molarityTabM2Value;
@synthesize volumeTabV1Value = m_volumeTabV1Value;
@synthesize volumeTabV2Value = m_volumeTabV2Value;
@synthesize volumeTabM1Value = m_volumeTabM1Value;
@synthesize volumeTabM2Value = m_volumeTabM2Value;
@synthesize molarityTabV1Scale = m_molarityTabV1Scale;
@synthesize molarityTabV2Scale = m_molarityTabV2Scale;
@synthesize volumeTabV1Scale = m_volumeTabV1Scale;
@synthesize volumeTabV2Scale = m_volumeTabV2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_molarityTabV1Value = 0;
		m_molarityTabV2Value = 0;
		m_molarityTabM1Value = 0;
		m_molarityTabM2Value = 0;
		
		m_volumeTabV1Value = 0;
		m_volumeTabV2Value = 0;
		m_volumeTabM1Value = 0;
		m_volumeTabM2Value = 0;
		
		m_molarityTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_molarityTabV2Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV1Scale = [CBMeasurementScale initialVolumeScale];
		m_volumeTabV2Scale = [CBMeasurementScale initialVolumeScale];
	}
	return self;
}

- (void)dealloc {
	[m_molarityTabV1Scale release];
	[m_molarityTabV1Scale release];
	[m_volumeTabV1Scale release];
	[m_volumeTabV2Scale release];
	
	m_molarityTabV1Scale = nil;
	m_molarityTabV1Scale = nil;
	m_volumeTabV1Scale = nil;
	m_volumeTabV2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculateMolarity:(id)sender
{
    double m1 = self.molarityTabM1Value;
    double m2;
    double v1 = self.molarityTabV1Value;
    double v2 = self.molarityTabV2Value;

    v1 = [CBCalculator convert:v1 fromScale:self.molarityTabV1Scale];
    v2 = [CBCalculator convert:v2 fromScale:self.molarityTabV2Scale];
    
    /* finish up with the calculation itself */
    m2 = m1 * v1 / v2;

    self.molarityTabM2Value = m2;
}

- (IBAction)calculateVolume:(id)sender
{
    double m1 = self.volumeTabM1Value;
    double m2 = self.volumeTabM2Value;
    double v1 = self.volumeTabV1Value;
    double v2;
    
    v1 = [CBCalculator convert:v1 fromScale:self.volumeTabV1Scale];

    /* finish up with the calculation itself */
    v2 = v1 * m1 / m2;
    v2 = [CBCalculator convert:v2 toScale:self.volumeTabV2Scale];
	
    self.volumeTabV2Value = v2;
}

@end
