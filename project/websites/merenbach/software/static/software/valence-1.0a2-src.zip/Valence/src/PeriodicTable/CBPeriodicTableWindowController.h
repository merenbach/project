//
//  CBPeriodicTableWindowController.h
//  Elemental
//
//  Created by Andrew Merenbach on 15/10/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//@class ELMLegendTableView;

//@class CBPeriodicTableWindowController;
@class CBPeriodicTableMatrix;

@class CBPeriodicTableInspectorWindowController;
//@class CBRecentItemsArrayController;

@interface CBPeriodicTableWindowController : NSWindowController {
	NSArray *m_periodicTableData;
	NSArrayController *m_elementsArrayController;
	CBPeriodicTableMatrix *m_periodicTableMatrix;
	NSSplitView *m_elementsSplitView;
	
	NSArray *m_elementsArray;
	NSDictionary *m_legendsDictionary;
	NSDictionary *m_periodicTableColors;

	NSArray *m_currentLegendTerms;
	CGFloat m_cachedDividerPosition;
	CBPeriodicTableInspectorWindowController *m_inspectorWindowController;
	NSArray *m_periodicTableKeys;
	
	// end properties
	
	
	//IBOutlet CBRecentItemsArrayController *recentSearchesArrayController;
	//IBOutlet NSArrayController *searchArrayController;
	IBOutlet NSArrayController *periodicTablesArrayController;

	//IBOutlet NSArrayController *legendArrayController;
    IBOutlet NSTableView *legendTableView;
	IBOutlet NSTextView *legendDescriptionTextView;
		
	NSArrayController *elementInformationArrayController;
	
	//IBOutlet CBPeriodicTableInspectorWindowController *informationWindowController;
	//IBOutlet NSMenu *searchTemplateMenu;
}

@property (readonly) NSArray *periodicTableData;
@property (assign) IBOutlet NSArrayController *elementsArrayController;
@property (assign) IBOutlet CBPeriodicTableMatrix *periodicTableMatrix;
@property (assign) IBOutlet NSSplitView *elementsSplitView;
@property (readonly) NSArray *elementsArray;
@property (readonly) NSDictionary *legendsDictionary;
@property (readonly) NSDictionary *periodicTableColors;
@property (copy, readwrite) NSArray *currentLegendTerms;
@property (assign, readwrite) CGFloat cachedDividerPosition;
@property (retain, readwrite) CBPeriodicTableInspectorWindowController *inspectorWindowController;
@property (readonly) NSArray *periodicTableKeys;

- (IBAction)switchTable:(id)sender;


- (id)currentPeriodicTableKey;

//- (NSArray *)legendSortDescriptors;

//- (NSArray *)currentFamily;
//- (void)setCurrentFamily:(NSArray *)anArray;

- (IBAction)showInspectorWindow:(id)sender;
//- (void)showInformationWindow:(id)sender;
- (void)prepareInspectorWindowData:(id)sender;
- (void)searchFilterPredicateChanged;

//- (IBAction)toggleLegend:(id)sender;

@end


/*@interface CBPeriodicTableWindowController (LegendTableViewDelegateMethods)

- (void)tableView:(NSTableView *)aTableView willDisplayCell:(id)aCell
	forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex;
- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end*/

@interface CBPeriodicTableWindowController (SplitViewDelegateMethods)
//- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset;
//- (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset;
- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset;
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize;
- (void)windowDidResize:(NSNotification *)notification;
@end
