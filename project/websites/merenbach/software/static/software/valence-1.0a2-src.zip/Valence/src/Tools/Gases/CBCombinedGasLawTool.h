#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;

@interface CBCombinedGasLawTool : CBToolViewController
{
	double m_pressureTabP1Value;
	double m_pressureTabP2Value;
	double m_pressureTabV1Value;
	double m_pressureTabV2Value;
	double m_pressureTabT1Value;
	double m_pressureTabT2Value;
	
	double m_volumeTabP1Value;
	double m_volumeTabP2Value;
	double m_volumeTabV1Value;
	double m_volumeTabV2Value;
	double m_volumeTabT1Value;
	double m_volumeTabT2Value;
	
	double m_temperatureTabP1Value;
	double m_temperatureTabP2Value;
	double m_temperatureTabV1Value;
	double m_temperatureTabV2Value;
	double m_temperatureTabT1Value;
	double m_temperatureTabT2Value;
	
	CBMeasurementScale *m_pressureTabP1Scale;
	CBMeasurementScale *m_pressureTabP2Scale;
	CBMeasurementScale *m_pressureTabV1Scale;
	CBMeasurementScale *m_pressureTabV2Scale;
	CBMeasurementScale *m_pressureTabT1Scale;
	CBMeasurementScale *m_pressureTabT2Scale;

	CBMeasurementScale *m_volumeTabP1Scale;
	CBMeasurementScale *m_volumeTabP2Scale;
	CBMeasurementScale *m_volumeTabV1Scale;
	CBMeasurementScale *m_volumeTabV2Scale;
	CBMeasurementScale *m_volumeTabT1Scale;
	CBMeasurementScale *m_volumeTabT2Scale;

	CBMeasurementScale *m_temperatureTabP1Scale;
	CBMeasurementScale *m_temperatureTabP2Scale;
	CBMeasurementScale *m_temperatureTabV1Scale;
	CBMeasurementScale *m_temperatureTabV2Scale;
	CBMeasurementScale *m_temperatureTabT1Scale;
	CBMeasurementScale *m_temperatureTabT2Scale;	
}

@property (assign, readwrite) double pressureTabP1Value;
@property (assign, readwrite) double pressureTabP2Value;
@property (assign, readwrite) double pressureTabV1Value;
@property (assign, readwrite) double pressureTabV2Value;
@property (assign, readwrite) double pressureTabT1Value;
@property (assign, readwrite) double pressureTabT2Value;

@property (assign, readwrite) double volumeTabP1Value;
@property (assign, readwrite) double volumeTabP2Value;
@property (assign, readwrite) double volumeTabV1Value;
@property (assign, readwrite) double volumeTabV2Value;
@property (assign, readwrite) double volumeTabT1Value;
@property (assign, readwrite) double volumeTabT2Value;

@property (assign, readwrite) double temperatureTabP1Value;
@property (assign, readwrite) double temperatureTabP2Value;
@property (assign, readwrite) double temperatureTabV1Value;
@property (assign, readwrite) double temperatureTabV2Value;
@property (assign, readwrite) double temperatureTabT1Value;
@property (assign, readwrite) double temperatureTabT2Value;

@property (retain, readwrite) CBMeasurementScale *pressureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabT2Scale;

@property (retain, readwrite) CBMeasurementScale *volumeTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *volumeTabT2Scale;

@property (retain, readwrite) CBMeasurementScale *temperatureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabV1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabV2Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT2Scale;

- (IBAction)calculatePressure:(id)sender;
- (IBAction)calculateVolume:(id)sender;
- (IBAction)calculateTemperature:(id)sender;

@end
