#import "CBHeatEnergyTransferredTool.h"
#import "CBCalculator.h"

#define CB_HEAT_ENERGY_XFER_INITIAL_STR @"initial"
#define CB_HEAT_ENERGY_XFER_FINAL_STR @"final"


@implementation CBHeatEnergyTransferredTool

@synthesize qTabMValue = m_qTabMValue;
@synthesize qTabCValue = m_qTabCValue;
@synthesize qTabT1Value = m_qTabT1Value;
@synthesize qTabT2Value = m_qTabT2Value;
@synthesize qTabQValue = m_qTabQValue;
@synthesize qTabMScale = m_qTabMScale;
@synthesize qTabCScale = m_qTabCScale;
@synthesize qTabT1Scale = m_qTabT1Scale;
@synthesize qTabT2Scale = m_qTabT2Scale;
@synthesize qTabQScale = m_qTabQScale;
@synthesize qTabEquilibriumString = m_qTabEquilibriumString;

@synthesize mTabMValue = m_mTabMValue;
@synthesize mTabCValue = m_mTabCValue;
@synthesize mTabT1Value = m_mTabT1Value;
@synthesize mTabT2Value = m_mTabT2Value;
@synthesize mTabQValue = m_mTabQValue;
@synthesize mTabMScale = m_mTabMScale;
@synthesize mTabCScale = m_mTabCScale;
@synthesize mTabT1Scale = m_mTabT1Scale;
@synthesize mTabT2Scale = m_mTabT2Scale;
@synthesize mTabQScale = m_mTabQScale;
@synthesize mTabEquilibriumString = m_mTabEquilibriumString;

@synthesize cTabMValue = m_cTabMValue;
@synthesize cTabCValue = m_cTabCValue;
@synthesize cTabT1Value = m_cTabT1Value;
@synthesize cTabT2Value = m_cTabT2Value;
@synthesize cTabQValue = m_cTabQValue;
@synthesize cTabMScale = m_cTabMScale;
@synthesize cTabCScale = m_cTabCScale;
@synthesize cTabT1Scale = m_cTabT1Scale;
@synthesize cTabT2Scale = m_cTabT2Scale;
@synthesize cTabQScale = m_cTabQScale;
@synthesize cTabEquilibriumString = m_cTabEquilibriumString;

@synthesize tTabMValue = m_tTabMValue;
@synthesize tTabCValue = m_tTabCValue;
@synthesize tTabTValue = m_tTabTValue;
@synthesize tTabQValue = m_tTabQValue;
@synthesize tTabMScale = m_tTabMScale;
@synthesize tTabCScale = m_tTabCScale;
@synthesize tTabTScale = m_tTabTScale;
@synthesize tTabQScale = m_tTabQScale;
@synthesize tTabEquilibriumString = m_tTabEquilibriumString;


//@synthesize tInitialString = m_tInitialString;
//@synthesize tFinalString = m_tFinalString;

/*- (IBAction)moreInfo:(id)sender
{
//    [self showWindow:[self window]];
    if (!infoWindow) {
        if (![NSBundle loadNibNamed:@"Stoichiometry" owner:self])  {
            NSLog(@"Failed to load Stoichiometry.nib");
            NSBeep();
            return;
        }
	//[[scaleField window] setExcludedFromWindowsMenu:YES];
	//[[scaleField window] setMenu:nil];
        [infoWindow center];
    }
    [infoWindow makeKeyAndOrderFront:nil];
}*/

/*typedef struct measurement {
    NSString *scale;
    NSString *string;
} measurement;*/


- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_qTabMValue = 0;
		m_qTabCValue = 0;
		m_qTabT1Value = 0;
		m_qTabT2Value = 0;
		m_qTabQValue = 0;
		m_qTabMScale = [[CBMeasurementScale initialMassScale] retain];
		m_qTabCScale = [[CBMeasurementScale initialHeatScale] retain];
		m_qTabT1Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_qTabT2Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_qTabQScale = [[CBMeasurementScale initialHeatScale] retain];
		m_qTabEquilibriumString = [[NSString alloc] initWithString:@""];
		
		m_mTabMValue = 0;
		m_mTabCValue = 0;
		m_mTabT1Value = 0;
		m_mTabT2Value = 0;
		m_mTabQValue = 0;
		m_mTabMScale = [[CBMeasurementScale initialMassScale] retain];
		m_mTabCScale = [[CBMeasurementScale initialHeatScale] retain];
		m_mTabT1Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_mTabT2Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_mTabQScale = [[CBMeasurementScale initialHeatScale] retain];
		m_mTabEquilibriumString = [[NSString alloc] initWithString:@""];
		
		m_cTabMValue = 0;
		m_cTabCValue = 0;
		m_cTabT1Value = 0;
		m_cTabT2Value = 0;
		m_cTabQValue = 0;
		m_cTabMScale = [[CBMeasurementScale initialMassScale] retain];
		m_cTabCScale = [[CBMeasurementScale initialHeatScale] retain];
		m_cTabT1Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_cTabT2Scale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_cTabQScale = [[CBMeasurementScale initialHeatScale] retain];
		m_cTabEquilibriumString = [[NSString alloc] initWithString:@""];
		
		m_tTabMValue = 0;
		m_tTabCValue = 0;
		m_tTabTValue = 0;
		m_tTabQValue = 0;
		m_tTabMScale = [[CBMeasurementScale initialMassScale] retain];
		m_tTabCScale = [[CBMeasurementScale initialHeatScale] retain];
		m_tTabTScale = [[CBMeasurementScale initialTemperatureScale] retain];
		m_tTabQScale = [[CBMeasurementScale initialHeatScale] retain];
		m_tTabEquilibriumString = [[NSString alloc] initWithString:@""];
		
		/*m_fromValue = 0;
		m_toValue = 0;
		m_fromScale = [CBMeasurementScale initialHeatScale];
		m_toScale = [CBMeasurementScale initialHeatScale];
		m_resultScaleString = m_toScale.localizedTitle;*/
		
		/*NSDictionary *superscriptAttrs = [NSDictionary dictionaryWithObjectsAndKeys:
										  [NSNumber numberWithInteger:1], NSSuperscriptAttributeName,								  
										  [NSFont systemFontOfSize:[NSFont smallSystemFontSize]], NSFontAttributeName,
										  nil];
		
		NSAttributedString *initialString = [[[NSAttributedString alloc] initWithString:NSLocalizedString(CB_HEAT_ENERGY_XFER_INITIAL_STR, CB_HEAT_ENERGY_XFER_INITIAL_STR) attributes:superscriptAttrs] autorelease];
		NSAttributedString *finalString = [[[NSAttributedString alloc] initWithString:NSLocalizedString(CB_HEAT_ENERGY_XFER_FINAL_STR, CB_HEAT_ENERGY_XFER_FINAL_STR) attributes:superscriptAttrs] autorelease];
		
		NSMutableAttributedString *tInitialStringTemp = [[[NSMutableAttributedString alloc] initWithString:@"t"] autorelease];
		NSMutableAttributedString *tFinalStringTemp = [[[NSMutableAttributedString alloc] initWithString:@"t"] autorelease];
		
		[tInitialStringTemp appendAttributedString:initialString];
		[tFinalStringTemp appendAttributedString:finalString];
		
		m_tInitialString = [tInitialStringTemp copy];
		m_tFinalString = [tFinalStringTemp copy];*/
	}
	return self;
}

- (void)dealloc {
	[m_qTabMScale release];
	[m_qTabCScale release];
	[m_qTabT1Scale release];
	[m_qTabT2Scale release];
	[m_qTabQScale release];
	[m_qTabEquilibriumString release];
	
	[m_mTabMScale release];
	[m_mTabCScale release];
	[m_mTabT1Scale release];
	[m_mTabT2Scale release];
	[m_mTabQScale release];
	[m_mTabEquilibriumString release];
	
	[m_cTabMScale release];
	[m_cTabCScale release];
	[m_cTabT1Scale release];
	[m_cTabT2Scale release];
	[m_cTabQScale release];
	[m_cTabEquilibriumString release];
	
	[m_tTabMScale release];
	[m_tTabCScale release];
	[m_tTabTScale release];
	[m_tTabQScale release];
	[m_tTabEquilibriumString release];

	m_qTabMScale = nil;
	m_qTabCScale = nil;
	m_qTabT1Scale = nil;
	m_qTabT2Scale = nil;
	m_qTabQScale = nil;
	m_qTabEquilibriumString = nil;
	
	m_mTabMScale = nil;
	m_mTabCScale = nil;
	m_mTabT1Scale = nil;
	m_mTabT2Scale = nil;
	m_mTabQScale = nil;
	m_mTabEquilibriumString = nil;
	
	m_cTabMScale = nil;
	m_cTabCScale = nil;
	m_cTabT1Scale = nil;
	m_cTabT2Scale = nil;
	m_cTabQScale = nil;
	m_cTabEquilibriumString = nil;
	
	m_tTabMScale = nil;
	m_tTabCScale = nil;
	m_tTabTScale = nil;
	m_tTabQScale = nil;
	m_tTabEquilibriumString = nil;
	
	[super dealloc];
}

- (IBAction)calculateQ:(id)sender
{
    /*measurement massMeas;
    massMeas.scale = [hMMenu selectedItem] tag];
    massMeas.string = [hMValue;*/
    
    double m = self.qTabMValue;
    double c = self.qTabCValue;
    double t1 = self.qTabT1Value;
    double t2 = self.qTabT2Value;
    double q;
    double deltat;
    
    m = [CBCalculator convert:m fromScale:self.qTabMScale];
    c = [CBCalculator convert:c fromScale:self.qTabCScale];
        
    t1 = [CBCalculator convert:t1 fromScale:self.qTabT1Scale];
    t2 = [CBCalculator convert:t2 fromScale:self.qTabT2Scale];

	deltat = t2 - t1;
	
    // finish up with the calculation itself
    q = m * c * deltat;
    q = [CBCalculator convert:q toScale:self.qTabQScale];
    
    self.qTabQValue = q;
    self.qTabEquilibriumString = [self equilibriumStringForDeltaT:q];
}

- (IBAction)calculateM:(id)sender
{
    double m;
    double c = self.mTabCValue;
    double t1 = self.mTabT1Value;
    double t2 = self.mTabT2Value;
    double q = self.mTabQValue;
    double deltat;
        
    q = [CBCalculator convert:q fromScale:self.mTabQScale];
    c = [CBCalculator convert:c fromScale:self.mTabCScale];
        
    t1 = [CBCalculator convert:t1 fromScale:self.mTabT1Scale];
    t2 = [CBCalculator convert:t2 fromScale:self.mTabT2Scale];
	
	deltat = t2 - t1;
	
    // finish up with the calculation itself
    m = q / (c * deltat);
    m = [CBCalculator convert:m toScale:self.mTabMScale];
    
    self.mTabMValue = m;
    self.mTabEquilibriumString = [self equilibriumStringForDeltaT:q];
}

- (IBAction)calculateC:(id)sender
{
    double m = self.cTabMValue;
    double c;
    double t1 = self.cTabT1Value;
    double t2 = self.cTabT2Value;
    double q = self.cTabQValue;
    double deltat;
    
    m = [CBCalculator convert:m fromScale:self.cTabMScale];
    q = [CBCalculator convert:q fromScale:self.cTabQScale];
        
    t1 = [CBCalculator convert:t1 fromScale:self.cTabT1Scale];
    t2 = [CBCalculator convert:t2 fromScale:self.cTabT2Scale];
	
	deltat = t2 - t1;
	
    // finish up with the calculation itself
    c = q / (m * deltat);
    c = [CBCalculator convert:c toScale:self.cTabCScale];
    
    self.cTabCValue = c;
    self.cTabEquilibriumString = [self equilibriumStringForDeltaT:q];
}

- (IBAction)calculateT:(id)sender
{
    double m = self.tTabMValue;
    double c = self.tTabCValue;
    double t;
    //NSString *t1 = self.tTabT1Value;
    //NSString *t2 = self.tTabT2Value;
    double q = self.tTabQValue;

    m = [CBCalculator convert:m fromScale:self.tTabMScale];
    c = [CBCalculator convert:c fromScale:self.tTabCScale];
    q = [CBCalculator convert:q fromScale:self.tTabQScale];

    // finish up with the calculation itself
    t = q / (m * c);
    t = [CBCalculator convert:t toScale:self.tTabTScale];

    self.tTabTValue = t;
    self.tTabEquilibriumString = [self equilibriumStringForDeltaT:q];
}

- (NSString *)equilibriumStringForDeltaT:(double)deltat
{
	NSString *string = nil;

    if (deltat < 0) string = NSLocalizedString(@"Exothermic", @"Exothermic");
    else if (deltat == 0) string = NSLocalizedString(@"Thermally stable", @"Thermally stable");
    else if (deltat > 0) string = NSLocalizedString(@"Endothermic", @"Endothermic");
	
	return string;
}

@end
