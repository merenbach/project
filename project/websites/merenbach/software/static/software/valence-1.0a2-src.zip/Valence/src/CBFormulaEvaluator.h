//
//  CBFormulaEvaluator.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/22/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBFormulaEvaluator : NSObject {
	//NSDictionary *molarMassData;
	NSString *m_formula;
}

@property (copy, readwrite) NSString *formula;

- (id)initWithFormula:(NSString *)formula;

- (NSString *)evaluate;

//- (NSDecimalNumber *)massForSymbol:(NSString *)symbol;
//- (NSDecimalNumber *)numberOfAtomsForSymbol:(NSString *)symbol;

@end
