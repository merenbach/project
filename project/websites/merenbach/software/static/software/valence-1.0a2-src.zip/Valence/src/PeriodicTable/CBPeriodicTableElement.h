//
//  CBPeriodicTableElement.h
//  Valence
//
//  Created by Andrew Merenbach on 4/9/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBPeriodicTableElement : NSObject {
	NSString *m_elementName;
	NSString *m_elementSymbol;
	NSString *m_elementNumber;
	//NSString *m_localizedName;
	NSString *m_groupName;
	NSInteger m_groupNumber;
	NSString *m_atomicMass;
	
	NSDictionary *m_tableData;
	
	// search functionality
	BOOL m_isSearchResult;
}

@property (copy, readwrite) NSString *elementName;
@property (copy, readwrite) NSString *elementSymbol;
@property (copy, readwrite) NSString *elementNumber;
@property (copy, readonly) NSString *localizedName;
@property (copy, readwrite) NSString *groupName;
@property (assign, readwrite) NSInteger groupNumber;
@property (copy, readwrite) NSString *atomicMass;
@property (copy, readwrite) NSDictionary *tableData;
@property (assign, readwrite) BOOL isSearchResult;

- (id)init;
+ (id)element;
- (void)dealloc;

@end
