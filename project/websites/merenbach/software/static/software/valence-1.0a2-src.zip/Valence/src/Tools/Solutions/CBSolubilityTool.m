#import "CBSolubilityTool.h"
#import "CBCalculator.h"

@implementation CBSolubilityTool

@synthesize solubilityTabP1Value = m_solubilityTabP1Value;
@synthesize solubilityTabP2Value = m_solubilityTabP2Value;
@synthesize solubilityTabS1Value = m_solubilityTabS1Value;
@synthesize solubilityTabS2Value = m_solubilityTabS2Value;
@synthesize pressureTabP1Value = m_pressureTabP1Value;
@synthesize pressureTabP2Value = m_pressureTabP2Value;
@synthesize pressureTabS1Value = m_pressureTabS1Value;
@synthesize pressureTabS2Value = m_pressureTabS2Value;
@synthesize solubilityTabP1Scale = m_solubilityTabP1Scale;
@synthesize solubilityTabP2Scale = m_solubilityTabP2Scale;
@synthesize pressureTabP1Scale = m_pressureTabP1Scale;
@synthesize pressureTabP2Scale = m_pressureTabP2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_solubilityTabP1Value = 0;
		m_solubilityTabP2Value = 0;
		m_solubilityTabS1Value = 0;
		m_solubilityTabS2Value = 0;
		
		m_pressureTabP1Value = 0;
		m_pressureTabP2Value = 0;
		m_pressureTabS1Value = 0;
		m_pressureTabS2Value = 0;
		
		m_solubilityTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_solubilityTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabP2Scale = [CBMeasurementScale initialPressureScale];
	}
	return self;
}

- (void)dealloc {
	[m_solubilityTabP1Scale release];
	[m_solubilityTabP1Scale release];
	[m_pressureTabP1Scale release];
	[m_pressureTabP2Scale release];
	
	m_solubilityTabP1Scale = nil;
	m_solubilityTabP1Scale = nil;
	m_pressureTabP1Scale = nil;
	m_pressureTabP2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculateSolubility:(id)sender
{
    double s1 = self.solubilityTabS1Value;
    double s2;
    double p1 = self.solubilityTabP1Value;
    double p2 = self.solubilityTabP2Value;
    
    p1 = [CBCalculator convert:p1 fromScale:self.solubilityTabP1Scale];
    p2 = [CBCalculator convert:p2 fromScale:self.solubilityTabP2Scale];

    /* finish up with the calculation itself */
    s2 = s1 * p1 / p2;

    self.solubilityTabS2Value = s2;
}

- (IBAction)calculatePressure:(id)sender
{
    double s1 = self.pressureTabS1Value;
    double s2 = self.pressureTabS2Value;
    double p1 = self.pressureTabP1Value;
    double p2;
    
    p1 = [CBCalculator convert:p1 fromScale:self.pressureTabP1Scale];
        
    /* finish up with the calculation itself */
    p2 = p1 * s1 / s2;
    p2 = [CBCalculator convert:p2 toScale:self.pressureTabP2Scale];
   
    self.pressureTabP2Value = p2;
}

@end
