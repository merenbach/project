#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;

@interface CBMolarityTool : CBToolViewController
{    
	/*IBOutlet NSTextField *molarityQuantityField;
	IBOutlet NSTextField *molarityMolarMassField;
	IBOutlet NSTextField *molarityVolumeField;
	IBOutlet NSTextField *molarityMolarityField;
	
	IBOutlet CBScalePopUpButton *molarityQuantityMenu;
	IBOutlet CBScalePopUpButton *molarityVolumeMenu;
		
	IBOutlet NSTextField *volumeQuantityField;
	IBOutlet NSTextField *volumeMolarMassField;
	IBOutlet NSTextField *volumeVolumeField;
	IBOutlet NSTextField *volumeMolarityField;
	
	IBOutlet CBScalePopUpButton *volumeQuantityMenu;
	IBOutlet CBScalePopUpButton *volumeVolumeMenu;
	
	IBOutlet NSTextField *quantityQuantityField;
	IBOutlet NSTextField *quantityMolarMassField;
	IBOutlet NSTextField *quantityVolumeField;
	IBOutlet NSTextField *quantityMolarityField;
	
	IBOutlet CBScalePopUpButton *quantityQuantityMenu;
	IBOutlet CBScalePopUpButton *quantityVolumeMenu;*/
	
	double m_molarityTabQuantityValue;
	double m_molarityTabMolarMassValue;
	double m_molarityTabVolumeValue;
	double m_molarityTabMolarityValue;
	
	double m_volumeTabQuantityValue;
	double m_volumeTabMolarMassValue;
	double m_volumeTabVolumeValue;
	double m_volumeTabMolarityValue;
	
	double m_quantityTabQuantityValue;
	double m_quantityTabMolarMassValue;
	double m_quantityTabVolumeValue;
	double m_quantityTabMolarityValue;

	CBMeasurementScale *m_molarityTabQuantityScale;
	CBMeasurementScale *m_molarityTabVolumeScale;
	CBMeasurementScale *m_volumeTabQuantityScale;
	CBMeasurementScale *m_volumeTabVolumeScale;
	CBMeasurementScale *m_quantityTabQuantityScale;
	CBMeasurementScale *m_quantityTabVolumeScale;
}

@property (assign, readwrite) double molarityTabQuantityValue;
@property (assign, readwrite) double molarityTabMolarMassValue;
@property (assign, readwrite) double molarityTabVolumeValue;
@property (assign, readwrite) double molarityTabMolarityValue;
@property (assign, readwrite) double volumeTabQuantityValue;
@property (assign, readwrite) double volumeTabMolarMassValue;
@property (assign, readwrite) double volumeTabVolumeValue;
@property (assign, readwrite) double volumeTabMolarityValue;
@property (assign, readwrite) double quantityTabQuantityValue;
@property (assign, readwrite) double quantityTabMolarMassValue;
@property (assign, readwrite) double quantityTabVolumeValue;
@property (assign, readwrite) double quantityTabMolarityValue;
@property (retain, readwrite) CBMeasurementScale *molarityTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *molarityTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *volumeTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *volumeTabVolumeScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *quantityTabVolumeScale;

- (IBAction)calculateSolutionMolarity:(id)sender;
- (IBAction)calculateSolutionVolume:(id)sender;
- (IBAction)calculateSoluteQuantity:(id)sender;

@end
