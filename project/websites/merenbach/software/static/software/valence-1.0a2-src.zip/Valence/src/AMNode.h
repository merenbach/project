//
//  AMNode.h
//  DiceX
//
//  Created by Andrew Merenbach on 24/11/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AMNode : NSObject {
	NSString *m_title;
	NSArray *m_children;
	id m_representedObject;
}

@property (copy, readwrite) NSString *title;
@property (copy, readwrite) NSArray *children;
@property (retain, readwrite) id representedObject;

- (NSComparisonResult)localizedCompare:(AMNode *)otherNode;

@end
