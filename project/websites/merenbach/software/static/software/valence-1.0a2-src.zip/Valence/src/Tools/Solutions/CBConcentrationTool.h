#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@interface CBConcentrationTool : CBToolViewController
{
	double m_solventMassTabSoluteMass;
	double m_solventMassTabSoluteSolubility;
	double m_solventMassTabSolventMass;
	
	double m_soluteMassTabSoluteMass;
	double m_soluteMassTabSoluteSolubility;
	double m_soluteMassTabSolventMass;
	
	double m_soluteSolubilityTabSoluteMass;
	double m_soluteSolubilityTabSoluteSolubility;
	double m_soluteSolubilityTabSolventMass;
}

@property (assign, readwrite) double solventMassTabSoluteMass;
@property (assign, readwrite) double solventMassTabSoluteSolubility;
@property (assign, readwrite) double solventMassTabSolventMass;

@property (assign, readwrite) double soluteMassTabSoluteMass;
@property (assign, readwrite) double soluteMassTabSoluteSolubility;
@property (assign, readwrite) double soluteMassTabSolventMass;

@property (assign, readwrite) double soluteSolubilityTabSoluteMass;
@property (assign, readwrite) double soluteSolubilityTabSoluteSolubility;
@property (assign, readwrite) double soluteSolubilityTabSolventMass;

- (IBAction)calculateSolventMass:(id)sender;
- (IBAction)calculateSoluteMass:(id)sender;
- (IBAction)calculateSoluteSolubility:(id)sender;

@end
