//
//  CBPeriodicTableInspectorWindow.m
//  Valence
//
//  Created by Andrew Merenbach on 4/10/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableInspectorWindow.h"

#define CB_PERIODIC_TABLE_INSPECTOR_ALPHA 0.75


@implementation CBPeriodicTableInspectorWindow

- (id)initWithContentRect:(NSRect)contentRect styleMask:(NSUInteger)windowStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)deferCreation {
	NSUInteger modifiedWindowStyle = windowStyle & NSBorderlessWindowMask;
	self = [super initWithContentRect:contentRect styleMask:modifiedWindowStyle backing:bufferingType defer:deferCreation];
	if (self != nil) {
		[self setMovableByWindowBackground:YES];
		[self setAlphaValue:CB_PERIODIC_TABLE_INSPECTOR_ALPHA];
	}
	return self;
}

- (BOOL)canBecomeKeyWindow {
	return NO;
}

// this is more of a sanity-check than anything else;
// the window is (as of 4/10/2010) filled with a text view,
// which blocks out any other clicks that this might catch
- (void)mouseDown:(NSEvent *)theEvent {
	[[self delegate] close];
}

@end

@implementation CBPeriodicTableInspectorTextDisplay

@synthesize mouseDraggedFlag = m_mouseDraggedFlag;

- (void)mouseDown:(id)sender {
	self.mouseDraggedFlag = NO;
}

- (void)mouseUp:(id)sender {
	if (self.mouseDraggedFlag == NO) {
		[[self delegate] close];	// close the inspector
	}
}

- (void)mouseDragged:(id)sender {
	self.mouseDraggedFlag = YES;
}

@end