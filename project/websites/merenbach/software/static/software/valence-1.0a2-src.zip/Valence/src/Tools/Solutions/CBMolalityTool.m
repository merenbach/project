#import "CBMolalityTool.h"
#import "CBCalculator.h"
#import "CBScalePopUpButton.h"


@implementation CBMolalityTool

@synthesize molalityTabQuantityValue = m_molalityTabQuantityValue;
@synthesize molalityTabMolarMassValue = m_molalityTabMolarMassValue;
@synthesize molalityTabMassValue = m_molalityTabMassValue;
@synthesize molalityTabMolalityValue = m_molalityTabMolalityValue;

@synthesize massTabQuantityValue = m_massTabQuantityValue;
@synthesize massTabMolarMassValue = m_massTabMolarMassValue;
@synthesize massTabMassValue = m_massTabMassValue;
@synthesize massTabMolalityValue = m_massTabMolalityValue;

@synthesize quantityTabQuantityValue = m_quantityTabQuantityValue;
@synthesize quantityTabMolarMassValue = m_quantityTabMolarMassValue;
@synthesize quantityTabMassValue = m_quantityTabMassValue;
@synthesize quantityTabMolalityValue = m_quantityTabMolalityValue;

@synthesize molalityTabQuantityScale = m_molalityTabQuantityScale;
@synthesize molalityTabMassScale = m_molalityTabMassScale;
@synthesize massTabQuantityScale = m_massTabQuantityScale;
@synthesize massTabMassScale = m_massTabMassScale;
@synthesize quantityTabQuantityScale = m_quantityTabQuantityScale;
@synthesize quantityTabMassScale = m_quantityTabMassScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_molalityTabQuantityValue = 0;
		m_molalityTabMolarMassValue = 0;
		m_molalityTabMassValue = 0;
		m_molalityTabMolalityValue = 0;
		
		m_massTabQuantityValue = 0;
		m_massTabMolarMassValue = 0;
		m_massTabMassValue = 0;
		m_massTabMolalityValue = 0;
		
		m_quantityTabQuantityValue = 0;
		m_quantityTabMolarMassValue = 0;
		m_quantityTabMassValue = 0;
		m_quantityTabMolalityValue = 0;
		
		m_molalityTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_molalityTabMassScale = [CBMeasurementScale initialMassScale];
		m_massTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_massTabMassScale = [CBMeasurementScale initialMassScale];
		m_quantityTabQuantityScale = [CBMeasurementScale initialMassMolesScale];
		m_quantityTabMassScale = [CBMeasurementScale initialMassScale];
	}
	return self;
}

- (void)dealloc {
	[m_molalityTabQuantityScale release];
	[m_molalityTabMassScale release];
	[m_massTabQuantityScale release];
	[m_massTabMassScale release];
	[m_quantityTabQuantityScale release];
	[m_quantityTabMassScale release];
	
	m_molalityTabQuantityScale = nil;
	m_molalityTabMassScale = nil;
	m_massTabQuantityScale = nil;
	m_massTabMassScale = nil;
	m_quantityTabQuantityScale = nil;
	m_quantityTabMassScale = nil;
	
	[super dealloc];
}

- (IBAction)calculateSolventMolality:(id)sender
{
	double q = self.molalityTabQuantityValue;
	double mm = self.molalityTabMolarMassValue;
	double mass = self.molalityTabMassValue;
	double molality;

	q = [CBCalculator convert:q fromScale:self.molalityTabQuantityScale molarMass:mm];
	mass = [CBCalculator convert:mass fromScale:self.molalityTabMassScale];
		
	// finish up with the calculation itself
	molality = q / mass;
	
	self.molalityTabMolalityValue = molality;
}

- (IBAction)calculateSolventMass:(id)sender
{
	double q = self.massTabQuantityValue;
	double mm = self.massTabMolarMassValue;
	double mass;
	double molality = self.massTabMolalityValue;
	
	q = [CBCalculator convert:q fromScale:self.massTabQuantityScale molarMass:mm];
	
	// finish up with the calculation itself
	mass = q / molality;
	mass = [CBCalculator convert:mass toScale:self.massTabMassScale];
	
	self.massTabMassValue = mass;
}

- (IBAction)calculateSoluteQuantity:(id)sender
{
	double q;
	double mm = self.quantityTabMolarMassValue;
	double mass = self.quantityTabMassValue;
	double molality = self.quantityTabMolalityValue;

	mass = [CBCalculator convert:mass fromScale:self.quantityTabMassScale];

	// finish up with the calculation itself
	q = mass * molality;
	q = [CBCalculator convert:q toScale:self.quantityTabQuantityScale molarMass:mm]; 
	
	self.quantityTabQuantityValue = q;
}

@end
