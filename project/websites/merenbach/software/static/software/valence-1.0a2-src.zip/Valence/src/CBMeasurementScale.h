//
//  CBMeasurementScale.h
//  Valence
//
//  Created by Andrew Merenbach on 4/8/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBMeasurementScale : NSObject
{
	NSString *m_title;
	//NSString *m_localizedTitle;
	NSString *m_scaleType;
	NSString *m_scaleCategory;
	BOOL m_isMolarScale;
}

@property (copy, readwrite) NSString *title;
@property (copy, readonly) NSString *localizedTitle;
@property (copy, readwrite) NSString *scaleType;
@property (copy, readwrite) NSString *scaleCategory;
@property (assign, readwrite) BOOL isMolarScale;

+ (void)initialize;
- (id)init;
+ (id)scale;
- (void)dealloc;

- (NSString *)localizedTitle;

+ (NSArray *)pressureScales;
+ (NSArray *)volumeScales;
+ (NSArray *)temperatureScales;
+ (NSArray *)heatScales;
+ (NSArray *)massScales;
+ (NSArray *)molesScales;
+ (NSArray *)massMolesScales;

- (NSArray *)scalesForPressure;
- (NSArray *)scalesForVolume;
- (NSArray *)scalesForTemperature;
- (NSArray *)scalesForHeat;
- (NSArray *)scalesForMass;
- (NSArray *)scalesForMoles;
- (NSArray *)scalesForMassMoles;

+ (CBMeasurementScale *)initialPressureScale;
+ (CBMeasurementScale *)initialVolumeScale;
+ (CBMeasurementScale *)initialTemperatureScale;
+ (CBMeasurementScale *)initialHeatScale;
+ (CBMeasurementScale *)initialMassScale;
+ (CBMeasurementScale *)initialMolesScale;
+ (CBMeasurementScale *)initialMassMolesScale;

@end
