//
//  CBPeriodicTableElement.m
//  Valence
//
//  Created by Andrew Merenbach on 4/9/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableElement.h"


@implementation CBPeriodicTableElement

@synthesize elementName = m_elementName;
@synthesize elementSymbol = m_elementSymbol;
@synthesize elementNumber = m_elementNumber;
//@synthesize localizedName = m_localizedName;
@dynamic localizedName;
@synthesize groupName = m_groupName;
@synthesize groupNumber = m_groupNumber;
@synthesize atomicMass = m_atomicMass;
@synthesize tableData = m_tableData;
@synthesize isSearchResult = m_isSearchResult;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_elementName = [[NSString alloc] initWithString:@""];
		m_elementSymbol = [[NSString alloc] initWithString:@""];
		m_elementNumber = [[NSString alloc] initWithString:@""];
		m_groupName = [[NSString alloc] initWithString:@""];
		m_groupNumber = 0;
		m_atomicMass = [[NSString alloc] initWithString:@""];
		m_tableData = nil;
		m_isSearchResult = NO;
	}
	return self;
}

+ (id)element {
	return [[[[self class] alloc] init] autorelease];	
}

- (void)dealloc {
	[m_elementName release];
	[m_elementSymbol release];
	[m_elementNumber release];
	[m_groupName release];
	[m_atomicMass release];
	[m_tableData release];
	
	m_elementName = nil;
	m_elementSymbol = nil;
	m_elementNumber = nil;
	m_groupName = nil;
	m_atomicMass = nil;
	m_tableData = nil;
	
	[super dealloc];
}

- (NSString *)localizedName {
	return NSLocalizedStringFromTable(self.elementName, @"PeriodicTable", self.elementName);	
}

@end
