#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBMolesTool : CBToolViewController {
	double m_molesTabSampleMassValue;
	double m_molesTabQuantityValue;
	double m_massTabSampleMassValue;
	double m_massTabQuantityValue;
	double m_molesTabMolarMassValue;
	double m_massTabMolarMassValue;
	CBMeasurementScale *m_molesTabSampleMassScale;
	CBMeasurementScale *m_molesTabQuantityScale;
	CBMeasurementScale *m_massTabSampleMassScale;
	CBMeasurementScale *m_massTabQuantityScale;
}

@property (assign, readwrite) double molesTabSampleMassValue;
@property (assign, readwrite) double molesTabQuantityValue;
@property (assign, readwrite) double massTabSampleMassValue;
@property (assign, readwrite) double massTabQuantityValue;
@property (assign, readwrite) double molesTabMolarMassValue;
@property (assign, readwrite) double massTabMolarMassValue;
@property (retain, readwrite) CBMeasurementScale *molesTabSampleMassScale;
@property (retain, readwrite) CBMeasurementScale *molesTabQuantityScale;
@property (retain, readwrite) CBMeasurementScale *massTabSampleMassScale;
@property (retain, readwrite) CBMeasurementScale *massTabQuantityScale;

- (IBAction)calculateMoles:(id)sender;
- (IBAction)calculateMass:(id)sender;

@end
