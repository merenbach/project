//
//  CBScalePopUpButtonCategories.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/25/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CBScalePopUpButton.h"

@interface CBHeatPopUpButton : CBScalePopUpButton {}
@end

@interface CBPressurePopUpButton : CBScalePopUpButton {}
@end

@interface CBTemperaturePopUpButton : CBScalePopUpButton {}
@end

@interface CBVolumePopUpButton : CBScalePopUpButton {}
@end

@interface CBMassPopUpButton : CBScalePopUpButton {}
@end

@interface CBMolesPopUpButton : CBScalePopUpButton {}
@end

@interface CBMassMolesPopUpButton : CBScalePopUpButton {}
@end


@interface CBHeatPopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBPressurePopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBTemperaturePopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBVolumePopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBMassPopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBMolesPopUpButtonCell : CBScalePopUpButtonCell {}
@end

@interface CBMassMolesPopUpButtonCell : CBScalePopUpButtonCell {}
@end

