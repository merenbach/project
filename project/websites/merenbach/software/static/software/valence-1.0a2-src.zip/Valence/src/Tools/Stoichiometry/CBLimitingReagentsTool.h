/* Tool */

#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

typedef enum _CBLimitingReagentsQuantityType {
	CBLimitingReagentsQuantityIsMoles = 1,
	CBLimitingReagentsQuantityIsMass = 2,
} CBLimitingReagentsQuantityType;

@class CBScalePopUpButton;
@class CBMeasurementScale;

@interface CBLimitingReagentsTool : CBToolViewController
{    
	NSMatrix *m_reactant1QuantityRadioButtons;
	NSMatrix *m_reactant2QuantityRadioButtons;

	NSInteger m_reactant1UnitTypeTag;
	NSInteger m_reactant2UnitTypeTag;
	BOOL m_reactant1UsesMoles;
	BOOL m_reactant1UsesMass;
	BOOL m_reactant2UsesMoles;
	BOOL m_reactant2UsesMass;
	
	NSString *m_reactant1Name;		// input
	NSString *m_reactant2Name;		// input
	double m_reactant1MolesValue;	// input
	double m_reactant1MassValue;	// input
	double m_reactant2MolesValue;	// input
	double m_reactant2MassValue;	// input
	double m_reactant1MolarMass;	// input
	double m_reactant2MolarMass;	// input
	double m_productMolarMass;		// input
	NSInteger m_reactant1Coefficient;	// input
	NSInteger m_reactant2Coefficient;	// input
	NSInteger m_productCoefficient;		// input
	
	NSString *m_limitingReagentName;	// output
	NSString *m_excessReagentName;		// output
	double m_productMolesValue;	// output
	double m_productMassValue;	// output
	double m_limitingReagentMolesUsedValue;	// output
	double m_limitingReagentMassUsedValue;	// output
	double m_excessReagentMolesUsedValue;	// output
	double m_excessReagentMassUsedValue;	// output
	double m_excessReagentMolesLeftValue;	// output
	double m_excessReagentMassLeftValue;	// output
	
	CBMeasurementScale *m_reactant1MolesScale;	// input
	CBMeasurementScale *m_reactant1MassScale;	// input
	CBMeasurementScale *m_reactant2MolesScale;	// input
	CBMeasurementScale *m_reactant2MassScale;	// input
	CBMeasurementScale *m_productMolesScale;	// output
	CBMeasurementScale *m_productMassScale;		// output
	CBMeasurementScale *m_limitingReagentMolesUsedScale;	// output
	CBMeasurementScale *m_limitingReagentMassUsedScale;		// output
	CBMeasurementScale *m_excessReagentMolesUsedScale;		// output
	CBMeasurementScale *m_excessReagentMassUsedScale;		// output
	CBMeasurementScale *m_excessReagentMolesLeftScale;	// output
	CBMeasurementScale *m_excessReagentMassLeftScale;	// output
}

@property (assign) IBOutlet NSMatrix *reactant1QuantityRadioButtons;
@property (assign) IBOutlet NSMatrix *reactant2QuantityRadioButtons;

@property (assign, readwrite) NSInteger reactant1UnitTypeTag;
@property (assign, readwrite) NSInteger reactant2UnitTypeTag;
@property (assign, readwrite) BOOL reactant1UsesMoles;
@property (assign, readwrite) BOOL reactant1UsesMass;
@property (assign, readwrite) BOOL reactant2UsesMoles;
@property (assign, readwrite) BOOL reactant2UsesMass;

@property (copy, readwrite) NSString *reactant1Name;		// input
@property (copy, readwrite) NSString *reactant2Name;		// input
@property (assign, readwrite) double reactant1MolesValue;	// input
@property (assign, readwrite) double reactant1MassValue;	// input
@property (assign, readwrite) double reactant2MolesValue;	// input
@property (assign, readwrite) double reactant2MassValue;	// input
@property (assign, readwrite) double reactant1MolarMass;	// input
@property (assign, readwrite) double reactant2MolarMass;	// input
@property (assign, readwrite) double productMolarMass;		// input
@property (assign, readwrite) NSInteger reactant1Coefficient;	// input
@property (assign, readwrite) NSInteger reactant2Coefficient;	// input
@property (assign, readwrite) NSInteger productCoefficient;		// input

@property (copy, readwrite) NSString *limitingReagentName;	// output
@property (copy, readwrite) NSString *excessReagentName;		// output
@property (assign, readwrite) double productMolesValue;	// output
@property (assign, readwrite) double productMassValue;	// output
@property (assign, readwrite) double limitingReagentMolesUsedValue;	// output
@property (assign, readwrite) double limitingReagentMassUsedValue;	// output
@property (assign, readwrite) double excessReagentMolesUsedValue;	// output
@property (assign, readwrite) double excessReagentMassUsedValue;	// output
@property (assign, readwrite) double excessReagentMolesLeftValue;	// output
@property (assign, readwrite) double excessReagentMassLeftValue;	// output

@property (retain, readwrite) CBMeasurementScale *reactant1MolesScale;
@property (retain, readwrite) CBMeasurementScale *reactant1MassScale;
@property (retain, readwrite) CBMeasurementScale *reactant2MolesScale;
@property (retain, readwrite) CBMeasurementScale *reactant2MassScale;
@property (retain, readwrite) CBMeasurementScale *productMolesScale;
@property (retain, readwrite) CBMeasurementScale *productMassScale;
@property (retain, readwrite) CBMeasurementScale *limitingReagentMolesUsedScale;
@property (retain, readwrite) CBMeasurementScale *limitingReagentMassUsedScale;
@property (retain, readwrite) CBMeasurementScale *excessReagentMolesUsedScale;
@property (retain, readwrite) CBMeasurementScale *excessReagentMassUsedScale;
@property (retain, readwrite) CBMeasurementScale *excessReagentMolesLeftScale;
@property (retain, readwrite) CBMeasurementScale *excessReagentMassLeftScale;

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
- (void)updateInputFieldAvailability:(id)sender;
- (IBAction)calculate:(id)sender;

@end
