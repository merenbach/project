#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBHeatTool : CBToolViewController {
	double m_fromValue;
	double m_toValue;
	CBMeasurementScale *m_fromScale;
	CBMeasurementScale *m_toScale;
	NSString *m_resultScaleString;
}

@property (assign, readwrite) double fromValue;
@property (assign, readwrite) double toValue;
@property (retain, readwrite) CBMeasurementScale *fromScale;
@property (retain, readwrite) CBMeasurementScale *toScale;
@property (copy, readwrite) NSString *resultScaleString;

- (IBAction)calculate:(id)sender;

@end
