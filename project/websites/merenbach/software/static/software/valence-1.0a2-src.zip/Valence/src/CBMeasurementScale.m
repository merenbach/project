//
//  CBMeasurementScale.m
//  Valence
//
//  Created by Andrew Merenbach on 4/8/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMeasurementScale.h"
#import "CBScalePopUpButton.h"


static NSDictionary *originalScaleDict = nil;
static NSDictionary *scaleDict = nil;

@implementation CBMeasurementScale

@synthesize title = m_title;
@dynamic localizedTitle;
//@synthesize localizedTitle = m_localizedTitle;
@synthesize scaleType = m_scaleType;
@synthesize scaleCategory = m_scaleCategory;
@synthesize isMolarScale = m_isMolarScale;

+ (void)initialize {
	//NSValueTransformer *vt = [[[CBPopUpButtonMolarScaleSelectedVT alloc] init] autorelease];
	//[NSValueTransformer setValueTransformer:vt forName:@"CBPopUpButtonMolarScaleSelected"];
	
	if (!originalScaleDict) {
		NSBundle *bundle = [NSBundle mainBundle];
		NSString *path = [bundle pathForResource:@"Scales" ofType:@"plist"];
		originalScaleDict = [[NSDictionary alloc] initWithContentsOfFile:path];
		
		NSArray *dictKeys = [originalScaleDict allKeys];
		NSMutableDictionary *scaleDictTemp = [NSMutableDictionary dictionary];
		
		for (id key in dictKeys) {
			NSArray *scaleSubarray = [originalScaleDict objectForKey:key];
			NSMutableArray *array = [NSMutableArray array];
			for (NSDictionary *item in scaleSubarray) {
				CBMeasurementScale *scale = [CBMeasurementScale scale];
				NSString *title = [item objectForKey:@"title"];
				scale.title = title;
				//scale.localizedTitle = NSLocalizedString(title, title);
				scale.scaleType = [item objectForKey:@"type"];
				scale.scaleCategory = [item objectForKey:@"category"];
				scale.isMolarScale = [[item objectForKey:@"isMolarScale"] boolValue];
				[array addObject:scale];
			}
			[scaleDictTemp setObject:array forKey:key];
		}
		scaleDict = [scaleDictTemp copy];
	}
}

- (id)init {
	self = [super init];
	if (self != nil) {
		m_title = [[NSString alloc] initWithString:@""];
		//m_localizedTitle = [[NSString alloc] initWithString:@""];
		m_scaleType = [[NSString alloc] initWithString:@""];
		m_scaleCategory = [[NSString alloc] initWithString:@""];
		m_isMolarScale = NO;
	}
	return self;
}

+ (id)scale {
	return [[[[self class] alloc] init] autorelease];
}

- (void)dealloc {
	[m_title release];
	m_title = nil;
	
	//[m_localizedTitle release];
	//m_localizedTitle = nil;
	
	[m_scaleType release];
	m_scaleType = nil;
	
	[m_scaleCategory release];
	m_scaleCategory = nil;
	
	[super dealloc];
}

- (NSString *)localizedTitle {
	return NSLocalizedStringFromTable(self.title, @"Scales", self.title);
}


+ (NSArray *)pressureScales {
	return [scaleDict objectForKey:CBScalePressureKey];
}

+ (NSArray *)volumeScales {
	return [scaleDict objectForKey:CBScaleVolumeKey];
}

+ (NSArray *)temperatureScales {
	return [scaleDict objectForKey:CBScaleTemperatureKey];
}

+ (NSArray *)heatScales {
	return [scaleDict objectForKey:CBScaleHeatKey];
}

+ (NSArray *)massScales {
	return [scaleDict objectForKey:CBScaleMassKey];
}

+ (NSArray *)molesScales {
	return [scaleDict objectForKey:CBScaleMolesKey];
}

+ (NSArray *)massMolesScales {
	return [scaleDict objectForKey:CBScaleMassMolesKey];
}

- (NSArray *)scalesForPressure {
	return [[self class] pressureScales];
}

- (NSArray *)scalesForVolume {
	return [[self class] volumeScales];
}

- (NSArray *)scalesForTemperature {
	return [[self class] temperatureScales];
}

- (NSArray *)scalesForHeat {
	return [[self class] heatScales];
}

- (NSArray *)scalesForMass {
	return [[self class] massScales];
}

- (NSArray *)scalesForMoles {
	return [[self class] molesScales];
}

- (NSArray *)scalesForMassMoles {
	return [[self class] massMolesScales];
}

+ (CBMeasurementScale *)initialPressureScale {
	return [[[self class] pressureScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialVolumeScale {
	return [[[self class] volumeScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialTemperatureScale {
	return [[[self class] temperatureScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialHeatScale {
	return [[[self class] heatScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialMassScale {
	return [[[self class] massScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialMolesScale {
	return [[[self class] molesScales] objectAtIndex:0];
}

+ (CBMeasurementScale *)initialMassMolesScale {
	return [[[self class] massMolesScales] objectAtIndex:0];
}

@end
