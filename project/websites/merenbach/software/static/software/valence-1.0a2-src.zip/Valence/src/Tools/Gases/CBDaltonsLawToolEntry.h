//
//  CBDaltonsLawToolEntry.h
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CBMeasurementScale;


@interface CBDaltonsLawToolEntry : NSObject <NSCopying> {
	NSString *m_gasName;
	double m_pressureValue;
	CBMeasurementScale *m_gasScale;
}

@property (copy, readwrite) NSString *gasName;
@property (assign, readwrite) double pressureValue;
@property (retain, readwrite) CBMeasurementScale *gasScale;

+ (NSArray *)copyKeys;
- (id)init;
- (void)dealloc;
- (id)copyWithZone:(NSZone *)zone;
- (NSDictionary *)dictionaryRepresentation;

@end