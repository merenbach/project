//
//  CBPTLegendButtonCell.h
//  PeriodicTableModule
//
//  Created by Andrew Merenbach on 04/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBPeriodicTableLegendCell : NSCell {
	//NSColor *AM_backgroundColor;
}

/*- (NSColor *)backgroundColor;
- (void)setBackgroundColor:(NSColor *)aColor;*/

@end
