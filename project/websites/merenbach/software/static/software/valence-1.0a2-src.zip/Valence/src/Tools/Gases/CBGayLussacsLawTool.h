#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class CBMeasurementScale;


@interface CBGayLussacsLawTool : CBToolViewController
{    
	double m_pressureTabP1Value;
	double m_pressureTabP2Value;
	double m_pressureTabT1Value;
	double m_pressureTabT2Value;
	
	double m_temperatureTabP1Value;
	double m_temperatureTabP2Value;
	double m_temperatureTabT1Value;
	double m_temperatureTabT2Value;
	
	CBMeasurementScale *m_pressureTabP1Scale;
	CBMeasurementScale *m_pressureTabP2Scale;
	CBMeasurementScale *m_pressureTabT1Scale;
	CBMeasurementScale *m_pressureTabT2Scale;
		
	CBMeasurementScale *m_temperatureTabP1Scale;
	CBMeasurementScale *m_temperatureTabP2Scale;
	CBMeasurementScale *m_temperatureTabT1Scale;
	CBMeasurementScale *m_temperatureTabT2Scale;	
}

@property (assign, readwrite) double pressureTabP1Value;
@property (assign, readwrite) double pressureTabP2Value;
@property (assign, readwrite) double pressureTabT1Value;
@property (assign, readwrite) double pressureTabT2Value;

@property (assign, readwrite) double temperatureTabP1Value;
@property (assign, readwrite) double temperatureTabP2Value;
@property (assign, readwrite) double temperatureTabT1Value;
@property (assign, readwrite) double temperatureTabT2Value;

@property (retain, readwrite) CBMeasurementScale *pressureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *pressureTabT2Scale;

@property (retain, readwrite) CBMeasurementScale *temperatureTabP1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabP2Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT1Scale;
@property (retain, readwrite) CBMeasurementScale *temperatureTabT2Scale;

- (IBAction)calculatePressure:(id)sender;
- (IBAction)calculateTemperature:(id)sender;

@end
