#import "CBGayLussacsLawTool.h"
#import "CBCalculator.h"

@implementation CBGayLussacsLawTool

@synthesize pressureTabP1Value = m_pressureTabP1Value;
@synthesize pressureTabP2Value = m_pressureTabP2Value;
@synthesize pressureTabT1Value = m_pressureTabT1Value;
@synthesize pressureTabT2Value = m_pressureTabT2Value;

@synthesize temperatureTabP1Value = m_temperatureTabP1Value;
@synthesize temperatureTabP2Value = m_temperatureTabP2Value;
@synthesize temperatureTabT1Value = m_temperatureTabT1Value;
@synthesize temperatureTabT2Value = m_temperatureTabT2Value;

@synthesize pressureTabP1Scale = m_pressureTabP1Scale;
@synthesize pressureTabP2Scale = m_pressureTabP2Scale;
@synthesize pressureTabT1Scale = m_pressureTabT1Scale;
@synthesize pressureTabT2Scale = m_pressureTabT2Scale;

@synthesize temperatureTabP1Scale = m_temperatureTabP1Scale;
@synthesize temperatureTabP2Scale = m_temperatureTabP2Scale;
@synthesize temperatureTabT1Scale = m_temperatureTabT1Scale;
@synthesize temperatureTabT2Scale = m_temperatureTabT2Scale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_pressureTabP1Value = 0;
		m_pressureTabP2Value = 0;
		m_pressureTabT1Value = 0;
		m_pressureTabT2Value = 0;
				
		m_temperatureTabP1Value = 0;
		m_temperatureTabP2Value = 0;
		m_temperatureTabT1Value = 0;
		m_temperatureTabT2Value = 0;
		
		m_pressureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_pressureTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_pressureTabT2Scale = [CBMeasurementScale initialTemperatureScale];
		
		m_temperatureTabP1Scale = [CBMeasurementScale initialPressureScale];
		m_temperatureTabP2Scale = [CBMeasurementScale initialPressureScale];
		m_temperatureTabT1Scale = [CBMeasurementScale initialTemperatureScale];
		m_temperatureTabT2Scale = [CBMeasurementScale initialTemperatureScale];		
	}
	return self;
}

- (void)dealloc {
	[m_pressureTabP1Scale release];
	[m_pressureTabP2Scale release];
	[m_pressureTabT1Scale release];
	[m_pressureTabT2Scale release];
	
	m_pressureTabP1Scale = nil;
	m_pressureTabP2Scale = nil;
	m_pressureTabT1Scale = nil;
	m_pressureTabT2Scale = nil;
	
	[m_temperatureTabP1Scale release];
	[m_temperatureTabP2Scale release];
	[m_temperatureTabT1Scale release];
	[m_temperatureTabT2Scale release];
	
	m_temperatureTabP1Scale = nil;
	m_temperatureTabP2Scale = nil;
	m_temperatureTabT1Scale = nil;
	m_temperatureTabT2Scale = nil;
	
	[super dealloc];
}

- (IBAction)calculatePressure:(id)sender
{
    double p1 = self.pressureTabP1Value;
    double p2;
    double t1 = self.pressureTabT1Value;
    double t2 = self.pressureTabT2Value;
    
    p1 = [CBCalculator convert:p1 fromScale:self.pressureTabP1Scale];
    t1 = [CBCalculator convert:t1 fromScale:self.pressureTabT1Scale];
    t2 = [CBCalculator convert:t2 fromScale:self.pressureTabT2Scale];
       
    /* finish up with the calculation itself */
    p2 = p1 * t2 / t1;
    p2 = [CBCalculator convert:p2 toScale:self.pressureTabP2Scale];

    self.pressureTabP2Value = p2;
}

- (IBAction)calculateTemperature:(id)sender
{
    double p1 = self.temperatureTabP1Value;
	double p2 = self.temperatureTabP2Value;
	double t1 = self.temperatureTabT1Value;
    double t2;
    
    p1 = [CBCalculator convert:p1 fromScale:self.temperatureTabP1Scale];
    t1 = [CBCalculator convert:t1 fromScale:self.temperatureTabT1Scale];
    p2 = [CBCalculator convert:p2 fromScale:self.temperatureTabP2Scale];
        
    t2 = p2 * t1 / p1;
    t2 = [CBCalculator convert:t2 toScale:self.temperatureTabT2Scale];

    self.temperatureTabT2Value = t2;
}

@end
