//
//  CBPeriodicTableInspectorWindowController.m
//  Elemental
//
//  Created by Andrew Merenbach on 25/10/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "CBPeriodicTableInspectorWindowController.h"

@implementation CBPeriodicTableInspectorWindowController

@synthesize elementDescription = m_elementDescription;

- (id)init {
	self = [super initWithWindowNibName:@"PeriodicTableInspectorWindow"];
	if (self != nil) {
		m_elementDescription = [[NSString alloc] init];
	}
	return self;
}

- (void)dealloc {
	[m_elementDescription release];
	m_elementDescription = nil;

	[super dealloc];
}

- (void)windowDidLoad {
	NSPanel *window = (NSPanel *)self.window;
	[window setFloatingPanel:YES];	
}

/*- (void)close {
	[self.window setParentWindow:nil];
	[super close];
}*/

/*- (void)hideWindow:(id)sender {
	//[self.window orderOut:nil];
}*/

@end
