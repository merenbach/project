//
//  CBMoleFractionsToolResult.m
//  Valence
//
//  Created by Andrew Merenbach on 4/6/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "CBMoleFractionsToolResult.h"


@implementation CBMoleFractionsToolResult

@synthesize fractionalPart = m_fractionalPart;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_fractionalPart = 0;
	}
	return self;
}

- (id)copyWithZone:(NSZone *)zone {
	CBMoleFractionsToolResult *copy = [super copyWithZone:zone];
	copy.fractionalPart = self.fractionalPart;
	return copy;
}

@end
