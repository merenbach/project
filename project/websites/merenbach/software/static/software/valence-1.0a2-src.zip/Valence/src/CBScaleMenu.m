//
//  CBScaleMenu.m
//  Valence
//
//  Created by Andrew Merenbach on 4/4/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

// credit to Matt Neuburg: http://www.cocoabuilder.com/archive/cocoa/275031-nspopupbutton-bindings-separator-items.html?q=nspopupbutton+bindings+separator#275053

#import "CBScaleMenu.h"
#define MYMENUSEPARATORSTRING @"-"

@implementation CBScaleMenu

- (NSMenuItem *)insertItemWithTitle:(NSString *)aString action:(SEL)aSelector keyEquivalent:(NSString *)charCode atIndex:(NSInteger)index {
	id item = nil;
    if ([aString isEqual: MYMENUSEPARATORSTRING]) {
        NSMenuItem *sep = [NSMenuItem separatorItem];
        [super insertItem:sep atIndex:index];
        item = sep;
    } else {
		item = [super insertItemWithTitle:aString action:aSelector keyEquivalent:charCode atIndex:index];
	}
	return item;
}

- (NSMenuItem *)addItemWithTitle:(NSString *)aString action:(SEL)aSelector keyEquivalent:(NSString *)keyEquiv {
	id item = nil;
    if ([aString isEqual: MYMENUSEPARATORSTRING]) {
        NSMenuItem *sep = [NSMenuItem separatorItem];
        [self addItem:sep];
        item = sep;
    } else {
		item = [super addItemWithTitle:aString action:aSelector keyEquivalent:keyEquiv];
	}
	return item;
}

@end
