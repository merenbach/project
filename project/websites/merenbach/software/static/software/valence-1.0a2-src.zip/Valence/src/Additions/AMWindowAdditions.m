//
//  AMWindowAdditions.m
//  AM Additions to NSWindow
//
//  Created by Andrew Merenbach on 1/1/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "AMWindowAdditions.h"


@implementation NSWindow (AMWindowAdditions)

- (void)resizeToSize:(NSSize)newSize {
	NSRect aFrame = NSZeroRect;
	
	CGFloat newHeight = newSize.height;
	CGFloat newWidth = newSize.width;

	aFrame = [self contentRectForFrameRect:[self frame]];
	aFrame.origin.y += aFrame.size.height;
	aFrame.origin.y -= newHeight;
	aFrame.size.height = newHeight;
	aFrame.size.width = newWidth;
	
	aFrame = [self frameRectForContentRect:aFrame];
	
	[self setFrame:aFrame display:YES animate:YES];
}

@end
