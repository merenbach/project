//
//  CBMoleFractionsToolEntry.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/23/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBMoleFractionsToolEntry.h"
#import "CBCalculator.h"


@implementation CBMoleFractionsToolEntry

@synthesize soluteQuantity = m_soluteQuantity;
@synthesize molarMass = m_molarMass;
@synthesize soluteScale = m_soluteScale;

+ (NSArray *)copyKeys {
	static NSArray *array = nil;
	if (!array) {
		array = [[NSArray alloc] initWithObjects:
			@"soluteName",
			@"soluteQuantity",
			@"soluteScale",
			@"molarMass",
			nil];
	}
	return array;
}

- (id)init {
	self = [super init];
	if (self != nil) {
		m_soluteQuantity = 0;
		m_molarMass = 0;
		m_soluteScale = [[CBMeasurementScale initialMassMolesScale] retain];
	}
	return self;
}

- (void)dealloc {
	[m_soluteScale release];
	m_soluteScale = nil;
	
	[super dealloc];
}

- (id)copyWithZone:(NSZone *)zone {
	CBMoleFractionsToolEntry *copy = [super copyWithZone:zone];
	
	copy.soluteQuantity = self.soluteQuantity;
	copy.molarMass = self.molarMass;
	copy.soluteScale = self.soluteScale;
	
	return copy;
}

- (NSDictionary *)dictionaryRepresentation {
	return [self dictionaryWithValuesForKeys:[[self class] copyKeys]];
}

@end