//
//  AMWindowAdditions.h
//  AM Additions to NSWindow
//
//  Created by Andrew Merenbach on 1/1/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "Cocoa/Cocoa.h"


@interface NSWindow (AMWindowAdditions)

- (void)resizeToSize:(NSSize)newSize;

@end
