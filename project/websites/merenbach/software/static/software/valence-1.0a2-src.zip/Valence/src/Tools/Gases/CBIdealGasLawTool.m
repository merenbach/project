#import "CBIdealGasLawTool.h"
#import "CBCalculator.h"

// ideal gas constant
const double R = 8.31434;

@implementation CBIdealGasLawTool

@synthesize pressureTabPressureValue = m_pressureTabPressureValue;
@synthesize pressureTabVolumeValue = m_pressureTabVolumeValue;
@synthesize pressureTabTemperatureValue = m_pressureTabTemperatureValue;
@synthesize pressureTabQuantityValue = m_pressureTabQuantityValue;

@synthesize volumeTabPressureValue = m_volumeTabPressureValue;
@synthesize volumeTabVolumeValue = m_volumeTabVolumeValue;
@synthesize volumeTabTemperatureValue = m_volumeTabTemperatureValue;
@synthesize volumeTabQuantityValue = m_volumeTabQuantityValue;

@synthesize quantityTabPressureValue = m_quantityTabPressureValue;
@synthesize quantityTabVolumeValue = m_quantityTabVolumeValue;
@synthesize quantityTabTemperatureValue = m_quantityTabTemperatureValue;
@synthesize quantityTabQuantityValue = m_quantityTabQuantityValue;

@synthesize temperatureTabPressureValue = m_temperatureTabPressureValue;
@synthesize temperatureTabVolumeValue = m_temperatureTabVolumeValue;
@synthesize temperatureTabTemperatureValue = m_temperatureTabTemperatureValue;
@synthesize temperatureTabQuantityValue = m_temperatureTabQuantityValue;

@synthesize pressureTabPressureScale = m_pressureTabPressureScale;
@synthesize pressureTabVolumeScale = m_pressureTabVolumeScale;
@synthesize pressureTabTemperatureScale = m_pressureTabTemperatureScale;
@synthesize pressureTabQuantityScale = m_pressureTabQuantityScale;

@synthesize volumeTabPressureScale = m_volumeTabPressureScale;
@synthesize volumeTabVolumeScale = m_volumeTabVolumeScale;
@synthesize volumeTabTemperatureScale = m_volumeTabTemperatureScale;
@synthesize volumeTabQuantityScale = m_volumeTabQuantityScale;

@synthesize quantityTabPressureScale = m_quantityTabPressureScale;
@synthesize quantityTabVolumeScale = m_quantityTabVolumeScale;
@synthesize quantityTabTemperatureScale = m_quantityTabTemperatureScale;
@synthesize quantityTabQuantityScale = m_quantityTabQuantityScale;

@synthesize temperatureTabPressureScale = m_temperatureTabPressureScale;
@synthesize temperatureTabVolumeScale = m_temperatureTabVolumeScale;
@synthesize temperatureTabTemperatureScale = m_temperatureTabTemperatureScale;
@synthesize temperatureTabQuantityScale = m_temperatureTabQuantityScale;

- (id)initWithNibName:(NSString *)nibName {
	self = [super initWithNibName:nibName];
	if (self != nil) {
		m_pressureTabPressureValue = 0;
		 m_pressureTabVolumeValue = 0;
		 m_pressureTabTemperatureValue = 0;
		 m_pressureTabQuantityValue = 0;
		
		 m_volumeTabPressureValue = 0;
		 m_volumeTabVolumeValue = 0;
		 m_volumeTabTemperatureValue = 0;
		 m_volumeTabQuantityValue = 0;
		
		 m_quantityTabPressureValue = 0;
		m_quantityTabVolumeValue = 0;
		 m_quantityTabTemperatureValue = 0;
		 m_quantityTabQuantityValue = 0;
		
		 m_temperatureTabPressureValue = 0;
		 m_temperatureTabVolumeValue = 0;
		 m_temperatureTabTemperatureValue = 0;
		 m_temperatureTabQuantityValue = 0;
		
		 m_pressureTabPressureScale = [CBMeasurementScale initialPressureScale];
		 m_pressureTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		 m_pressureTabTemperatureScale = [CBMeasurementScale initialTemperatureScale];
		m_pressureTabQuantityScale = [CBMeasurementScale initialMolesScale];
		
		 m_volumeTabPressureScale = [CBMeasurementScale initialPressureScale];
		 m_volumeTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		 m_volumeTabTemperatureScale = [CBMeasurementScale initialTemperatureScale];
		m_volumeTabQuantityScale = [CBMeasurementScale initialMolesScale];
		
		 m_quantityTabPressureScale = [CBMeasurementScale initialPressureScale];
		 m_quantityTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		 m_quantityTabTemperatureScale = [CBMeasurementScale initialTemperatureScale];
		m_quantityTabQuantityScale = [CBMeasurementScale initialMolesScale];
		
		 m_temperatureTabPressureScale = [CBMeasurementScale initialPressureScale];
		 m_temperatureTabVolumeScale = [CBMeasurementScale initialVolumeScale];
		 m_temperatureTabTemperatureScale = [CBMeasurementScale initialTemperatureScale];
		 m_temperatureTabQuantityScale = [CBMeasurementScale initialMolesScale];
	}
	return self;
}

- (void)dealloc {
	[m_pressureTabPressureScale release];
	[m_pressureTabVolumeScale release];
	[m_pressureTabTemperatureScale release];
	[m_pressureTabQuantityScale release];
	
	[m_volumeTabPressureScale release];
	[m_volumeTabVolumeScale release];
	[m_volumeTabTemperatureScale release];
	[m_volumeTabQuantityScale release];
	
	[m_quantityTabPressureScale release];
	[m_quantityTabVolumeScale release];
	[m_quantityTabTemperatureScale release];
	[m_quantityTabQuantityScale release];
	
	[m_temperatureTabPressureScale release];
	[m_temperatureTabVolumeScale release];
	[m_temperatureTabTemperatureScale release];
	[m_temperatureTabQuantityScale release];
	
	
	m_pressureTabPressureScale = nil;
	m_pressureTabVolumeScale = nil;
	m_pressureTabTemperatureScale = nil;
	m_pressureTabQuantityScale = nil;
	
	m_volumeTabPressureScale = nil;
	m_volumeTabVolumeScale = nil;
	m_volumeTabTemperatureScale = nil;
	m_volumeTabQuantityScale = nil;
	
	m_quantityTabPressureScale = nil;
	m_quantityTabVolumeScale = nil;
	m_quantityTabTemperatureScale = nil;
	m_quantityTabQuantityScale = nil;
	
	m_temperatureTabPressureScale = nil;
	m_temperatureTabVolumeScale = nil;
	m_temperatureTabTemperatureScale = nil;
	m_temperatureTabQuantityScale = nil;
	
	
	[super dealloc];
}

- (IBAction)calculatePressure:(id)sender
{
	double p;
	double v = self.pressureTabVolumeValue;
	double m = self.pressureTabQuantityValue;
	double t = self.pressureTabTemperatureValue;
		
	v = [CBCalculator convert:v fromScale:self.pressureTabVolumeScale];
	m = [CBCalculator convert:m fromScale:self.pressureTabQuantityScale];
	t = [CBCalculator convert:t fromScale:self.pressureTabTemperatureScale];
				
	/* finish up with the calculation itself */
	p = m * R * t / v;
	p = [CBCalculator convert:p toScale:self.pressureTabPressureScale];

	self.pressureTabPressureValue = p;
}

- (IBAction)calculateVolume:(id)sender
{
	double p = self.volumeTabPressureValue;
	double v;
	double m = self.volumeTabQuantityValue;
	double t = self.volumeTabTemperatureValue;
	
	p = [CBCalculator convert:p fromScale:self.volumeTabPressureScale];
	m = [CBCalculator convert:m fromScale:self.volumeTabQuantityScale];
	t = [CBCalculator convert:t fromScale:self.volumeTabTemperatureScale];
			
	/* finish up with the calculation itself */
	v = m * R * t / p;
	v = [CBCalculator convert:v toScale:self.volumeTabVolumeScale];
  
	self.volumeTabVolumeValue = v;
}

- (IBAction)calculateQuantity:(id)sender
{
	double p = self.quantityTabPressureValue;
	double v = self.quantityTabVolumeValue;
	double m;
	double t = self.quantityTabTemperatureValue;

	p = [CBCalculator convert:p fromScale:self.quantityTabPressureScale];
	v = [CBCalculator convert:v fromScale:self.quantityTabVolumeScale];
	t = [CBCalculator convert:t fromScale:self.quantityTabTemperatureScale];
		
	/* finish up with the calculation itself */
	m = (p * v) / (R * t);
	m = [CBCalculator convert:m toScale:self.quantityTabQuantityScale];

	self.quantityTabQuantityValue = m;
}

- (IBAction)calculateTemperature:(id)sender
{
	double p = self.temperatureTabPressureValue;
	double v = self.temperatureTabVolumeValue;
	double m = self.temperatureTabQuantityValue;
	double t;

	p = [CBCalculator convert:p fromScale:self.temperatureTabPressureScale];
	v = [CBCalculator convert:v fromScale:self.temperatureTabVolumeScale];
	m = [CBCalculator convert:m fromScale:self.temperatureTabQuantityScale];
						
	/* finish up with the calculation itself */
	t = m * R * p / v;
	t = [CBCalculator convert:t toScale:self.temperatureTabTemperatureScale];

	self.temperatureTabTemperatureValue = t;
}

@end
