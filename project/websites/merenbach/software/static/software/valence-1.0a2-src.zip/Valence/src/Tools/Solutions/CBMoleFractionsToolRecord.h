//
//  CBMoleFractionsToolRecord.h
//  Valence
//
//  Created by Andrew Merenbach on 4/6/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBMoleFractionsToolRecord : NSObject <NSCopying> {
	NSString *m_soluteName;
}

@property (copy, readwrite) NSString *soluteName;

- (id)init;
+ (id)record;
- (void)dealloc;

@end
