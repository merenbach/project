//
//  CBCenteredClipView.h
//  Valence (via Geometer's GMPolygonClipView)
//
//  Created by Andrew Merenbach on 18/12/2004.
//  Copyright 2004 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CBCenteredClipView : NSClipView {
	//BOOL AM_circumscribed;
}

//- (BOOL)isCircumscribed;
//- (void)setCircumscribed:(BOOL)flag;

@end


@interface CBCenteredClipView (CenteringMethods)

- (void)centerDocument;
- (NSPoint)constrainScrollPoint:(NSPoint)proposedNewOrigin;

- (void)viewBoundsChanged:(NSNotification *)notification;
- (void)viewFrameChanged:(NSNotification *)notification;

- (void)setFrame:(NSRect)frameRect;
- (void)setFrameOrigin:(NSPoint)newOrigin;
- (void)setFrameSize:(NSSize)newSize;
- (void)setFrameRotation:(float)angle;

@end