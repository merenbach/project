//
//  CBExpressionTextField.m
//  ChemBuddy
//
//  Created by Andrew Merenbach on 7/19/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "CBExpressionTextField.h"
#import "CBExpressionFormatter.h"


@implementation CBExpressionTextField

- (id)initWithFrame:(NSRect)frameRect {
	self = [super initWithFrame:frameRect];
	if (self != nil) {
		[self setFormatter:[CBExpressionFormatter sharedInstance]];
		[self setDoubleValue:0];
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateFormattedValue:)
			name:CBExpressionFormatterUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		[self setFormatter:[CBExpressionFormatter sharedInstance]];
		[self setDoubleValue:0];
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateFormattedValue:)
			name:CBExpressionFormatterUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self
		name:CBExpressionFormatterUpdatedNotificationName
		object:nil];
		
	[super dealloc];
}

- (void)updateFormattedValue:(NSNotification *)aNotification {
	[self setNeedsDisplay:YES];
}

@end


@implementation CBExpressionTextFieldCell

- (id)initTextCell:(NSString *)aString {
	self = [super initTextCell:aString];
	if (self != nil) {
		[self setFormatter:[CBExpressionFormatter sharedInstance]];
		[self setDoubleValue:0];
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateFormattedValue:)
			name:CBExpressionFormatterUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if (self != nil) {
		[self setFormatter:[CBExpressionFormatter sharedInstance]];
		[self setDoubleValue:0];
		[[NSNotificationCenter defaultCenter] addObserver:self
			selector:@selector(updateFormattedValue:)
			name:CBExpressionFormatterUpdatedNotificationName
			object:nil];
	}
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self
		name:CBExpressionFormatterUpdatedNotificationName
		object:nil];
		
	[super dealloc];
}

- (void)updateFormattedValue:(NSNotification *)aNotification {
	[(NSControl *)[self controlView] setNeedsDisplay:YES];
}

@end
