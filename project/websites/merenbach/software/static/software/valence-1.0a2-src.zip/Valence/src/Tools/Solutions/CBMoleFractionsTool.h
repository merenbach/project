#import <Cocoa/Cocoa.h>
#import "CBToolViewController.h"

@class AMTableView;
@class CBSortingArrayController;

@interface CBMoleFractionsTool : CBToolViewController
{    
	//IBOutlet NSArrayController *entriesArrayController;
	//IBOutlet NSArrayController *resultsArrayController;
	
	NSArray *m_entriesArray;
	NSArray *m_resultsArray;
	
	AMTableView *m_entriesTableView;
	AMTableView *m_resultsTableView;
}

@property (copy, readwrite) NSArray *entriesArray;
@property (copy, readwrite) NSArray *resultsArray;
@property (assign) IBOutlet AMTableView *entriesTableView;
@property (assign) IBOutlet AMTableView *resultsTableView;

- (void)awakeFromNib;
- (IBAction)calculate:(id)sender;

@end