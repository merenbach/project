//
//  QuotientAppDelegate.m
//  Quotient
//
//  Created by Andrew Merenbach on 1/23/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "QuotientAppDelegate.h"
#import "XQEquationController.h"
#import "XQEquationCalculator.h"

#import "XQPatternDetector.h"


CGFloat minQuotientTextViewHeight = 120;
CGFloat minRepetendTextViewHeight = 120;

#define DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS 100


@implementation QuotientAppDelegate

@synthesize window = m_window;
@synthesize resultsSplitView;

@synthesize calculationProgressIndicator = m_calculationProgressIndicator;
@synthesize detectionProgressIndicator = m_detectionProgressIndicator;
@synthesize textFieldForDividend = m_textFieldForDividend;
@synthesize textFieldForDivisor = m_textFieldForDivisor;
@synthesize textFieldForScale = m_textFieldForScale;

@synthesize equationController = m_equationController;
@synthesize isExporting = m_isExporting;

/*- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}*/

- (id)init {
    self = [super init];
    if (self) {
        m_equationController = [[XQEquationController alloc] init];
        m_isExporting = NO;
    }
    return self;
}

- (void)dealloc {
	[m_equationController release];
	m_equationController = nil;

	[super dealloc];
 }

- (void)awakeFromNib {
    //[equationController loadValuesFromDefaults];
    [self loadAllValuesFromDefaults];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication {
    return YES;
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    [self saveAllValuesToDefaults];
    //[equationController saveValuesToDefaults];
}

- (BOOL)application:(NSApplication *)sender delegateHandlesKey:(NSString *)key {
    BOOL b = [key isEqualToString:@"divisor"] ||
	[key isEqualToString:@"dividend"] ||
	[key isEqualToString:@"scaleOfNotation"] ||
	[key isEqualToString:@"quotient"];
    return b;
}

/* cover methods for scripting */
- (NSString *)quotient {
    return self.equationController.cachedQuotient; 
}

- (NSUInteger)dividend {
    return self.equationController.cachedDividend;
}

- (void)setDividend:(NSUInteger)value {
    self.equationController.cachedDividend = value;
}

- (NSUInteger)divisor {
    return self.equationController.cachedDivisor;
}

- (void)setDivisor:(NSUInteger)value {
    self.equationController.cachedDivisor = value;
}

- (NSUInteger)scaleOfNotation {
    return self.equationController.cachedScaleOfNotation;
}

- (void)setScaleOfNotation:(NSUInteger)value {
    self.equationController.cachedScaleOfNotation = value;
}

- (void)calculateQuotient:(id)sender {
    [self.equationController toggleRunningCalculation:sender];
}

- (void)detectRepetend:(id)sender {
    [self.equationController toggleRunningPatternSearch:sender];
}

- (NSString *)divide:(NSNumber *)dividend by:(NSNumber *)divisor withScale:(NSNumber *)scale {
    NSString *quotientString = nil;
    
    {
        XQEquationCalculator *calculator = [[XQEquationCalculator alloc] init];
        
        calculator.dividend = [dividend unsignedIntegerValue];
        calculator.divisor = [divisor unsignedIntegerValue];
        calculator.scaleOfNotation = [scale unsignedIntegerValue];
        
        [calculator calculate];
        quotientString = calculator.quotient;
        
        calculator = nil;
    }
    
    return quotientString;
}

- (NSString *)detectRepetendInString:(NSString *)string {
    NSString *pattern = nil;
    
    {
        // ensure that there are only digits in the string; otherwise set string to blank
        NSMutableCharacterSet *numberSet = [NSMutableCharacterSet decimalDigitCharacterSet];
        [numberSet addCharactersInString:@".,"];
        [numberSet invert];
        
        NSRange numberRange = [string rangeOfCharacterFromSet:numberSet];
        if (numberRange.location != NSNotFound) {
            string = @"";
        }
		
        // configure our detector
        XQPatternDetector *detector = [[XQPatternDetector alloc] init]; //detectorForScripting
        detector.originalString = string;
        
        //[detector addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];
        
        //NSOperationQueue *queue = [NSOperationQueue new]; //operationQueueForScripting
        //[queue addOperation:detector];
        [detector locate];
        pattern = detector.patternString;
        
        detector = nil;
    }
    
    return pattern;
}

/* end cover methods for scripting */

- (IBAction)export:(id)sender
{
    NSSavePanel *sp;
	
    sp = [NSSavePanel savePanel];
	
    [sp setCanSelectHiddenExtension:YES];
    [sp setRequiredFileType:@"txt"];
    
    [sp
		beginSheetForDirectory:nil
		file:@"Quotient Output"
		modalForWindow:self.window
		modalDelegate:self
		didEndSelector:@selector(savePanelDidEnd:returnCode:contextInfo:)
		contextInfo:NULL];
}

- (void)savePanelDidEnd:(NSSavePanel *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo
{
    if (returnCode == NSOKButton) {
        self.isExporting = YES;
        NSMutableString *summary = [@"=== Quotient Output ===\n" mutableCopy];
		[summary appendString:@"\n"];
		[summary appendFormat:@"%@: %i\n", NSLocalizedString(@"Dividend", @"Dividend"), self.equationController.cachedDividend];
		[summary appendFormat:@"%@: %i\n", NSLocalizedString(@"Divisor", @"Divisor"), self.equationController.cachedDivisor];
		[summary appendFormat:@"%@: %i\n", NSLocalizedString(@"Scale", @"Scale"), self.equationController.cachedScaleOfNotation];
		[summary appendString:@"\n"];
		
		NSString *quotSuffix = NSLocalizedString(@"...", @"..."); // suffix; may be ellipses, or may be nothing
		NSString *quot = self.equationController.cachedQuotient;
		NSUInteger quotLen = [quot length];
		//NSString *quotLenString = [NSString stringWithFormat:@"%@ %i", NSLocalizedString(@"Length", @"Length"), quotLen];
		if (!quot || quotLen == 0) {    // sanity-check
			quot = NSLocalizedString(@"None", @"None");
			quotSuffix = @"";   // we don't need a suffix due to there being no quotient
		}
		
		// we need no ellipsis on a quotient without a decimal point
		if (self.equationController.cachedScaleOfNotation == 0) {
			quotSuffix = @"";
		}
		
		[summary appendFormat:@"%@: %@%@\n", NSLocalizedString(@"Quotient", @"Quotient"), quot, quotSuffix];
		[summary appendString:@"\n"];
		
		NSString *rep = self.equationController.cachedRepetend;
		NSUInteger repLen = [rep length];
		NSString *repLenString = [NSString stringWithFormat:@"%@ %i", NSLocalizedString(@"Length", @"Length"), repLen];
		if (!rep || repLen == 0) {
			rep = NSLocalizedString(@"None", @"None");
		}
		
		[summary appendFormat:@"%@ (%@): %@", NSLocalizedString(@"Repetend", @"Repetend"), repLenString, rep];
        [summary writeToFile:[sheet filename] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        self.isExporting = NO;
    }
}

- (void)loadAllValuesFromDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    self.equationController.cachedDividend = [userDefaults integerForKey:@"dividend"];
    self.equationController.cachedDivisor = [userDefaults integerForKey:@"divisor"];
    self.equationController.cachedScaleOfNotation = [userDefaults integerForKey:@"scale"];
}

- (void)saveAllValuesToDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:self.equationController.cachedDividend forKey:@"dividend"];
    [userDefaults setInteger:self.equationController.cachedDivisor forKey:@"divisor"];
    [userDefaults setInteger:self.equationController.cachedScaleOfNotation forKey:@"scale"];
}

// ensure that unparseable values are equated to zero
- (BOOL)control:(NSControl *)control didFailToFormatString:(NSString *)string errorDescription:(NSString *)error {
    BOOL success = NO;
    if (control == self.textFieldForDividend || control == self.textFieldForDivisor || control == self.textFieldForScale) {
        [control setIntegerValue:0];
        success = YES;
    }
    
    /*if (!success) {
	 [NSApp presentError:error];
	 }*/
    
    return success;
}

/*- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset {
 CGFloat coordinate = proposedMin;
 if (sender == resultsSplitView) {
 if (offset == 0) {
 coordinate = minQuotientTextViewHeight;
 }
 }
 return coordinate;
 }
 
 - (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset {
 CGFloat coordinate = proposedMax;
 if (sender == resultsSplitView) {
 if (offset == 0) {
 CGFloat height = NSHeight([resultsSplitView frame]);
 coordinate = height - minRepetendTextViewHeight;
 }
 }
 return coordinate;
 }*/

@end

@implementation QuotientAppDelegate (SplitViewDelegateMethods)

/*- (CGFloat)splitView:(NSSplitView *)sender constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)offset {
 CGFloat coordinate = proposedMin;
 
 / *if (sender == self.mainSplitView) {
 if (offset == 0) {
 coordinate = DLAdvancedDocumentMinimumWidthForDocumentView;
 }
 }
 else* / if (sender == self.recordsSplitView) {
 if (offset == 0) {
 coordinate = DLAdvancedDocumentMinimumHeightForEntriesView;
 }
 }
 return coordinate;
 }
 
 - (CGFloat)splitView:(NSSplitView *)sender constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)offset {
 CGFloat coordinate = proposedMax;
 / *if (sender == self.mainSplitView) {
 if (offset == 0) {
 CGFloat width = [self.mainSplitView frame].size.width;
 coordinate = width - DLAdvancedDocumentMinimumWidthForSummaryView;
 }
 }
 else* / if (sender == self.recordsSplitView) {
 if (offset == 0) {
 CGFloat height = NSHeight([self.recordsSplitView frame]);
 coordinate = height - DLAdvancedDocumentMinimumHeightForResultsView;
 }
 }
 return coordinate;
 }*/

- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
	CGFloat newPosition = proposedPosition;
	if (proposedPosition < DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS) {
		newPosition = DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS;
	} else if (proposedPosition > NSHeight([sender frame]) - DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS) {
		newPosition = NSHeight([sender frame]) - DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS;
	}
	return newPosition;
}

/*  During live resize of the window, lock the left side, the collection
 side, and resize the tableside
 The frames have to be set to add up to the total size minus the divider
 thickness */
- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize {
    //detect if it's a window resize
    if ([sender inLiveResize]) {
		CGFloat dt = [sender dividerThickness];

        //info needed
        NSRect tmpRect = [sender bounds];
        NSArray *subviews =  [sender subviews];
        NSView *collectionsSide = [subviews objectAtIndex:0];
        NSView *tableSide = [subviews objectAtIndex:1];
        CGFloat collectionHeight = [collectionsSide bounds].size.height;
		
        //tableside frame: full size minus collection width and divider
        // My divider thickness is hard coded here as 1
        tmpRect.size.height = tmpRect.size.height - collectionHeight - dt;
        tmpRect.origin.y = tmpRect.origin.y + collectionHeight + dt;
        [tableSide setFrame:tmpRect];
		
        //collection frame stays the same
        tmpRect.size.height = collectionHeight;
        tmpRect.origin.y = 0;
        [collectionsSide setFrame:tmpRect];
    }
    /*else
	 [sender adjustSubviews];*/
}

- (void)windowDidResize:(NSNotification *)notification {
	NSWindow *window = [notification object];
	if (window == self.window) {
		NSSplitView *sv = self.resultsSplitView;
		
		NSView *view = [[sv subviews] objectAtIndex:1];
		NSRect rect = [view frame];
		
		CGFloat h = NSHeight(rect);
		CGFloat dt = [sv dividerThickness];
		
		if (h < (DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS - dt)) {
			h = DL_MINIMUM_HEIGHT_FOR_ENTRIES_AND_RESULTS_VIEWS - dt;
			
			// get the differential between the height we want and the height of the bottom rectangle
			CGFloat diff = h - NSHeight(rect);
			
			// resize the top view to the new height and adjust its own origin (bottom-left window origin) accordingly
			NSView *topView = [[sv subviews] objectAtIndex:0];
			NSRect topRect = [topView frame];
			topRect.size.height -= diff;
			topRect.origin.y += diff;
			[topView setFrame:topRect];
			[topView setNeedsDisplay:YES];
		}
	}
}

/*- (void)splitView:(NSSplitView *)sender resizeSubviewsWithOldSize:(NSSize)oldSize
 {
 NSRect newFrame = [sender frame];
 CGFloat dt = [sender dividerThickness];
 
 //NSView *leftView = self.splitViewBottomView;
 //NSView *rightView = self.splitViewTopView;
 NSView *leftView = self.splitViewTopView;
 NSView *rightView = self.splitViewBottomView;
 
 // this is the fixed view (right)
 // on top on being fixed it is also collapsible
 NSRect rightFrame = [self.splitViewBottomView frame];
 // this is the flexible view (left)
 NSRect leftFrame = [self.splitViewTopView frame];
 
 rightFrame.size.height = newFrame.size.height;
 leftFrame.size.height = newFrame.size.height;
 
 if (![self.recordsSplitView isSubviewCollapsed:rightView]) {
 NSLog(@"not collapsed");
 rightFrame.origin.x = newFrame.size.width - rightFrame.size.width;
 rightFrame.origin.y = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - rightFrame.size.width - dt;		
 } else {
 NSLog(@"collapsed");
 rightFrame.origin.x = newFrame.size.width;
 rightFrame.origin.y = 0;
 rightFrame.size.width = 0;
 
 leftFrame.origin = NSMakePoint(0,0);
 leftFrame.size.width = newFrame.size.width - dt;
 }
 [leftView setFrame: leftFrame];
 [rightView setFrame:rightFrame];
 }*/


/*- (CGFloat)splitView:(NSSplitView *)sender constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)offset {
 float coordinate = proposedPosition;
 if (offset == 0) {
 float halfway = (minimumHeight + maximumHeight) / 2.0;
 if (proposedPosition > halfway) {
 coordinate = maximumHeight;
 } else if (proposedPosition < halfway) {
 coordinate = minimumHeight;
 } else {
 coordinate = maximumHeight;	// could also be minimumHeight
 }
 }
 return coordinate;
 }*/

@end

/*40 q = int(d/p): REM truncate q to an integer<br/>
 50 print q;".";: REM print q, then the decimal point<br/>
 60 d = 10*(d mod p): REM set d to 10 times the modulus (remainder) of d divided by p<br/>   -- = 10 * (dividend - (quotient * divisor))
 70 q = int(d/p): REM set q to the digit right after the decimal point<br/>
 80 print q;: REM print q<br/>
 90 if not button and inkey$<>" " then goto 60: REM click mouse or press [SPACE] to interrupt
 100 end: REM end the program*/
//}
