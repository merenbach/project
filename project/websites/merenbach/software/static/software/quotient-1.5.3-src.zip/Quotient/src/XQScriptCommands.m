//
//  XQScriptCommands.m
//  Quotient
//
//  Created by Andrew Merenbach on 21/11/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "XQScriptCommands.h"
#import "QuotientAppDelegate.h"

@implementation XQBasicScriptCommand

- (id)performDefaultImplementation {
    id returnValue = nil;

    QuotientAppDelegate *delegate = [NSApp delegate];

    NSString *commandName = [[self commandDescription] commandName];
    if ([commandName isEqualToString:@"calculate"]) {
        [delegate calculateQuotient:self];
        
    } else if ([commandName isEqualToString:@"find repetend"]) {
        [delegate detectRepetend:self];
        
    } else if ([commandName isEqualToString:@"divide"]) {
        id dividend, divisor, scale;
        {
            NSDictionary *args = [self evaluatedArguments];
            dividend = [args objectForKey:@""];
            divisor = [args objectForKey:@"divisor"];
            scale = [args objectForKey:@"scale"];
        }
        returnValue = [delegate divide:dividend by:divisor withScale:scale];
        
    } else if ([commandName isEqualToString:@"find repetend in"]) {
        id quotient;
        {
            NSDictionary *args = [self evaluatedArguments];
            quotient = [args objectForKey:@""];
        }
        returnValue = [delegate detectRepetendInString:quotient];
    }
    
    return returnValue;
}

@end
