//
//  XQEquationController.m
//  Quotient
//
//  Created by Andrew Merenbach on 5/11/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import "XQEquationController.h"
#import "XQEquationCalculator.h"
#import "XQPatternDetector.h"
//#import "XQPreferencesWindowController.h"


@implementation XQEquationController

+ (void)initialize {
    NSValueTransformer *vt;
    
    vt = [XQEquationCalculatorStateValueTransformer new];
    [NSValueTransformer setValueTransformer:vt forName:@"EquationControllerStateVT"];
    
    vt = [XQPatternDetectorStateValueTransformer new];
    [NSValueTransformer setValueTransformer:vt forName:@"PatternDetectorStateVT"];
}

- (id)init {
    self = [super init];
    if (self) {
        m_cachedDividend = 1;
        m_cachedDivisor = 1;
        m_cachedScaleOfNotation = 1;
        m_cachedQuotient = [[NSString alloc] initWithString:@""];
        m_cachedRepetend = [[NSString alloc] initWithString:@""];
        
        // new
        m_isRunningCalculation = NO;
        m_isRunningPatternSearch = NO;
        
        operationQueue = [NSOperationQueue new];
    }
    return self;
}

- (void)dealloc {    
    [m_cachedQuotient release];
    m_cachedQuotient = nil;
    
    [m_cachedRepetend release];
    m_cachedRepetend = nil;
        
    [operationQueue release];
    operationQueue = nil;
        
    [super dealloc];
}

/*- (void)loadValuesFromDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [self setDividend:[userDefaults integerForKey:XQPreferencesDividendKey]];
    [self setDivisor:[userDefaults integerForKey:XQPreferencesDivisorKey]];
    [self setScale:[userDefaults integerForKey:XQPreferencesScaleKey]];
}*/

/*- (void)saveValuesToDefaults {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:[self dividend] forKey:XQPreferencesDividendKey];
    [userDefaults setInteger:[self divisor] forKey:XQPreferencesDivisorKey];
    [userDefaults setInteger:[self scale] forKey:XQPreferencesScaleKey];
}*/


- (void)toggleRunningCalculation:(id)sender {
    // If already running, cancel and exit
    if (self.isRunningCalculation) {
        //self.cachedQuotient = @"";
        
        [equationCalculator removeObserver:self forKeyPath:@"isFinished"];
        //[operationQueue cancelAllOperations];
        [equationCalculator cancel];
        //operationQueue = nil;
        equationCalculator = nil;
        self.isRunningCalculation = NO;
    }
    else {
        // If not running, start up the operation queue
        self.isRunningCalculation = YES;
        self.cachedQuotient = @"";
        //startDate = [NSDate date];
        //self.time = 0.0;
        //timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
        
        // Create an expression tree for A * A * A + B * ( A * B + B )
        equationCalculator = [[XQEquationCalculator alloc] initWithScale:self.cachedScaleOfNotation];
        equationCalculator.dividend = self.cachedDividend;
        equationCalculator.divisor = self.cachedDivisor;
        equationCalculator.scaleOfNotation = self.cachedScaleOfNotation;
        
        // Observe the complete expression to see when it is done
        [equationCalculator addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];

        // Add operations to a operation queue
        //operationQueue = [NSOperationQueue new];
        //[operationQueue setMaxConcurrentOperationCount:numberOfCores];
        [operationQueue addOperation:equationCalculator];
    }
}

- (void)toggleRunningPatternSearch:(id)sender {
    // If already running, cancel and exit
    if (self.isRunningPatternSearch) {
        //self.cachedRepetend = @"";
        
        [repetendDetector removeObserver:self forKeyPath:@"isFinished"];
        //[operationQueue cancelAllOperations];
        [repetendDetector cancel];

        //operationQueue = nil;
        repetendDetector = nil;

        self.isRunningPatternSearch = NO;
    }
    else {
        // If not running, start up the operation queue
        self.isRunningPatternSearch = YES;
        self.cachedRepetend = @"";
        
        // Create the detector
        repetendDetector = [[XQPatternDetector alloc] init];
        repetendDetector.originalString = self.cachedQuotient;
        
        // Observe the complete expression to see when it is done
        [repetendDetector addObserver:self forKeyPath:@"isFinished" options:0 context:NULL];

        // Add operations to a operation queue
        //operationQueue = [NSOperationQueue new];
        //[operationQueue setMaxConcurrentOperationCount:numberOfCores];
        [operationQueue addOperation:repetendDetector];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ( [keyPath isEqual:@"isFinished"] && equationCalculator == object ) {
        [self performSelectorOnMainThread:@selector(finishCalculation:) withObject:equationCalculator.quotient waitUntilDone:YES];
    
        [equationCalculator removeObserver:self forKeyPath:@"isFinished"];
        //operationQueue = nil;
        equationCalculator = nil;

        self.isRunningCalculation = NO;
    }
    else if ( [keyPath isEqual:@"isFinished"] && repetendDetector == object ) {
        [self performSelectorOnMainThread:@selector(finishDetection:) withObject:repetendDetector.patternString waitUntilDone:YES];
    
        [repetendDetector removeObserver:self forKeyPath:@"isFinished"];
        //operationQueue = nil;
        repetendDetector = nil;
        
        self.isRunningPatternSearch = NO;
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)finishCalculation:(NSString *)string {
    self.cachedQuotient = string;
}

- (void)finishDetection:(NSString *)string {
    self.cachedRepetend = repetendDetector.patternString;
}

- (void)setNilValueForKey:(NSString *)key {
    NSArray *zeroKeys = [NSArray arrayWithObjects:@"cachedDividend", @"cachedDivisor", @"cachedScaleOfNotation", nil];
    if ([zeroKeys containsObject:key]) {
        [self setValue:[NSNumber numberWithUnsignedInteger:0] forKey:key];
    }
    else {
        [super setNilValueForKey:key];
    }
}

/*- (void)setNilValueForKey:(NSString *)key {
    [self willChangeValueForKey:key];
    [self setValue:[NSNumber numberWithInt:0] forKey:key];
    [self didChangeValueForKey:key];
}*/

@synthesize cachedDividend = m_cachedDividend;
@synthesize cachedDivisor = m_cachedDivisor;
@synthesize cachedScaleOfNotation = m_cachedScaleOfNotation;
@synthesize cachedQuotient = m_cachedQuotient;

@synthesize cachedRepetend = m_cachedRepetend;
//@synthesize isCalculating;
//@synthesize delegate;

// new
@synthesize isRunningCalculation = m_isRunningCalculation;
@synthesize isRunningPatternSearch = m_isRunningPatternSearch;
//@synthesize time;
//@synthesize numberOfCores;
//@synthesize equationCalculator;

@end

@implementation XQEquationCalculatorStateValueTransformer
+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
    NSString *returnValue = nil;
    if (value) {
        if (![value boolValue]) {
            returnValue = NSLocalizedString(@"Calculate", @"Calculate");
        }
        else {
            returnValue = NSLocalizedString(@"Stop", @"Stop");
        }
    }
    return returnValue;
}
@end

@implementation XQPatternDetectorStateValueTransformer
+ (Class)transformedValueClass { return [NSString class]; }
+ (BOOL)allowsReverseTransformation { return NO; }
- (id)transformedValue:(id)value {
    NSString *returnValue = nil;
    if (value) {
        if (![value boolValue]) {
            returnValue = NSLocalizedString(@"Locate", @"Locate");
        }
        else {
            returnValue = NSLocalizedString(@"Stop", @"Stop");
        }
    }
    return returnValue;
}
@end
