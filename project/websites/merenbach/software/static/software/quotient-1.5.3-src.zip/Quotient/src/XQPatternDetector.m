//
//  XQPatternDetector.m
//  Sniffer
//
//  Created by Andrew Merenbach on 7/11/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import "XQPatternDetector.h"
//#import "SNAdditions.h"

#import "XQEquationController.h"


@implementation XQPatternDetector

@synthesize originalString = m_originalString;
@synthesize patternString = m_patternString;

//@synthesize isDetecting;
//@synthesize handler;

- (id)init {
    self = [super init];
    if (self) {
        //self.isDetecting = NO;
        //self.handler = nil;
        m_originalString = [[NSString alloc] initWithString:@""];
        m_patternString = [[NSString alloc] initWithString:@""];
    }
    return self;
}

- (void)dealloc {
    [m_originalString release];
    m_originalString = nil;
    
    [m_patternString release];
    m_patternString = nil;

    [super dealloc];
}

- (void)main {
    [self locate];
}

- (void)locate {
    NSString *inputString;
    NSString *decimalString;
    NSString *outputString;
    
    if (self.isCancelled) return;
    inputString = self.originalString;
    
    if (self.isCancelled) return;
    decimalString = [self substringPastDecimalPointInString:inputString];
    
    if (self.isCancelled) return;
    outputString = [self findPatternFromRightInString:decimalString];
    
    if (self.isCancelled) return;
    self.patternString = outputString;
}

@end

@implementation XQPatternDetector (Algorithms)

- (NSString *)findPatternFromRightInString:(NSString *)string {
    NSString *pattern = @"";
    NSUInteger len = [string length];
    
    for (NSUInteger idx = 0; idx < len; ++idx) {
        if (self.isCancelled) break;
        NSString *substring = [string substringFromIndex:idx];
        NSString *tempPattern = [self findPatternInString:substring];
        if (tempPattern) {
            pattern = tempPattern;
            break;
        }
    }
    
    return pattern;
}

- (NSString *)findPatternInString:(NSString *)string {
    NSString *pattern = nil;
    NSIndexSet *groupSizes = [self indexSetOfFactorsOfNumber:[string length]];
    
    /*  unsigned currentIndex = [indexSet firstIndex];
    int i = 0;
    while (currentIndex != NSNotFound) {
        if (currentIndex < row) { i++; }
        currentIndex = [indexSet indexGreaterThanIndex:currentIndex];
    }
    return i;
*/

    NSUInteger currentIndex = [groupSizes firstIndex];
    while (currentIndex != NSNotFound) {
        if (self.isCancelled) break;
        NSString *searchTerm = [string substringToIndex:currentIndex];
        NSString *searchString = [string stringByReplacingOccurrencesOfString:searchTerm withString:@""];
        if ([searchString length] == 0) {
            pattern = searchTerm;
            break;
        }
        currentIndex = [groupSizes indexGreaterThanIndex:currentIndex];
    }
    
    if (self.isCancelled) return nil;
    
    return pattern;
}

/* works only on positive integers */
- (NSIndexSet *)indexSetOfFactorsOfNumber:(NSUInteger)num {
    NSMutableIndexSet *factors = [NSMutableIndexSet indexSet];
    
    if (num > 1) {
        [factors addIndex:1];
        
        double root = sqrt(num);
        NSUInteger root_rounded = (NSUInteger)floor(root);
        NSUInteger quotient;
        
        // since we're a set (and can thus avoid duplicates), we'll just test the root and add it twice if it divides evenly
        for (NSUInteger i = 2; i <= root_rounded; ++i) {
            if (num % i == 0) {
                quotient = num / i; //(NSUInteger)floor((double)num / (double)i);
                [factors addIndex:quotient];
                [factors addIndex:i];
            }
        }

        /*if (num % root_rounded == 0) {
            [factors addObject:[NSNumber numberWithUnsignedInteger:root_rounded]];
        }*/
    }
        
    return [[factors copy] autorelease];
    
    // sort ascending
    //NSArray *sortedFactors = [[factors allObjects] sortedArrayUsingSelector:@selector(compare:)];
    //return sortedFactors;
}

/* works only on positive integers */
/*- (NSArray *)factorsOfNumber:(NSUInteger)num {
    NSMutableSet *factors = [NSMutableSet set];
    
    if (num > 0) {
        [factors addObject:[NSNumber numberWithUnsignedInteger:1]];
        
        double root = sqrt(num);
        NSUInteger root_rounded = (NSUInteger)ceil(root);
        NSUInteger quotient;
        
        // since we're a set (and can thus avoid duplicates), we'll just test the root and add it twice if it divides evenly
        for (NSUInteger i = 2; i <= root_rounded; ++i) {
            if (num % i == 0) {
                quotient = num / i; //(NSUInteger)floor((double)num / (double)i);
                [factors addObject:[NSNumber numberWithUnsignedInteger:quotient]];
                [factors addObject:[NSNumber numberWithUnsignedInteger:i]];
            }
        }

        / *if (num % root_rounded == 0) {
            [factors addObject:[NSNumber numberWithUnsignedInteger:root_rounded]];
        }* /
    }
    
    // sort ascending
    NSArray *sortedFactors = [[factors allObjects] sortedArrayUsingSelector:@selector(compare:)];
    return sortedFactors;
}*/

- (NSString *)substringPastDecimalPointInString:(NSString *)string {
    NSScanner *scanner = [NSScanner scannerWithString:string];
    NSString *decimalString = @"";
    
    // [TODO] are these two lines the most efficient way of doing this?
    //[scanner setCharactersToBeSkipped:[NSCharacterSet decimalDigitCharacterSet]];
    (void)[scanner scanUpToString:@"." intoString:NULL];
    (void)[scanner scanString:@"." intoString:NULL];
//[scanner scanCharactersFromSet:[NSCharacterSet decimalDigitCharacterSet] intoString:&decimalString];
    //[scanner setCharactersToBeSkipped:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    //NSUInteger loc = [scanner scanLocation];
    //if (loc < [string length])
    if (![scanner isAtEnd]) {
        decimalString = [[scanner string] substringFromIndex:[scanner scanLocation]];
    }
    
    return decimalString;
}

@end
