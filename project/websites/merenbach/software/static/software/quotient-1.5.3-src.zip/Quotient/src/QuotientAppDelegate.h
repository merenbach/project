//
//  QuotientAppDelegate.h
//  Quotient
//
//  Created by Andrew Merenbach on 1/23/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class XQEquationController;

@interface QuotientAppDelegate : NSObject {
    NSWindow *m_window;
    
	NSProgressIndicator *m_calculationProgressIndicator;
    NSProgressIndicator *m_detectionProgressIndicator;
    NSTextField *m_textFieldForDividend;
    NSTextField *m_textFieldForDivisor;
    NSTextField *m_textFieldForScale;
    NSSplitView *resultsSplitView;
    
    //XQEquationController *equationControllerForScripting;
    
    //IBOutlet NSFormCell *dividendField;
    //IBOutlet NSFormCell *divisorField;
    //IBOutlet NSFormCell *scaleOfNotationField;
    //NSOperationQueue *operationQueueForScripting;
    //XQPatternDetector *detectorForScripting;
	
    // property ivars
    XQEquationController *m_equationController;
    BOOL m_isExporting;	
}

@property (retain, readwrite) XQEquationController *equationController;
@property (assign, readwrite) BOOL isExporting;

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSSplitView *resultsSplitView;

@property (assign) IBOutlet NSProgressIndicator *calculationProgressIndicator;
@property (assign) IBOutlet NSProgressIndicator *detectionProgressIndicator;
@property (assign) IBOutlet NSTextField *textFieldForDividend;
@property (assign) IBOutlet NSTextField *textFieldForDivisor;
@property (assign) IBOutlet NSTextField *textFieldForScale;


//+ (void)initialize;

//- (id)init;
//- (void)dealloc;

- (void)awakeFromNib;
//- (IBAction)calculate:(id)sender;
//- (void)finishCalculation:(NSString *)quotient;

//- (void)performCalculation:(id)sender;
- (IBAction)export:(id)sender;

//- (NSString *)quotientWithScale:(unsigned)scale dividend:(double)b divisor:(double)a;

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication;
//- (void)applicationDidFinishLaunching:(NSNotification *)notification;
- (void)applicationWillTerminate:(NSNotification *)aNotification;

- (BOOL)application:(NSApplication *)sender delegateHandlesKey:(NSString *)key;
//- (void)finishedQuotientCalculation:(id)controller;

/* cover methods for scripting */
- (void)calculateQuotient:(id)sender;
- (void)detectRepetend:(id)sender;
- (NSString *)divide:(NSNumber *)dividend by:(NSNumber *)divisor withScale:(NSNumber *)scale;
- (NSString *)detectRepetendInString:(NSString *)string;

- (void)loadAllValuesFromDefaults;
- (void)saveAllValuesToDefaults;

@end
