//
//  XQEquationController.h
//  Quotient
//
//  Created by Andrew Merenbach on 5/11/06.
//  Copyright 2006 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class XQEquationCalculator;
@class XQPatternDetector;


@interface XQEquationController : NSObject {
    // property ivars
        NSUInteger m_cachedDividend;
        NSUInteger m_cachedDivisor;
        NSUInteger m_cachedScaleOfNotation;
        NSString *m_cachedQuotient;

        NSString *m_cachedRepetend;

        BOOL m_isRunningCalculation;
        BOOL m_isRunningPatternSearch;
            
    // non-property ivars
        NSOperationQueue *operationQueue;
        XQEquationCalculator *equationCalculator;
        XQPatternDetector *repetendDetector;
}

- (id)init;

//- (void)loadValuesFromDefaults;
//- (void)saveValuesToDefaults;

- (void)toggleRunningCalculation:(id)sender;
- (void)toggleRunningPatternSearch:(id)sender;

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;

- (void)finishCalculation:(NSString *)string;
- (void)finishDetection:(NSString *)string;


@property (readwrite, assign) BOOL isRunningCalculation;
@property (readwrite, assign) BOOL isRunningPatternSearch;
//@property (readwrite, assign) NSTimeInterval time;
//@property (readwrite, assign) NSUInteger numberOfCores;
//@property (readwrite, assign) XQEquationCalculator *equationCalculator;

@property (assign, readwrite) NSUInteger cachedDividend;
@property (assign, readwrite) NSUInteger cachedDivisor;
@property (assign, readwrite) NSUInteger cachedScaleOfNotation;
@property (copy, readwrite) NSString *cachedQuotient;
@property (copy, readwrite) NSString *cachedRepetend;

//@property BOOL isCalculating;
//@property (assign) id delegate;

@end

@interface XQEquationCalculatorStateValueTransformer : NSValueTransformer {}
@end

@interface XQPatternDetectorStateValueTransformer : NSValueTransformer {}
@end
