//
//  XQEquationCalculator.h
//  Quotient
//
//  Created by Andrew Merenbach on 1/15/08.
//  Copyright 2008 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface XQEquationCalculator : NSOperation {

    unichar *buffer;

    // property ivars
    NSUInteger m_dividend;
    NSUInteger m_divisor;
    NSUInteger m_scaleOfNotation;
    NSString *m_quotient;
}

- (id)initWithScale:(NSUInteger)scale;
- (id)init;
- (void)finalize;

- (void)main;
- (void)calculate;

@property (assign, readwrite) NSUInteger dividend;
@property (assign, readwrite) NSUInteger divisor;
@property (assign, readwrite) NSUInteger scaleOfNotation;
@property (copy, readwrite) NSString *quotient;

@end
