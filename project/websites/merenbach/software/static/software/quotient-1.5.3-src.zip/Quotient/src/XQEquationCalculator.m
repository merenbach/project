//
//  XQEquationCalculator.m
//  Quotient
//
//  Created by Andrew Merenbach on 1/15/08.
//  Copyright 2008 Andrew Merenbach. All rights reserved.
//

#import "XQEquationCalculator.h"


@implementation XQEquationCalculator

- (id)initWithScale:(NSUInteger)scale {
    self = [super init];
    if (self) {
        m_dividend = 1;
        m_divisor = 1;
        m_scaleOfNotation = scale;
        m_quotient = [[NSString alloc] initWithString:@""];

        buffer = (unichar *)malloc(scale * sizeof(unichar));
    }
    return self;
}

- (id)init {
    self = [self initWithScale:1];
    return self;
}

- (void)dealloc {
    [m_quotient release];
    m_quotient = nil;
	
	free(buffer);
    buffer = NULL;
	
    [super dealloc];
}

- (void)finalize {
    free(buffer);
    buffer = NULL;
    [super finalize];
}

- (void)main {
    [self calculate];
}

- (void)calculate {
    NSMutableString *quotientString = [NSMutableString string];
    
    NSUInteger b = self.dividend;
    NSUInteger a = self.divisor;
    NSUInteger scale = self.scaleOfNotation;
    
    if (a > 0 && !self.isCancelled) {   // sanity-check; cannot divide by zero
        //buffer = (unichar *)malloc(scale * sizeof(unichar));
        NSUInteger q;
        NSUInteger integerPortion;
        
        q = floor(b / a);
        integerPortion = q;
        
        //b = 10 * fmod(b, a);
        
        for (NSUInteger n = 0; n < scale; ++n) {
            if (self.isCancelled) break;
            
            b = 10 * (b - q * a);
            q = floor(b / a);
            
            /*
            UniChar uch = '0' + (q % 10);
            CFStringAppendCharacters((CFMutableStringRef)quotientString, &uch, 1);
            */
            
            //[quotientString appendFormat:@"%i", q];
            buffer[n] = (unichar)'0' + (unichar)(q % 10);
            //b = 10 * fmod(b, a);
            //b = 10 * b % a;
        }
                
        if (self.isCancelled) return;
        NSString *scaleString = [NSString stringWithCharacters:buffer length:scale];
        
        if (self.isCancelled) return;
        [quotientString appendFormat:@"%i", integerPortion];
        
        if ([scaleString length] > 0) {
            [quotientString appendString:@"."];
            [quotientString appendString:scaleString];
        }
        
        //free(buffer);
    }
        
    if (self.isCancelled) return;
    self.quotient = quotientString;
}


@synthesize dividend = m_dividend;
@synthesize divisor = m_divisor;
@synthesize scaleOfNotation = m_scaleOfNotation;
@synthesize quotient = m_quotient;

@end
