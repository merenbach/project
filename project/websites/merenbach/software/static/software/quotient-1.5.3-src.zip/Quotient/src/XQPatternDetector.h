//
//  XQPatternDetector.h
//  Sniffer
//
//  Created by Andrew Merenbach on 7/11/07.
//  Copyright 2007 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface XQPatternDetector : NSOperation {
    // for properties
    //BOOL isDetecting;
    //id handler;
    NSString *m_originalString;
    NSString *m_patternString;
}

//@property (assign, readwrite) BOOL isDetecting;
//@property (assign, readwrite) id handler;
@property (copy, readwrite) NSString *originalString;
@property (copy, readwrite) NSString *patternString;

- (id)init;
- (void)main;
- (void)locate;

@end

@interface XQPatternDetector (Algorithms)
- (NSString *)findPatternFromRightInString:(NSString *)string;
- (NSString *)findPatternInString:(NSString *)string;
- (NSIndexSet *)indexSetOfFactorsOfNumber:(NSUInteger)num;
//- (NSArray *)factorsOfNumber:(NSUInteger)num;
- (NSString *)substringPastDecimalPointInString:(NSString *)string;
@end
