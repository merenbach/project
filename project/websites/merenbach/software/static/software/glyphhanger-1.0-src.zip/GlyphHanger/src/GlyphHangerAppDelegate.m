//
//  GlyphHangerAppDelegate.m
//  GlyphHanger
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "GlyphHangerAppDelegate.h"
#import "GHAttributedStringAdditions.h"

@implementation GlyphHangerAppDelegate

@synthesize window = m_window;
@synthesize textView = m_textView;
@synthesize radius = m_radius;

- (id)init {
	self = [super init];
	if (self != nil) {
		m_radius = 0;
	}
	return self;
}

- (IBAction)convertText:(id)sender {
	NSAttributedString *string = [self.textView textStorage];
	
	NSImage *newImage = [string croppedAttributedStringImageWithRadius:self.radius];
	NSData *imageData = [newImage TIFFRepresentation];
	
	NSArray *types = [NSArray arrayWithObject:NSTIFFPboardType];
	NSPasteboard *pboard = [NSPasteboard generalPasteboard];
	[pboard declareTypes:types owner:nil];
	
	(void)[pboard setData:imageData forType:NSTIFFPboardType];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
	return YES;
}

/* old method from when GlyphHanger was a system service */
/*- (void)convertGlyphs:(NSPasteboard *)pboard
			userData:(NSString *)data
			   error:(NSString **)error
{
	
	NSAttributedString *pboardString;
	NSImage *newImage;
	NSArray *types = [pboard types];
	NSData *inputData;
	
	if ([types containsObject:NSRTFDPboardType] && (inputData = [pboard dataForType:NSRTFDPboardType]) ) {
		NSDictionary *attrs;
		pboardString = [[[NSAttributedString alloc] initWithRTFD:inputData documentAttributes:&attrs] autorelease];
		if (! (newImage = [pboardString croppedImage]) ) {
			*error = NSLocalizedString(@"Error: Pasteboard contains no usable data.",
									   @"Couldn't perform service operation.");
			return;
		}
	} else if ([types containsObject:NSRTFPboardType] && (inputData = [pboard dataForType:NSRTFPboardType]) ) {
		pboardString = [[[NSAttributedString alloc] initWithRTF:inputData documentAttributes:NULL] autorelease];
		if (! (newImage = [pboardString croppedImage]) ) {
			*error = NSLocalizedString(@"Error: Pasteboard contains no usable data.",
									   @"Couldn't perform service operation.");
			return;
		}
		
	} else {
		*error = NSLocalizedString(@"Error: No supported data type in pasteboard.",
								   @"Pasteboard couldn't give string type.");
		return;
	}
	
	NSData *imageData = [newImage TIFFRepresentation];
	
	types = [NSArray arrayWithObject:NSTIFFPboardType];
	pboard = [NSPasteboard generalPasteboard];
	[pboard declareTypes:types owner:nil];
	
	(void) [pboard setData:imageData forType:NSTIFFPboardType];
}*/

@end
