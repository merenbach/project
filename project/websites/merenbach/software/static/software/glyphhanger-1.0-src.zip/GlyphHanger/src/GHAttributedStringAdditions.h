//
//  GHAttributedStringAdditions.h
//  GlyphHanger
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSAttributedString (GHAttributedStringAdditions)

- (NSImage *)croppedAttributedStringImageWithRadius:(CGFloat)radius;
//- (NSImage *)croppedAttributedStringImage;
- (NSImage *)drawnAttributedStringImageInRect:(NSRect)drawingRect;

@end
