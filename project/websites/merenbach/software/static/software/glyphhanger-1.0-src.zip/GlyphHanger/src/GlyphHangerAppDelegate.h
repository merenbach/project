//
//  GlyphHangerAppDelegate.h
//  GlyphHanger
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GlyphHangerAppDelegate : NSObject {
    NSWindow *m_window;
	NSTextView *m_textView;
	CGFloat m_radius;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSTextView *textView;
@property (assign, readwrite) CGFloat radius;

- (IBAction)convertText:(id)sender;
/*- (void)convertGlyphs:(NSPasteboard *)pboard
			 userData:(NSString *)data
				error:(NSString **)error;*/


@end
