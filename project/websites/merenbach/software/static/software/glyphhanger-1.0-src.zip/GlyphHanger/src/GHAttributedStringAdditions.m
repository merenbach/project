//
//  GHAttributedStringAdditions.m
//  GlyphHanger
//
//  Created by Andrew Merenbach on 1/24/10.
//  Copyright 2010 Andrew Merenbach. All rights reserved.
//

#import "GHAttributedStringAdditions.h"


@implementation NSAttributedString (GHAttributedStringAdditions)

- (NSImage *)croppedAttributedStringImageWithRadius:(CGFloat)radius {
	NSTextStorage *textStorage = [[NSTextStorage alloc] initWithAttributedString:self];
	NSTextContainer *textContainer = [[NSTextContainer alloc] initWithContainerSize:NSMakeSize(FLT_MAX, FLT_MAX)];
	NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
	
	[layoutManager addTextContainer:textContainer];
	[textStorage addLayoutManager:layoutManager];
	
	[textContainer setLineFragmentPadding:0.0];
	(void) [layoutManager glyphRangeForTextContainer:textContainer];
	NSRect drawingRect = [layoutManager usedRectForTextContainer:textContainer];
	
	// add border
	drawingRect.size.width += radius * 2;
	drawingRect.size.height += radius * 2;
	drawingRect.origin.x += radius;
	drawingRect.origin.y += radius;
	
	NSImage *textImage = [self drawnAttributedStringImageInRect:drawingRect];
	
	[textStorage removeLayoutManager:layoutManager];
	[layoutManager removeTextContainerAtIndex:0];
	
	[textStorage release];
	[textContainer release];
	[layoutManager release];
	
	return textImage;
}

/*- (NSImage *)croppedAttributedStringImage {	
	NSTextStorage *textStorage = [[NSTextStorage alloc] initWithAttributedString:self];
	NSTextContainer *textContainer = [[NSTextContainer alloc] initWithContainerSize:NSMakeSize(FLT_MAX, FLT_MAX)];
	NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
	
	[layoutManager addTextContainer:textContainer];
	[textStorage addLayoutManager:layoutManager];
	
	[textContainer setLineFragmentPadding:0.0];
	(void) [layoutManager glyphRangeForTextContainer:textContainer];
	NSRect drawingRect = [layoutManager usedRectForTextContainer:textContainer];
	drawingRect.size.width += 400;
	drawingRect.size.height += 400;
	NSImage *textImage = [self drawnAttributedStringImageInRect:drawingRect];
		
	[textStorage removeLayoutManager:layoutManager];
	[layoutManager removeTextContainerAtIndex:0];
	
	[textStorage release];
	[textContainer release];
	[layoutManager release];
	
	return textImage;
}*/

- (NSImage *)drawnAttributedStringImageInRect:(NSRect)drawingRect {
	NSImage *textImage = [[[NSImage alloc] initWithSize:drawingRect.size] autorelease];
	[textImage setFlipped:YES];

	NSGraphicsContext *currentContext = [NSGraphicsContext currentContext];

	NSImageInterpolation oldImageInterpolation = [currentContext imageInterpolation];
	BOOL oldShouldAntialias = [currentContext shouldAntialias];

	[currentContext setImageInterpolation:NSImageInterpolationHigh];
	[currentContext setShouldAntialias:YES];
	
	[textImage lockFocus];
	[self drawInRect:drawingRect];
	[textImage unlockFocus];

	[currentContext setImageInterpolation:oldImageInterpolation];
	[currentContext setShouldAntialias:oldShouldAntialias];
	
	return textImage;
}

@end